# ************************************************************
# Sequel Pro SQL dump
# Version 4004
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.9)
# Database: fanninglandscapes-c5
# Generation Time: 2013-04-27 22:13:55 -0300
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table AreaPermissionAssignments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AreaPermissionAssignments`;

CREATE TABLE `AreaPermissionAssignments` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `pkID` int(10) unsigned NOT NULL DEFAULT '0',
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`arHandle`,`pkID`,`paID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table AreaPermissionBlockTypeAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AreaPermissionBlockTypeAccessList`;

CREATE TABLE `AreaPermissionBlockTypeAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table AreaPermissionBlockTypeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AreaPermissionBlockTypeAccessListCustom`;

CREATE TABLE `AreaPermissionBlockTypeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `btID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`btID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Areas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Areas`;

CREATE TABLE `Areas` (
  `arID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `arOverrideCollectionPermissions` tinyint(1) NOT NULL DEFAULT '0',
  `arInheritPermissionsFromAreaOnCID` int(10) unsigned NOT NULL DEFAULT '0',
  `arIsGlobal` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arID`),
  KEY `arIsGlobal` (`arIsGlobal`),
  KEY `cID` (`cID`),
  KEY `arHandle` (`arHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Areas` WRITE;
/*!40000 ALTER TABLE `Areas` DISABLE KEYS */;

INSERT INTO `Areas` (`arID`, `cID`, `arHandle`, `arOverrideCollectionPermissions`, `arInheritPermissionsFromAreaOnCID`, `arIsGlobal`)
VALUES
	(1,106,'Header',0,0,0),
	(2,106,'Column 1',0,0,0),
	(3,106,'Column 2',0,0,0),
	(4,106,'Column 3',0,0,0),
	(5,106,'Column 4',0,0,0),
	(6,105,'Primary',0,0,0),
	(7,105,'Secondary 1',0,0,0),
	(8,105,'Secondary 2',0,0,0),
	(9,105,'Secondary 3',0,0,0),
	(10,105,'Secondary 4',0,0,0),
	(11,105,'Secondary 5',0,0,0),
	(12,121,'Main',0,0,0),
	(13,122,'Main',0,0,0),
	(14,123,'Main',0,0,0),
	(15,124,'Main',0,0,0),
	(16,124,'Sidebar',0,0,0),
	(17,124,'Thumbnail Image',0,0,0),
	(18,124,'Header Image',0,0,0),
	(19,125,'Header Image',0,0,0),
	(20,126,'Header Image',0,0,0),
	(21,127,'Header Image',0,0,0),
	(22,1,'Sidebar',0,0,0),
	(23,1,'Main',0,0,0),
	(24,1,'Header Image',0,0,0),
	(25,128,'Sidebar',0,0,0),
	(26,128,'Main',0,0,0),
	(27,128,'Header Image',0,0,0),
	(28,132,'Sidebar',0,0,0),
	(29,132,'Main',0,0,0),
	(30,132,'Header Image',0,0,0),
	(31,131,'Sidebar',0,0,0),
	(32,131,'Main',0,0,0),
	(33,131,'Header Image',0,0,0),
	(34,130,'Sidebar',0,0,0),
	(35,130,'Main',0,0,0),
	(36,130,'Header Image',0,0,0),
	(37,129,'Main',0,0,0),
	(38,129,'Sidebar',0,0,0),
	(39,129,'Header Image',0,0,0),
	(40,134,'Header Image',0,0,0),
	(41,134,'Main',0,0,0),
	(42,134,'Thumbnail Image',0,0,0),
	(43,134,'Sidebar',0,0,0),
	(44,133,'Main',0,0,0),
	(45,133,'Sidebar',0,0,0),
	(46,133,'Header Image',0,0,0),
	(47,1,'Site Name',0,0,1),
	(48,1,'Header Nav',0,0,1),
	(49,135,'Header Image',0,0,0),
	(50,135,'Thumbnail Image',0,0,0),
	(51,135,'Main',0,0,0),
	(52,128,'Site Name',0,0,1),
	(53,128,'Header Nav',0,0,1),
	(54,130,'Site Name',0,0,1),
	(55,130,'Header Nav',0,0,1),
	(56,1,'Top Block',0,0,0),
	(57,1,'About Block',0,0,0),
	(58,1,'Services Block',0,0,0),
	(59,1,'Gallery Block',0,0,0),
	(60,1,'Contact Block',0,0,0),
	(61,117,'Main',0,0,0);

/*!40000 ALTER TABLE `Areas` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atAddress
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atAddress`;

CREATE TABLE `atAddress` (
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state_province` varchar(255) DEFAULT NULL,
  `country` varchar(4) DEFAULT NULL,
  `postal_code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table atAddressCustomCountries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atAddressCustomCountries`;

CREATE TABLE `atAddressCustomCountries` (
  `atAddressCustomCountryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `country` varchar(5) NOT NULL,
  PRIMARY KEY (`atAddressCustomCountryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table atAddressSettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atAddressSettings`;

CREATE TABLE `atAddressSettings` (
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `akHasCustomCountries` int(1) NOT NULL DEFAULT '0',
  `akDefaultCountry` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table atBoolean
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atBoolean`;

CREATE TABLE `atBoolean` (
  `avID` int(10) unsigned NOT NULL,
  `value` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atBoolean` WRITE;
/*!40000 ALTER TABLE `atBoolean` DISABLE KEYS */;

INSERT INTO `atBoolean` (`avID`, `value`)
VALUES
	(20,1),
	(31,1),
	(34,1),
	(64,1),
	(65,1),
	(68,1),
	(69,1),
	(75,1),
	(108,1),
	(117,1),
	(118,1),
	(119,1),
	(138,1),
	(139,1),
	(140,1);

/*!40000 ALTER TABLE `atBoolean` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atBooleanSettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atBooleanSettings`;

CREATE TABLE `atBooleanSettings` (
  `akID` int(10) unsigned NOT NULL,
  `akCheckedByDefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atBooleanSettings` WRITE;
/*!40000 ALTER TABLE `atBooleanSettings` DISABLE KEYS */;

INSERT INTO `atBooleanSettings` (`akID`, `akCheckedByDefault`)
VALUES
	(5,0),
	(6,0),
	(8,0),
	(9,0),
	(10,1),
	(11,1);

/*!40000 ALTER TABLE `atBooleanSettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atDateTime
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atDateTime`;

CREATE TABLE `atDateTime` (
  `avID` int(10) unsigned NOT NULL,
  `value` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table atDateTimeSettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atDateTimeSettings`;

CREATE TABLE `atDateTimeSettings` (
  `akID` int(10) unsigned NOT NULL,
  `akDateDisplayMode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table atDefault
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atDefault`;

CREATE TABLE `atDefault` (
  `avID` int(10) unsigned NOT NULL,
  `value` longtext,
  PRIMARY KEY (`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atDefault` WRITE;
/*!40000 ALTER TABLE `atDefault` DISABLE KEYS */;

INSERT INTO `atDefault` (`avID`, `value`)
VALUES
	(1,'blog, blogging'),
	(2,'icon-book'),
	(3,'new blog, write blog, blogging'),
	(4,'icon-pencil'),
	(5,'blog drafts,composer'),
	(6,'icon-book'),
	(7,'pages, add page, delete page, copy, move, alias'),
	(8,'pages, add page, delete page, copy, move, alias'),
	(9,'icon-home'),
	(10,'pages, add page, delete page, copy, move, alias, bulk'),
	(11,'icon-road'),
	(12,'find page, search page, search, find, pages, sitemap'),
	(13,'icon-search'),
	(14,'add file, delete file, copy, move, alias, resize, crop, rename, images, title, attribute'),
	(15,'icon-picture'),
	(16,'file, file attributes, title, attribute, description, rename'),
	(17,'icon-cog'),
	(18,'files, category, categories'),
	(19,'icon-list-alt'),
	(21,'new file set'),
	(22,'icon-plus-sign'),
	(23,'users, groups, people, find, delete user, remove user, change password, password'),
	(24,'find, search, people, delete user, remove user, change password, password'),
	(25,'icon-user'),
	(26,'user, group, people, permissions, access, expire'),
	(27,'icon-globe'),
	(28,'user attributes, user data, gather data, registration data'),
	(29,'icon-cog'),
	(30,'new user, create'),
	(32,'icon-plus-sign'),
	(33,'new user group, new group, group, create'),
	(35,'icon-plus'),
	(36,'group set'),
	(37,'icon-list'),
	(38,'forms, log, error, email, mysql, exception, survey'),
	(39,'hits, pageviews, visitors, activity'),
	(40,'icon-signal'),
	(41,'forms, questions, response, data'),
	(42,'icon-briefcase'),
	(43,'questions, quiz, response'),
	(44,'icon-tasks'),
	(45,'forms, log, error, email, mysql, exception, survey, history'),
	(46,'icon-time'),
	(47,'new theme, theme, active theme, change theme, template, css'),
	(48,'icon-font'),
	(49,'theme'),
	(50,'page types'),
	(51,'custom theme, change theme, custom css, css'),
	(52,'page type defaults, global block, global area, starter, template'),
	(53,'icon-file'),
	(54,'page attributes, custom'),
	(55,'icon-cog'),
	(56,'single, page, custom, application'),
	(57,'icon-wrench'),
	(58,'add workflow, remove workflow'),
	(59,'icon-list'),
	(60,'icon-user'),
	(61,'stacks, reusable content, scrapbook, copy, paste, paste block, copy block, site name, logo'),
	(62,'icon-th'),
	(63,'icon-lock'),
	(66,'block, refresh, custom'),
	(67,'icon-wrench'),
	(70,'add-on, addon, ecommerce, install, discussions, forums, themes, templates, blocks'),
	(71,'update, upgrade'),
	(72,'concrete5.org, my account, marketplace'),
	(73,'buy theme, new theme, marketplace, template'),
	(74,'buy addon, buy add on, buy add-on, purchase addon, purchase add on, purchase add-on, find addon, new addon, marketplace'),
	(76,'website name, title'),
	(77,'logo, favicon, iphone, icon, bookmark'),
	(78,'tinymce, content block, fonts, editor, tinymce, content, overlay'),
	(79,'translate, translation, internationalization, multilingual, translate'),
	(80,'timezone, profile, locale'),
	(81,'interface, quick nav, dashboard background, background image'),
	(82,'vanity, pretty url, seo, pageview, view'),
	(83,'bulk, seo, change keywords, engine, optimization, search'),
	(84,'traffic, statistics, google analytics, quant, pageviews, hits'),
	(85,'pretty, slug'),
	(86,'turn off statistics, tracking, statistics, pageviews, hits'),
	(87,'configure search, site search, search option'),
	(88,'cache option, change cache, override, turn on cache, turn off cache, no cache, page cache, caching'),
	(89,'cache option, turn off cache, no cache, page cache, caching'),
	(90,'index search, reindex search, build sitemap, sitemap.xml, clear old versions, page versions, remove old'),
	(91,'editors, hide site, offline, private, public, access'),
	(92,'file options, file manager, upload, modify'),
	(93,'security, files, media, extension, manager, upload'),
	(94,'security, actions, administrator, admin, package, marketplace, search'),
	(95,'security, lock ip, lock out, block ip, address, restrict, access'),
	(96,'security, registration'),
	(97,'antispam, block spam, security'),
	(98,'lock site, under construction, hide, hidden'),
	(99,'profile, login, redirect, specific, dashboard, administrators'),
	(100,'member profile, member page,community, forums, social, avatar'),
	(101,'signup, new user, community'),
	(102,'smtp, mail settings'),
	(103,'email server, mail settings, mail configuration, external, internal'),
	(104,'email server, mail settings, mail configuration, private message, message system, import, email, message'),
	(105,'attribute configuration'),
	(106,'attributes, sets'),
	(107,'attributes, types'),
	(109,'overrides, system info, debug, support,help'),
	(110,'errors,exceptions, develop, support, help'),
	(111,'email, logging, logs, smtp, pop, errors, mysql, errors, log'),
	(112,'security, alternate storage, hide files'),
	(113,'network, proxy server'),
	(114,'export, backup, database, sql, mysql, encryption, restore'),
	(115,'upgrade, new version, update'),
	(116,'export, database, xml, starting, points, schema, refresh, custom, tables');

/*!40000 ALTER TABLE `atDefault` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atFile
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atFile`;

CREATE TABLE `atFile` (
  `avID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table atNumber
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atNumber`;

CREATE TABLE `atNumber` (
  `avID` int(10) unsigned NOT NULL,
  `value` decimal(14,4) DEFAULT '0.0000',
  PRIMARY KEY (`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atNumber` WRITE;
/*!40000 ALTER TABLE `atNumber` DISABLE KEYS */;

INSERT INTO `atNumber` (`avID`, `value`)
VALUES
	(120,960.0000),
	(121,212.0000),
	(122,960.0000),
	(123,212.0000),
	(124,960.0000),
	(125,212.0000),
	(126,960.0000),
	(127,212.0000),
	(128,960.0000),
	(129,212.0000),
	(130,960.0000),
	(131,212.0000),
	(132,960.0000),
	(133,212.0000),
	(134,150.0000),
	(135,150.0000),
	(143,3264.0000),
	(144,2448.0000),
	(145,3264.0000),
	(146,2448.0000),
	(147,3264.0000),
	(148,2448.0000),
	(149,3264.0000),
	(150,2448.0000),
	(151,3264.0000),
	(152,2448.0000),
	(153,3264.0000),
	(154,2448.0000),
	(155,3264.0000),
	(156,2448.0000),
	(157,3264.0000),
	(158,2448.0000),
	(159,334.0000),
	(160,102.0000);

/*!40000 ALTER TABLE `atNumber` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atSelectOptions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atSelectOptions`;

CREATE TABLE `atSelectOptions` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akID` int(10) unsigned DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `displayOrder` int(10) unsigned DEFAULT NULL,
  `isEndUserAdded` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atSelectOptions` WRITE;
/*!40000 ALTER TABLE `atSelectOptions` DISABLE KEYS */;

INSERT INTO `atSelectOptions` (`ID`, `akID`, `value`, `displayOrder`, `isEndUserAdded`)
VALUES
	(1,14,'composer',0,1),
	(2,14,'hello',1,1),
	(3,14,'world',2,1),
	(4,14,'first post',3,1);

/*!40000 ALTER TABLE `atSelectOptions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atSelectOptionsSelected
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atSelectOptionsSelected`;

CREATE TABLE `atSelectOptionsSelected` (
  `avID` int(10) unsigned NOT NULL,
  `atSelectOptionID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`avID`,`atSelectOptionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atSelectOptionsSelected` WRITE;
/*!40000 ALTER TABLE `atSelectOptionsSelected` DISABLE KEYS */;

INSERT INTO `atSelectOptionsSelected` (`avID`, `atSelectOptionID`)
VALUES
	(137,1),
	(137,2),
	(137,3),
	(137,4);

/*!40000 ALTER TABLE `atSelectOptionsSelected` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atSelectSettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atSelectSettings`;

CREATE TABLE `atSelectSettings` (
  `akID` int(10) unsigned NOT NULL,
  `akSelectAllowMultipleValues` tinyint(1) NOT NULL DEFAULT '0',
  `akSelectOptionDisplayOrder` varchar(255) NOT NULL DEFAULT 'display_asc',
  `akSelectAllowOtherValues` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atSelectSettings` WRITE;
/*!40000 ALTER TABLE `atSelectSettings` DISABLE KEYS */;

INSERT INTO `atSelectSettings` (`akID`, `akSelectAllowMultipleValues`, `akSelectOptionDisplayOrder`, `akSelectAllowOtherValues`)
VALUES
	(14,1,'display_asc',1);

/*!40000 ALTER TABLE `atSelectSettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table atTextareaSettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `atTextareaSettings`;

CREATE TABLE `atTextareaSettings` (
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `akTextareaDisplayMode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `atTextareaSettings` WRITE;
/*!40000 ALTER TABLE `atTextareaSettings` DISABLE KEYS */;

INSERT INTO `atTextareaSettings` (`akID`, `akTextareaDisplayMode`)
VALUES
	(2,''),
	(3,''),
	(4,''),
	(7,'');

/*!40000 ALTER TABLE `atTextareaSettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table AttributeKeyCategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AttributeKeyCategories`;

CREATE TABLE `AttributeKeyCategories` (
  `akCategoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akCategoryHandle` varchar(255) NOT NULL,
  `akCategoryAllowSets` smallint(4) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`akCategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `AttributeKeyCategories` WRITE;
/*!40000 ALTER TABLE `AttributeKeyCategories` DISABLE KEYS */;

INSERT INTO `AttributeKeyCategories` (`akCategoryID`, `akCategoryHandle`, `akCategoryAllowSets`, `pkgID`)
VALUES
	(1,'collection',1,NULL),
	(2,'user',1,NULL),
	(3,'file',1,NULL);

/*!40000 ALTER TABLE `AttributeKeyCategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table AttributeKeys
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AttributeKeys`;

CREATE TABLE `AttributeKeys` (
  `akID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akHandle` varchar(255) NOT NULL,
  `akName` varchar(255) NOT NULL,
  `akIsSearchable` tinyint(1) NOT NULL DEFAULT '0',
  `akIsSearchableIndexed` tinyint(1) NOT NULL DEFAULT '0',
  `akIsAutoCreated` tinyint(1) NOT NULL DEFAULT '0',
  `akIsInternal` tinyint(1) NOT NULL DEFAULT '0',
  `akIsColumnHeader` tinyint(1) NOT NULL DEFAULT '0',
  `akIsEditable` tinyint(1) NOT NULL DEFAULT '0',
  `atID` int(10) unsigned DEFAULT NULL,
  `akCategoryID` int(10) unsigned DEFAULT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`akID`),
  UNIQUE KEY `akHandle` (`akHandle`,`akCategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `AttributeKeys` WRITE;
/*!40000 ALTER TABLE `AttributeKeys` DISABLE KEYS */;

INSERT INTO `AttributeKeys` (`akID`, `akHandle`, `akName`, `akIsSearchable`, `akIsSearchableIndexed`, `akIsAutoCreated`, `akIsInternal`, `akIsColumnHeader`, `akIsEditable`, `atID`, `akCategoryID`, `pkgID`)
VALUES
	(1,'meta_title','Meta Title',1,1,0,0,0,1,1,1,0),
	(2,'meta_description','Meta Description',1,1,0,0,0,1,2,1,0),
	(3,'meta_keywords','Meta Keywords',1,1,0,0,0,1,2,1,0),
	(4,'icon_dashboard','Dashboard Icon',1,1,0,1,0,1,2,1,0),
	(5,'exclude_nav','Exclude From Nav',1,1,0,0,0,1,3,1,0),
	(6,'exclude_page_list','Exclude From Page List',1,1,0,0,0,1,3,1,0),
	(7,'header_extra_content','Header Extra Content',1,1,0,0,0,1,2,1,0),
	(8,'exclude_search_index','Exclude From Search Index',1,1,0,0,0,1,3,1,0),
	(9,'exclude_sitemapxml','Exclude From sitemap.xml',1,1,0,0,0,1,3,1,0),
	(10,'profile_private_messages_enabled','I would like to receive private messages.',1,1,0,0,0,1,3,2,0),
	(11,'profile_private_messages_notification_enabled','Send me email notifications when I receive a private message.',1,1,0,0,0,1,3,2,0),
	(12,'width','Width',1,1,0,0,0,1,6,3,0),
	(13,'height','Height',1,1,0,0,0,1,6,3,0),
	(14,'tags','Tags',1,1,0,0,0,1,8,1,0);

/*!40000 ALTER TABLE `AttributeKeys` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table AttributeSetKeys
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AttributeSetKeys`;

CREATE TABLE `AttributeSetKeys` (
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `asID` int(10) unsigned NOT NULL DEFAULT '0',
  `displayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`akID`,`asID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `AttributeSetKeys` WRITE;
/*!40000 ALTER TABLE `AttributeSetKeys` DISABLE KEYS */;

INSERT INTO `AttributeSetKeys` (`akID`, `asID`, `displayOrder`)
VALUES
	(1,1,1),
	(2,1,2),
	(3,1,3),
	(5,2,1),
	(6,2,2),
	(7,1,4),
	(8,2,3),
	(9,2,4);

/*!40000 ALTER TABLE `AttributeSetKeys` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table AttributeSets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AttributeSets`;

CREATE TABLE `AttributeSets` (
  `asID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asName` varchar(255) DEFAULT NULL,
  `asHandle` varchar(255) NOT NULL,
  `akCategoryID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  `asIsLocked` int(1) NOT NULL DEFAULT '1',
  `asDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`asID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `AttributeSets` WRITE;
/*!40000 ALTER TABLE `AttributeSets` DISABLE KEYS */;

INSERT INTO `AttributeSets` (`asID`, `asName`, `asHandle`, `akCategoryID`, `pkgID`, `asIsLocked`, `asDisplayOrder`)
VALUES
	(1,'Page Header','page_header',1,0,0,0),
	(2,'Navigation and Indexing','navigation',1,0,0,1);

/*!40000 ALTER TABLE `AttributeSets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table AttributeTypeCategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AttributeTypeCategories`;

CREATE TABLE `AttributeTypeCategories` (
  `atID` int(10) unsigned NOT NULL DEFAULT '0',
  `akCategoryID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`atID`,`akCategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `AttributeTypeCategories` WRITE;
/*!40000 ALTER TABLE `AttributeTypeCategories` DISABLE KEYS */;

INSERT INTO `AttributeTypeCategories` (`atID`, `akCategoryID`)
VALUES
	(1,1),
	(1,2),
	(1,3),
	(2,1),
	(2,2),
	(2,3),
	(3,1),
	(3,2),
	(3,3),
	(4,1),
	(4,2),
	(4,3),
	(5,1),
	(6,1),
	(6,2),
	(6,3),
	(7,1),
	(7,3),
	(8,1),
	(8,2),
	(8,3),
	(9,2);

/*!40000 ALTER TABLE `AttributeTypeCategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table AttributeTypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AttributeTypes`;

CREATE TABLE `AttributeTypes` (
  `atID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `atHandle` varchar(255) NOT NULL,
  `atName` varchar(255) NOT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`atID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `AttributeTypes` WRITE;
/*!40000 ALTER TABLE `AttributeTypes` DISABLE KEYS */;

INSERT INTO `AttributeTypes` (`atID`, `atHandle`, `atName`, `pkgID`)
VALUES
	(1,'text','Text',0),
	(2,'textarea','Text Area',0),
	(3,'boolean','Checkbox',0),
	(4,'date_time','Date/Time',0),
	(5,'image_file','Image/File',0),
	(6,'number','Number',0),
	(7,'rating','Rating',0),
	(8,'select','Select',0),
	(9,'address','Address',0);

/*!40000 ALTER TABLE `AttributeTypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table AttributeValues
# ------------------------------------------------------------

DROP TABLE IF EXISTS `AttributeValues`;

CREATE TABLE `AttributeValues` (
  `avID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `akID` int(10) unsigned DEFAULT NULL,
  `avDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uID` int(10) unsigned DEFAULT NULL,
  `atID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `AttributeValues` WRITE;
/*!40000 ALTER TABLE `AttributeValues` DISABLE KEYS */;

INSERT INTO `AttributeValues` (`avID`, `akID`, `avDateAdded`, `uID`, `atID`)
VALUES
	(1,3,'2013-04-27 15:01:41',1,2),
	(2,4,'2013-04-27 15:01:41',1,2),
	(3,3,'2013-04-27 15:01:41',1,2),
	(4,4,'2013-04-27 15:01:41',1,2),
	(5,3,'2013-04-27 15:01:41',1,2),
	(6,4,'2013-04-27 15:01:41',1,2),
	(7,3,'2013-04-27 15:01:41',1,2),
	(8,3,'2013-04-27 15:01:41',1,2),
	(9,4,'2013-04-27 15:01:41',1,2),
	(10,3,'2013-04-27 15:01:41',1,2),
	(11,4,'2013-04-27 15:01:41',1,2),
	(12,3,'2013-04-27 15:01:41',1,2),
	(13,4,'2013-04-27 15:01:41',1,2),
	(14,3,'2013-04-27 15:01:41',1,2),
	(15,4,'2013-04-27 15:01:41',1,2),
	(16,3,'2013-04-27 15:01:41',1,2),
	(17,4,'2013-04-27 15:01:41',1,2),
	(18,3,'2013-04-27 15:01:41',1,2),
	(19,4,'2013-04-27 15:01:42',1,2),
	(20,5,'2013-04-27 15:01:42',1,3),
	(21,3,'2013-04-27 15:01:42',1,2),
	(22,4,'2013-04-27 15:01:42',1,2),
	(23,3,'2013-04-27 15:01:42',1,2),
	(24,3,'2013-04-27 15:01:42',1,2),
	(25,4,'2013-04-27 15:01:42',1,2),
	(26,3,'2013-04-27 15:01:42',1,2),
	(27,4,'2013-04-27 15:01:42',1,2),
	(28,3,'2013-04-27 15:01:42',1,2),
	(29,4,'2013-04-27 15:01:42',1,2),
	(30,3,'2013-04-27 15:01:42',1,2),
	(31,5,'2013-04-27 15:01:42',1,3),
	(32,4,'2013-04-27 15:01:42',1,2),
	(33,3,'2013-04-27 15:01:42',1,2),
	(34,5,'2013-04-27 15:01:42',1,3),
	(35,4,'2013-04-27 15:01:42',1,2),
	(36,3,'2013-04-27 15:01:42',1,2),
	(37,4,'2013-04-27 15:01:42',1,2),
	(38,3,'2013-04-27 15:01:42',1,2),
	(39,3,'2013-04-27 15:01:42',1,2),
	(40,4,'2013-04-27 15:01:42',1,2),
	(41,3,'2013-04-27 15:01:42',1,2),
	(42,4,'2013-04-27 15:01:42',1,2),
	(43,3,'2013-04-27 15:01:42',1,2),
	(44,4,'2013-04-27 15:01:42',1,2),
	(45,3,'2013-04-27 15:01:42',1,2),
	(46,4,'2013-04-27 15:01:42',1,2),
	(47,3,'2013-04-27 15:01:42',1,2),
	(48,4,'2013-04-27 15:01:42',1,2),
	(49,3,'2013-04-27 15:01:42',1,2),
	(50,3,'2013-04-27 15:01:42',1,2),
	(51,3,'2013-04-27 15:01:42',1,2),
	(52,3,'2013-04-27 15:01:42',1,2),
	(53,4,'2013-04-27 15:01:42',1,2),
	(54,3,'2013-04-27 15:01:42',1,2),
	(55,4,'2013-04-27 15:01:42',1,2),
	(56,3,'2013-04-27 15:01:42',1,2),
	(57,4,'2013-04-27 15:01:42',1,2),
	(58,3,'2013-04-27 15:01:42',1,2),
	(59,4,'2013-04-27 15:01:42',1,2),
	(60,4,'2013-04-27 15:01:42',1,2),
	(61,3,'2013-04-27 15:01:42',1,2),
	(62,4,'2013-04-27 15:01:42',1,2),
	(63,4,'2013-04-27 15:01:43',1,2),
	(64,5,'2013-04-27 15:01:43',1,3),
	(65,8,'2013-04-27 15:01:43',1,3),
	(66,3,'2013-04-27 15:01:43',1,2),
	(67,4,'2013-04-27 15:01:43',1,2),
	(68,5,'2013-04-27 15:01:43',1,3),
	(69,5,'2013-04-27 15:01:43',1,3),
	(70,3,'2013-04-27 15:01:43',1,2),
	(71,3,'2013-04-27 15:01:43',1,2),
	(72,3,'2013-04-27 15:01:43',1,2),
	(73,3,'2013-04-27 15:01:43',1,2),
	(74,3,'2013-04-27 15:01:43',1,2),
	(75,5,'2013-04-27 15:01:43',1,3),
	(76,3,'2013-04-27 15:01:43',1,2),
	(77,3,'2013-04-27 15:01:43',1,2),
	(78,3,'2013-04-27 15:01:43',1,2),
	(79,3,'2013-04-27 15:01:43',1,2),
	(80,3,'2013-04-27 15:01:43',1,2),
	(81,3,'2013-04-27 15:01:43',1,2),
	(82,3,'2013-04-27 15:01:43',1,2),
	(83,3,'2013-04-27 15:01:43',1,2),
	(84,3,'2013-04-27 15:01:43',1,2),
	(85,3,'2013-04-27 15:01:43',1,2),
	(86,3,'2013-04-27 15:01:43',1,2),
	(87,3,'2013-04-27 15:01:43',1,2),
	(88,3,'2013-04-27 15:01:43',1,2),
	(89,3,'2013-04-27 15:01:43',1,2),
	(90,3,'2013-04-27 15:01:43',1,2),
	(91,3,'2013-04-27 15:01:43',1,2),
	(92,3,'2013-04-27 15:01:43',1,2),
	(93,3,'2013-04-27 15:01:43',1,2),
	(94,3,'2013-04-27 15:01:43',1,2),
	(95,3,'2013-04-27 15:01:43',1,2),
	(96,3,'2013-04-27 15:01:43',1,2),
	(97,3,'2013-04-27 15:01:43',1,2),
	(98,3,'2013-04-27 15:01:43',1,2),
	(99,3,'2013-04-27 15:01:43',1,2),
	(100,3,'2013-04-27 15:01:43',1,2),
	(101,3,'2013-04-27 15:01:43',1,2),
	(102,3,'2013-04-27 15:01:43',1,2),
	(103,3,'2013-04-27 15:01:43',1,2),
	(104,3,'2013-04-27 15:01:44',1,2),
	(105,3,'2013-04-27 15:01:44',1,2),
	(106,3,'2013-04-27 15:01:44',1,2),
	(107,3,'2013-04-27 15:01:44',1,2),
	(108,8,'2013-04-27 15:01:44',1,3),
	(109,3,'2013-04-27 15:01:44',1,2),
	(110,3,'2013-04-27 15:01:44',1,2),
	(111,3,'2013-04-27 15:01:44',1,2),
	(112,3,'2013-04-27 15:01:44',1,2),
	(113,3,'2013-04-27 15:01:44',1,2),
	(114,3,'2013-04-27 15:01:44',1,2),
	(115,3,'2013-04-27 15:01:44',1,2),
	(116,3,'2013-04-27 15:01:44',1,2),
	(117,5,'2013-04-27 15:01:44',1,3),
	(118,5,'2013-04-27 15:01:44',1,3),
	(119,8,'2013-04-27 15:01:44',1,3),
	(120,12,'2013-04-27 15:01:45',1,6),
	(121,13,'2013-04-27 15:01:45',1,6),
	(122,12,'2013-04-27 15:01:45',1,6),
	(123,13,'2013-04-27 15:01:45',1,6),
	(124,12,'2013-04-27 15:01:45',1,6),
	(125,13,'2013-04-27 15:01:45',1,6),
	(126,12,'2013-04-27 15:01:46',1,6),
	(127,13,'2013-04-27 15:01:46',1,6),
	(128,12,'2013-04-27 15:01:46',1,6),
	(129,13,'2013-04-27 15:01:46',1,6),
	(130,12,'2013-04-27 15:01:46',1,6),
	(131,13,'2013-04-27 15:01:46',1,6),
	(132,12,'2013-04-27 15:01:46',1,6),
	(133,13,'2013-04-27 15:01:46',1,6),
	(134,12,'2013-04-27 15:01:46',1,6),
	(135,13,'2013-04-27 15:01:46',1,6),
	(136,14,'2013-04-27 15:01:48',1,8),
	(137,14,'2013-04-27 15:01:48',1,8),
	(138,5,'2013-04-27 15:01:48',1,3),
	(139,6,'2013-04-27 15:01:49',1,3),
	(140,8,'2013-04-27 15:01:49',1,3),
	(141,14,'2013-04-27 15:01:49',1,8),
	(142,14,'2013-04-27 20:01:32',1,8),
	(143,12,'2013-04-27 20:29:50',1,6),
	(144,13,'2013-04-27 20:29:50',1,6),
	(145,12,'2013-04-27 20:30:45',1,6),
	(146,13,'2013-04-27 20:30:45',1,6),
	(147,12,'2013-04-27 20:30:47',1,6),
	(148,13,'2013-04-27 20:30:47',1,6),
	(149,12,'2013-04-27 20:30:49',1,6),
	(150,13,'2013-04-27 20:30:49',1,6),
	(151,12,'2013-04-27 20:30:51',1,6),
	(152,13,'2013-04-27 20:30:51',1,6),
	(153,12,'2013-04-27 20:30:53',1,6),
	(154,13,'2013-04-27 20:30:53',1,6),
	(155,12,'2013-04-27 20:30:55',1,6),
	(156,13,'2013-04-27 20:30:55',1,6),
	(157,12,'2013-04-27 20:30:57',1,6),
	(158,13,'2013-04-27 20:30:57',1,6),
	(159,12,'2013-04-27 21:09:37',1,6),
	(160,13,'2013-04-27 21:09:37',1,6);

/*!40000 ALTER TABLE `AttributeValues` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BasicWorkflowPermissionAssignments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BasicWorkflowPermissionAssignments`;

CREATE TABLE `BasicWorkflowPermissionAssignments` (
  `wfID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkID` int(10) unsigned NOT NULL DEFAULT '0',
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`wfID`,`pkID`,`paID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table BasicWorkflowProgressData
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BasicWorkflowProgressData`;

CREATE TABLE `BasicWorkflowProgressData` (
  `wpID` int(10) unsigned NOT NULL DEFAULT '0',
  `uIDStarted` int(10) unsigned NOT NULL DEFAULT '0',
  `uIDCompleted` int(10) unsigned NOT NULL DEFAULT '0',
  `wpDateCompleted` datetime DEFAULT NULL,
  PRIMARY KEY (`wpID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table BlockPermissionAssignments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlockPermissionAssignments`;

CREATE TABLE `BlockPermissionAssignments` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkID` int(10) unsigned NOT NULL DEFAULT '0',
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`bID`,`pkID`,`paID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table BlockRelations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlockRelations`;

CREATE TABLE `BlockRelations` (
  `brID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `originalBID` int(10) unsigned NOT NULL DEFAULT '0',
  `relationType` varchar(50) NOT NULL,
  PRIMARY KEY (`brID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `BlockRelations` WRITE;
/*!40000 ALTER TABLE `BlockRelations` DISABLE KEYS */;

INSERT INTO `BlockRelations` (`brID`, `bID`, `originalBID`, `relationType`)
VALUES
	(1,48,16,'DUPLICATE'),
	(2,49,15,'DUPLICATE'),
	(3,50,13,'DUPLICATE'),
	(4,58,54,'DUPLICATE'),
	(5,59,57,'DUPLICATE'),
	(6,60,58,'DUPLICATE'),
	(7,61,59,'DUPLICATE'),
	(8,62,52,'DUPLICATE');

/*!40000 ALTER TABLE `BlockRelations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Blocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Blocks`;

CREATE TABLE `Blocks` (
  `bID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bName` varchar(60) DEFAULT NULL,
  `bDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bDateModified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bFilename` varchar(32) DEFAULT NULL,
  `bIsActive` varchar(1) NOT NULL DEFAULT '1',
  `btID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned DEFAULT NULL,
  `btCachedBlockRecord` longtext,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Blocks` WRITE;
/*!40000 ALTER TABLE `Blocks` DISABLE KEYS */;

INSERT INTO `Blocks` (`bID`, `bName`, `bDateAdded`, `bDateModified`, `bFilename`, `bIsActive`, `btID`, `uID`, `btCachedBlockRecord`)
VALUES
	(1,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:5:\"bID=1\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:1:\"1\";i:1;s:161:\"	<div id=\"newsflow-header-first-run\"><h1>Welcome to concrete5.</h1>\n						<h2>It\'s easy to edit content and add pages using in-context editing.</h2></div>\n						\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:1:\"1\";s:7:\"content\";s:161:\"	<div id=\"newsflow-header-first-run\"><h1>Welcome to concrete5.</h1>\n						<h2>It\'s easy to edit content and add pages using in-context editing.</h2></div>\n						\";}'),
	(2,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:5:\"bID=2\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:1:\"2\";i:1;s:327:\"<div class=\"newsflow-column-first-run\">\n							<h3>Building Your Own Site</h3>\n							<p>Editing with concrete5 is a breeze. Just point and click to make changes.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/editors\')\" class=\"btn primary\">Editor\'s Guide</a></p>\n							</div>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:1:\"2\";s:7:\"content\";s:327:\"<div class=\"newsflow-column-first-run\">\n							<h3>Building Your Own Site</h3>\n							<p>Editing with concrete5 is a breeze. Just point and click to make changes.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/editors\')\" class=\"btn primary\">Editor\'s Guide</a></p>\n							</div>\";}'),
	(3,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:5:\"bID=3\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:1:\"3\";i:1;s:368:\"<div class=\"newsflow-column-first-run\">\n							<h3>Developing Applications</h3>\n							<p>If you’re comfortable in PHP concrete5 should be a breeze to learn. Take a few moments to understand the architecture.</p>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/developers\')\" class=\"btn primary\">Developer\'s Guide</a></p>\n							</div>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:1:\"3\";s:7:\"content\";s:368:\"<div class=\"newsflow-column-first-run\">\n							<h3>Developing Applications</h3>\n							<p>If you’re comfortable in PHP concrete5 should be a breeze to learn. Take a few moments to understand the architecture.</p>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/developers\')\" class=\"btn primary\">Developer\'s Guide</a></p>\n							</div>\";}'),
	(4,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:5:\"bID=4\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:1:\"4\";i:1;s:323:\"<div class=\"newsflow-column-first-run\">\n							<h3>Designing Websites</h3>\n							<p>Good with CSS and HTML? You can easily theme anything with concrete5.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/designers\')\" class=\"btn primary\">Designer\'s Guide</a></p>\n							</div>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:1:\"4\";s:7:\"content\";s:323:\"<div class=\"newsflow-column-first-run\">\n							<h3>Designing Websites</h3>\n							<p>Good with CSS and HTML? You can easily theme anything with concrete5.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/designers\')\" class=\"btn primary\">Designer\'s Guide</a></p>\n							</div>\";}'),
	(5,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:5:\"bID=5\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:1:\"5\";i:1;s:346:\"\n						<div class=\"newsflow-column-first-run\">\n						<h3>Business Background</h3>\n						<p>Worried about license structures, white-labeling or why concrete5 is a good choice for your agency?</p>\n						<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/executives\')\" class=\"btn primary\">Executive\'s Guide</a></p>\n						</div>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:1:\"5\";s:7:\"content\";s:346:\"\n						<div class=\"newsflow-column-first-run\">\n						<h3>Business Background</h3>\n						<p>Worried about license structures, white-labeling or why concrete5 is a good choice for your agency?</p>\n						<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/executives\')\" class=\"btn primary\">Executive\'s Guide</a></p>\n						</div>\";}'),
	(6,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',6,1,NULL),
	(7,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',7,1,NULL),
	(8,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',5,1,NULL),
	(9,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',5,1,NULL),
	(10,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',4,1,NULL),
	(11,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',3,1,NULL),
	(12,'','2013-04-27 15:01:44','2013-04-27 15:01:44',NULL,'1',5,1,NULL),
	(13,'Blog Content','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=13\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"13\";i:1;s:34:\"<p>This is my first blog post.</p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"13\";s:7:\"content\";s:34:\"<p>This is my first blog post.</p>\";}'),
	(14,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',25,1,'O:11:\"BlockRecord\":13:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:6:\"btTags\";s:8:\"_tableat\";s:6:\"btTags\";s:6:\"_where\";s:6:\"bID=14\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:5:{i:0;s:2:\"14\";i:1;s:4:\"Tags\";i:2;s:3:\"133\";i:3;s:4:\"page\";i:4;s:1:\"0\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"14\";s:5:\"title\";s:4:\"Tags\";s:9:\"targetCID\";s:3:\"133\";s:11:\"displayMode\";s:4:\"page\";s:10:\"cloudCount\";s:1:\"0\";}'),
	(15,'Thumbnail Image','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";s:6:\"bID=15\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"15\";i:1;s:1:\"8\";i:2;s:1:\"0\";i:3;s:1:\"0\";i:4;s:1:\"0\";i:5;s:0:\"\";i:6;s:1:\"0\";i:7;N;i:8;s:0:\"\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"15\";s:3:\"fID\";s:1:\"8\";s:10:\"fOnstateID\";s:1:\"0\";s:8:\"maxWidth\";s:1:\"0\";s:9:\"maxHeight\";s:1:\"0\";s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";s:1:\"0\";s:27:\"forceImageToMatchDimensions\";N;s:7:\"altText\";s:0:\"\";}'),
	(16,'Header Image','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";s:6:\"bID=16\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"16\";i:1;s:1:\"2\";i:2;s:1:\"0\";i:3;s:3:\"960\";i:4;s:3:\"212\";i:5;s:0:\"\";i:6;s:1:\"0\";i:7;s:1:\"1\";i:8;s:17:\"My concrete5 Blog\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"16\";s:3:\"fID\";s:1:\"2\";s:10:\"fOnstateID\";s:1:\"0\";s:8:\"maxWidth\";s:3:\"960\";s:9:\"maxHeight\";s:3:\"212\";s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";s:1:\"0\";s:27:\"forceImageToMatchDimensions\";s:1:\"1\";s:7:\"altText\";s:17:\"My concrete5 Blog\";}'),
	(17,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',18,1,NULL),
	(18,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";s:6:\"bID=18\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"18\";i:1;s:1:\"6\";i:2;s:1:\"0\";i:3;s:3:\"960\";i:4;s:3:\"212\";i:5;s:0:\"\";i:6;s:1:\"0\";i:7;s:1:\"1\";i:8;s:0:\"\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"18\";s:3:\"fID\";s:1:\"6\";s:10:\"fOnstateID\";s:1:\"0\";s:8:\"maxWidth\";s:3:\"960\";s:9:\"maxHeight\";s:3:\"212\";s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";s:1:\"0\";s:27:\"forceImageToMatchDimensions\";s:1:\"1\";s:7:\"altText\";s:0:\"\";}'),
	(19,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";s:6:\"bID=19\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"19\";i:1;s:1:\"4\";i:2;s:1:\"0\";i:3;s:3:\"960\";i:4;s:3:\"212\";i:5;s:0:\"\";i:6;s:1:\"0\";i:7;s:1:\"1\";i:8;s:0:\"\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"19\";s:3:\"fID\";s:1:\"4\";s:10:\"fOnstateID\";s:1:\"0\";s:8:\"maxWidth\";s:3:\"960\";s:9:\"maxHeight\";s:3:\"212\";s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";s:1:\"0\";s:27:\"forceImageToMatchDimensions\";s:1:\"1\";s:7:\"altText\";s:0:\"\";}'),
	(20,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',8,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:12:\"btNavigation\";s:8:\"_tableat\";s:12:\"btNavigation\";s:6:\"_where\";s:6:\"bID=20\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"20\";i:1;s:11:\"display_asc\";i:2;s:3:\"top\";i:3;s:1:\"0\";i:4;s:1:\"0\";i:5;s:4:\"none\";i:6;s:6:\"enough\";i:7;s:1:\"0\";i:8;s:1:\"0\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"20\";s:7:\"orderBy\";s:11:\"display_asc\";s:12:\"displayPages\";s:3:\"top\";s:15:\"displayPagesCID\";s:1:\"0\";s:23:\"displayPagesIncludeSelf\";s:1:\"0\";s:15:\"displaySubPages\";s:4:\"none\";s:20:\"displaySubPageLevels\";s:6:\"enough\";s:23:\"displaySubPageLevelsNum\";s:1:\"0\";s:23:\"displayUnavailablePages\";s:1:\"0\";}'),
	(21,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=21\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"21\";i:1;s:15:\"<h3>Links:</h3>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"21\";s:7:\"content\";s:15:\"<h3>Links:</h3>\";}'),
	(22,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',8,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:12:\"btNavigation\";s:8:\"_tableat\";s:12:\"btNavigation\";s:6:\"_where\";s:6:\"bID=22\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"22\";i:1;s:11:\"display_asc\";i:2;s:12:\"second_level\";i:3;s:1:\"0\";i:4;s:1:\"0\";i:5;s:3:\"all\";i:6;s:3:\"all\";i:7;s:1:\"0\";i:8;s:1:\"0\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"22\";s:7:\"orderBy\";s:11:\"display_asc\";s:12:\"displayPages\";s:12:\"second_level\";s:15:\"displayPagesCID\";s:1:\"0\";s:23:\"displayPagesIncludeSelf\";s:1:\"0\";s:15:\"displaySubPages\";s:3:\"all\";s:20:\"displaySubPageLevels\";s:3:\"all\";s:23:\"displaySubPageLevelsNum\";s:1:\"0\";s:23:\"displayUnavailablePages\";s:1:\"0\";}'),
	(23,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=23\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"23\";i:1;s:133:\"<h1><a title=\"Home\" \n                                	href=\"{CCM:CID_1}\"\n                                >Fanning Landscapes</a></h1>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"23\";s:7:\"content\";s:133:\"<h1><a title=\"Home\" \n                                	href=\"{CCM:CID_1}\"\n                                >Fanning Landscapes</a></h1>\";}'),
	(24,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=24\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"24\";i:1;s:16:\"<h3>Sidebar</h3>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"24\";s:7:\"content\";s:16:\"<h3>Sidebar</h3>\";}'),
	(25,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=25\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"25\";i:1;s:343:\"<p>Everything about concrete5 is completely customizable through the CMS. This is a separate area from the main content on the homepage. You can&nbsp;<a title=\"Move blocks in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/blocks-and-areas\" target=\"_blank\">drag and drop blocks</a>&nbsp;like this around your layout.</p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"25\";s:7:\"content\";s:343:\"<p>Everything about concrete5 is completely customizable through the CMS. This is a separate area from the main content on the homepage. You can&nbsp;<a title=\"Move blocks in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/blocks-and-areas\" target=\"_blank\">drag and drop blocks</a>&nbsp;like this around your layout.</p>\";}'),
	(26,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=26\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"26\";i:1;s:1592:\"<h2>Welcome to concrete5!</h2>\n                                        <p>Content Management is easy with concrete5\'s in-context editing. Just <a href=\"{CCM:CID_110}\">login</a> and you can change things as you browse your site.</p>\n                                        <p>You can watch videos and learn how to:</p>\n                                        <ul>\n                                        <li><a title=\"In-context editing CMS\" href=\"http://www.concrete5.org/documentation/general-topics/in-context-editing/\" target=\"_blank\">Edit</a>&nbsp;this page.</li>\n                                        <li>Add a <a title=\"Add a page in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add-a-page/\" target=\"_blank\">new page</a>.</li>\n                                        <li>Add some basic functionality, like&nbsp;<a title=\"Add a simple form in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add_a_form\" target=\"_blank\">a Form</a>.</li>\n                                        <li><a title=\"add-on marketplace for concrete5\" href=\"http://www.concrete5.org/marketplace/how_to_install_add_ons_and_themes_/\" target=\"_blank\">Finding &amp; adding</a>&nbsp;more functionality and themes.</li>\n                                        </ul>\n                                        <p>We\'ve taken the liberty to build out the rest of this site with some sample content that will help you learn concrete5. Wander around a bit, or click Dashboard to get to the&nbsp;<a href=\"{CCM:CID_6}\">Sitemap</a> and quickly delete the parts you don\'t want.</p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"26\";s:7:\"content\";s:1592:\"<h2>Welcome to concrete5!</h2>\n                                        <p>Content Management is easy with concrete5\'s in-context editing. Just <a href=\"{CCM:CID_110}\">login</a> and you can change things as you browse your site.</p>\n                                        <p>You can watch videos and learn how to:</p>\n                                        <ul>\n                                        <li><a title=\"In-context editing CMS\" href=\"http://www.concrete5.org/documentation/general-topics/in-context-editing/\" target=\"_blank\">Edit</a>&nbsp;this page.</li>\n                                        <li>Add a <a title=\"Add a page in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add-a-page/\" target=\"_blank\">new page</a>.</li>\n                                        <li>Add some basic functionality, like&nbsp;<a title=\"Add a simple form in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add_a_form\" target=\"_blank\">a Form</a>.</li>\n                                        <li><a title=\"add-on marketplace for concrete5\" href=\"http://www.concrete5.org/marketplace/how_to_install_add_ons_and_themes_/\" target=\"_blank\">Finding &amp; adding</a>&nbsp;more functionality and themes.</li>\n                                        </ul>\n                                        <p>We\'ve taken the liberty to build out the rest of this site with some sample content that will help you learn concrete5. Wander around a bit, or click Dashboard to get to the&nbsp;<a href=\"{CCM:CID_6}\">Sitemap</a> and quickly delete the parts you don\'t want.</p>\";}'),
	(27,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";s:6:\"bID=27\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"27\";i:1;s:1:\"1\";i:2;s:1:\"0\";i:3;s:3:\"960\";i:4;s:3:\"212\";i:5;s:0:\"\";i:6;s:1:\"0\";i:7;s:1:\"1\";i:8;s:0:\"\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"27\";s:3:\"fID\";s:1:\"1\";s:10:\"fOnstateID\";s:1:\"0\";s:8:\"maxWidth\";s:3:\"960\";s:9:\"maxHeight\";s:3:\"212\";s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";s:1:\"0\";s:27:\"forceImageToMatchDimensions\";s:1:\"1\";s:7:\"altText\";s:0:\"\";}'),
	(28,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',2,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:18:\"btCoreStackDisplay\";s:8:\"_tableat\";s:18:\"btCoreStackDisplay\";s:6:\"_where\";s:6:\"bID=28\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"28\";i:1;s:3:\"122\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"28\";s:4:\"stID\";s:3:\"122\";}'),
	(29,'','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=29\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"29\";i:1;s:1739:\"<h2>Learn More</h2>\n																<p>Visit&nbsp;<a title=\"concrete5 Content Management System\" href=\"http://www.concrete5.org/\" target=\"_blank\">concrete5.org</a>&nbsp;to learn more from the&nbsp;<a title=\"open source content management system\" href=\"http://www.concrete5.org/community\" target=\"_blank\">community</a>&nbsp;and the&nbsp;<a href=\"http://www.concrete5.org/documentation/general-topics/\" target=\"_blank\">documentation</a>. You can also browse our&nbsp;<a title=\"concrete5 marketplace\" href=\"http://www.concrete5.org/marketplace/\" target=\"_blank\">marketplace</a>&nbsp;for more&nbsp;<a title=\"Add-ons for concrete5\" href=\"http://www.concrete5.org/marketplace/addons/\" target=\"_blank\">add-ons</a>&nbsp;and&nbsp;<a title=\"Themes for concrete5\" href=\"http://www.concrete5.org/marketplace/themes/\" target=\"_blank\">themes</a>&nbsp;to quickly build the site you really need.&nbsp;</p>\n																<h3>&nbsp;</h3>\n																<h3>Getting Help</h3>\n																<p>You can get free help in the <a href=\"http://www.concrete5.org/community/forums/\" target=\"_blank\">forums</a> and post for free to the&nbsp;<a href=\"http://www.concrete5.org/community/forums/jobs1/\" target=\"_blank\">jobs board</a>.&nbsp;</p>\n																<p>You can also pay the concrete5 team of developers to help with&nbsp;<a href=\"http://www.concrete5.org/services/support/\" target=\"_blank\">any problem</a>&nbsp;you run into. We offer <a href=\"http://www.concrete5.org/services/training/\" target=\"_blank\">training courses</a>&nbsp;and&nbsp;<a href=\"http://www.concrete5.org/services/hosting/\" target=\"_blank\">hosting packages</a>, just let us know <a href=\"http://www.concrete5.org/services/professional_services/\" target=\"_blank\">how we can help</a>.</p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"29\";s:7:\"content\";s:1739:\"<h2>Learn More</h2>\n																<p>Visit&nbsp;<a title=\"concrete5 Content Management System\" href=\"http://www.concrete5.org/\" target=\"_blank\">concrete5.org</a>&nbsp;to learn more from the&nbsp;<a title=\"open source content management system\" href=\"http://www.concrete5.org/community\" target=\"_blank\">community</a>&nbsp;and the&nbsp;<a href=\"http://www.concrete5.org/documentation/general-topics/\" target=\"_blank\">documentation</a>. You can also browse our&nbsp;<a title=\"concrete5 marketplace\" href=\"http://www.concrete5.org/marketplace/\" target=\"_blank\">marketplace</a>&nbsp;for more&nbsp;<a title=\"Add-ons for concrete5\" href=\"http://www.concrete5.org/marketplace/addons/\" target=\"_blank\">add-ons</a>&nbsp;and&nbsp;<a title=\"Themes for concrete5\" href=\"http://www.concrete5.org/marketplace/themes/\" target=\"_blank\">themes</a>&nbsp;to quickly build the site you really need.&nbsp;</p>\n																<h3>&nbsp;</h3>\n																<h3>Getting Help</h3>\n																<p>You can get free help in the <a href=\"http://www.concrete5.org/community/forums/\" target=\"_blank\">forums</a> and post for free to the&nbsp;<a href=\"http://www.concrete5.org/community/forums/jobs1/\" target=\"_blank\">jobs board</a>.&nbsp;</p>\n																<p>You can also pay the concrete5 team of developers to help with&nbsp;<a href=\"http://www.concrete5.org/services/support/\" target=\"_blank\">any problem</a>&nbsp;you run into. We offer <a href=\"http://www.concrete5.org/services/training/\" target=\"_blank\">training courses</a>&nbsp;and&nbsp;<a href=\"http://www.concrete5.org/services/hosting/\" target=\"_blank\">hosting packages</a>, just let us know <a href=\"http://www.concrete5.org/services/professional_services/\" target=\"_blank\">how we can help</a>.</p>\";}'),
	(30,'','2013-04-27 15:01:47','2013-04-27 15:01:48',NULL,'1',2,1,NULL),
	(31,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',16,1,NULL),
	(32,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',2,1,NULL),
	(33,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',9,1,NULL),
	(34,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',14,1,NULL),
	(35,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=35\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"35\";i:1;s:17:\"<h3>Site Map</h3>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"35\";s:7:\"content\";s:17:\"<h3>Site Map</h3>\";}'),
	(36,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',8,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:12:\"btNavigation\";s:8:\"_tableat\";s:12:\"btNavigation\";s:6:\"_where\";s:6:\"bID=36\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"36\";i:1;s:11:\"display_asc\";i:2;s:3:\"top\";i:3;s:1:\"0\";i:4;s:1:\"0\";i:5;s:3:\"all\";i:6;s:3:\"all\";i:7;s:1:\"0\";i:8;s:1:\"0\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"36\";s:7:\"orderBy\";s:11:\"display_asc\";s:12:\"displayPages\";s:3:\"top\";s:15:\"displayPagesCID\";s:1:\"0\";s:23:\"displayPagesIncludeSelf\";s:1:\"0\";s:15:\"displaySubPages\";s:3:\"all\";s:20:\"displaySubPageLevels\";s:3:\"all\";s:23:\"displaySubPageLevelsNum\";s:1:\"0\";s:23:\"displayUnavailablePages\";s:1:\"0\";}'),
	(37,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',22,1,NULL),
	(38,'','2013-04-27 15:01:48','2013-04-27 15:01:48','blog_index_thumbnail.php','1',20,1,NULL),
	(39,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',9,1,NULL),
	(40,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',25,1,NULL),
	(41,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',28,1,NULL),
	(42,'Header Image','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',18,1,NULL),
	(43,'Blog Content','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',9,1,NULL),
	(44,'Thumbnail Image','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',18,1,NULL),
	(45,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',22,1,NULL),
	(46,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',25,1,NULL),
	(47,'','2013-04-27 15:01:48','2013-04-27 15:01:48',NULL,'1',28,1,NULL),
	(48,'Header Image','2013-04-27 20:01:23','2013-04-27 20:01:32',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"48\";i:1;s:1:\"2\";i:2;i:0;i:3;i:0;i:4;i:0;i:5;s:0:\"\";i:6;i:0;i:7;N;i:8;N;}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"48\";s:3:\"fID\";s:1:\"2\";s:10:\"fOnstateID\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";i:0;s:27:\"forceImageToMatchDimensions\";N;s:7:\"altText\";N;}'),
	(49,'Thumbnail Image','2013-04-27 20:01:23','2013-04-27 20:01:32',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"49\";i:1;s:1:\"8\";i:2;i:0;i:3;i:0;i:4;i:0;i:5;s:0:\"\";i:6;i:0;i:7;N;i:8;N;}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"49\";s:3:\"fID\";s:1:\"8\";s:10:\"fOnstateID\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";i:0;s:27:\"forceImageToMatchDimensions\";N;s:7:\"altText\";N;}'),
	(50,'Blog Content','2013-04-27 20:01:23','2013-04-27 20:01:32',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"50\";i:1;s:34:\"<p>This is my first blog post.</p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"50\";s:7:\"content\";s:34:\"<p>This is my first blog post.</p>\";}'),
	(51,NULL,'2013-04-27 20:07:31','2013-04-27 20:07:31',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"51\";i:1;s:18:\"<p>Rock Solid.</p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"51\";s:7:\"content\";s:18:\"<p>Rock Solid.</p>\";}'),
	(52,NULL,'2013-04-27 20:32:12','2013-04-27 20:32:12',NULL,'1',29,1,NULL),
	(53,NULL,'2013-04-27 20:33:27','2013-04-27 20:33:27',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"53\";i:1;s:624:\"<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"53\";s:7:\"content\";s:624:\"<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>\";}'),
	(54,NULL,'2013-04-27 20:35:20','2013-04-27 20:35:20',NULL,'1',14,1,NULL),
	(55,NULL,'2013-04-27 21:08:02','2013-04-27 21:08:02',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"55\";i:1;s:554:\"<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"55\";s:7:\"content\";s:554:\"<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>\";}'),
	(56,NULL,'2013-04-27 21:10:40','2013-04-27 21:10:40',NULL,'1',18,1,'O:11:\"BlockRecord\":17:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentImage\";s:8:\"_tableat\";s:14:\"btContentImage\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:9:{i:0;s:2:\"56\";i:1;s:2:\"17\";i:2;s:1:\"0\";i:3;i:0;i:4;i:0;i:5;s:0:\"\";i:6;s:1:\"1\";i:7;s:1:\"0\";i:8;s:4:\"Home\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"56\";s:3:\"fID\";s:2:\"17\";s:10:\"fOnstateID\";s:1:\"0\";s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:12:\"externalLink\";s:0:\"\";s:15:\"internalLinkCID\";s:1:\"1\";s:27:\"forceImageToMatchDimensions\";s:1:\"0\";s:7:\"altText\";s:4:\"Home\";}'),
	(57,NULL,'2013-04-27 21:37:36','2013-04-27 21:37:36',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";N;s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"57\";i:1;s:106:\"<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"57\";s:7:\"content\";s:106:\"<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>\";}'),
	(58,NULL,'2013-04-27 21:41:13','2013-04-27 21:41:13',NULL,'1',14,1,NULL),
	(59,NULL,'2013-04-27 21:43:57','2013-04-27 21:43:57',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=59\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"59\";i:1;s:106:\"<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"59\";s:7:\"content\";s:106:\"<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>\";}'),
	(60,NULL,'2013-04-27 21:46:03','2013-04-27 21:46:03',NULL,'1',14,1,NULL),
	(61,NULL,'2013-04-27 21:46:15','2013-04-27 21:46:15',NULL,'1',9,1,'O:11:\"BlockRecord\":10:{s:5:\"_dbat\";i:1;s:6:\"_table\";s:14:\"btContentLocal\";s:8:\"_tableat\";s:14:\"btContentLocal\";s:6:\"_where\";s:6:\"bID=61\";s:6:\"_saved\";b:1;s:8:\"_lasterr\";b:0;s:9:\"_original\";a:2:{i:0;s:2:\"61\";i:1;s:106:\"<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>\";}s:11:\"foreignName\";s:11:\"blockrecord\";s:3:\"bID\";s:2:\"61\";s:7:\"content\";s:106:\"<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>\";}'),
	(62,NULL,'2013-04-27 21:47:30','2013-04-27 21:48:46',NULL,'1',29,1,NULL);

/*!40000 ALTER TABLE `Blocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlockTypePermissionBlockTypeAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlockTypePermissionBlockTypeAccessList`;

CREATE TABLE `BlockTypePermissionBlockTypeAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table BlockTypePermissionBlockTypeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlockTypePermissionBlockTypeAccessListCustom`;

CREATE TABLE `BlockTypePermissionBlockTypeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `btID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`btID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table BlockTypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlockTypes`;

CREATE TABLE `BlockTypes` (
  `btID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `btHandle` varchar(32) NOT NULL,
  `btName` varchar(128) NOT NULL,
  `btDescription` text,
  `btActiveWhenAdded` tinyint(1) NOT NULL DEFAULT '1',
  `btCopyWhenPropagate` tinyint(1) NOT NULL DEFAULT '0',
  `btIncludeAll` tinyint(1) NOT NULL DEFAULT '0',
  `btIsInternal` tinyint(1) NOT NULL DEFAULT '0',
  `btDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `btInterfaceWidth` int(10) unsigned NOT NULL DEFAULT '400',
  `btInterfaceHeight` int(10) unsigned NOT NULL DEFAULT '400',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`btID`),
  UNIQUE KEY `btHandle` (`btHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `BlockTypes` WRITE;
/*!40000 ALTER TABLE `BlockTypes` DISABLE KEYS */;

INSERT INTO `BlockTypes` (`btID`, `btHandle`, `btName`, `btDescription`, `btActiveWhenAdded`, `btCopyWhenPropagate`, `btIncludeAll`, `btIsInternal`, `btDisplayOrder`, `btInterfaceWidth`, `btInterfaceHeight`, `pkgID`)
VALUES
	(1,'core_scrapbook_display','Scrapbook Display (Core)','Proxy block for blocks pasted through the scrapbook.',1,0,0,1,0,400,400,0),
	(2,'core_stack_display','Stack Display (Core)','Proxy block for stacks added through the UI.',1,0,0,1,0,400,400,0),
	(3,'dashboard_featured_addon','Dashboard Featured Add-On','Features an add-on from concrete5.org.',1,0,0,1,0,300,100,0),
	(4,'dashboard_featured_theme','Dashboard Featured Theme','Features a theme from concrete5.org.',1,0,0,1,0,300,100,0),
	(5,'dashboard_newsflow_latest','Dashboard Newsflow Latest','Grabs the latest newsflow data from concrete5.org.',1,0,0,1,0,400,400,0),
	(6,'dashboard_app_status','Dashboard App Status','Displays update and welcome back information on your dashboard.',1,0,0,1,0,400,400,0),
	(7,'dashboard_site_activity','Dashboard Site Activity','Displays a summary of website activity.',1,0,0,1,0,400,400,0),
	(8,'autonav','Auto-Nav','Creates navigation trees and sitemaps.',1,0,0,0,1,500,350,0),
	(9,'content','Content','HTML/WYSIWYG Editor Content.',1,0,0,0,2,600,465,0),
	(10,'date_nav','Date Navigation','A collapsible date based navigation tree',1,0,0,0,3,500,350,0),
	(11,'external_form','External Form','Include external forms in the filesystem and place them on pages.',1,0,0,0,4,370,100,0),
	(12,'file','File','Link to files stored in the asset library.',1,0,0,0,5,300,250,0),
	(13,'flash_content','Flash Content','Embeds SWF files, including flash detection.',1,0,0,0,6,380,200,0),
	(14,'form','Form','Build simple forms and surveys.',1,0,0,0,7,420,430,0),
	(15,'google_map','Google Map','Enter an address and a Google Map of that location will be placed in your page.',1,0,0,0,8,400,200,0),
	(16,'guestbook','Guestbook / Comments','Adds blog-style comments (a guestbook) to your page.',1,0,1,0,9,350,480,0),
	(17,'html','HTML','For adding HTML by hand.',1,0,0,0,10,600,465,0),
	(18,'image','Image','Adds images and onstates from the library to pages.',1,0,0,0,11,400,550,0),
	(19,'next_previous','Next & Previous Nav','Navigate through sibling pages.',1,0,0,0,12,430,400,0),
	(20,'page_list','Page List','List pages based on type, area.',1,0,0,0,13,500,350,0),
	(21,'rss_displayer','RSS Displayer','Fetch, parse and display the contents of an RSS or Atom feed.',1,0,0,0,14,400,330,0),
	(22,'search','Search','Add a search box to your site.',1,0,0,0,15,400,240,0),
	(23,'slideshow','Slideshow','Display a running loop of images.',1,0,0,0,16,550,400,0),
	(24,'survey','Survey','Provide a simple survey, along with results in a pie chart format.',1,0,0,0,17,420,300,0),
	(25,'tags','Tags','List pages based on type, area.',1,0,0,0,18,450,260,0),
	(26,'video','Video Player','Embeds uploaded video into a web page. Supports AVI, WMV, Quicktime/MPEG4 and FLV formats.',1,0,0,0,19,320,220,0),
	(27,'youtube','YouTube Video','Embeds a YouTube Video in your web page.',1,0,0,0,20,400,210,0),
	(28,'date_archive','Blog Date Archive','Displays month archive for pages',1,0,0,0,21,500,350,0),
	(29,'sortable_fancybox_gallery','Sortable Fancybox Gallery','Displays images in a fileset (with an optional lightbox), and allows you to change their display order via drag-and-drop.',1,0,0,0,22,800,480,1);

/*!40000 ALTER TABLE `BlockTypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btContentFile
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btContentFile`;

CREATE TABLE `btContentFile` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `fileLinkText` varchar(255) DEFAULT NULL,
  `filePassword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btContentImage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btContentImage`;

CREATE TABLE `btContentImage` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT '0',
  `fOnstateID` int(10) unsigned DEFAULT '0',
  `maxWidth` int(10) unsigned DEFAULT '0',
  `maxHeight` int(10) unsigned DEFAULT '0',
  `externalLink` varchar(255) DEFAULT NULL,
  `internalLinkCID` int(10) unsigned DEFAULT '0',
  `forceImageToMatchDimensions` int(10) unsigned DEFAULT '0',
  `altText` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btContentImage` WRITE;
/*!40000 ALTER TABLE `btContentImage` DISABLE KEYS */;

INSERT INTO `btContentImage` (`bID`, `fID`, `fOnstateID`, `maxWidth`, `maxHeight`, `externalLink`, `internalLinkCID`, `forceImageToMatchDimensions`, `altText`)
VALUES
	(15,8,0,0,0,'',0,NULL,''),
	(16,2,0,960,212,'',0,1,'My concrete5 Blog'),
	(17,7,0,960,212,'',0,1,''),
	(18,6,0,960,212,'',0,1,''),
	(19,4,0,960,212,'',0,1,''),
	(27,1,0,960,212,'',0,1,''),
	(42,2,0,960,212,'',0,1,'My concrete5 Blog'),
	(44,8,0,0,0,'',0,NULL,''),
	(48,2,0,0,0,'',0,NULL,NULL),
	(49,8,0,0,0,'',0,NULL,NULL),
	(56,17,0,0,0,'',1,0,'Home');

/*!40000 ALTER TABLE `btContentImage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btContentLocal
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btContentLocal`;

CREATE TABLE `btContentLocal` (
  `bID` int(10) unsigned NOT NULL,
  `content` longtext,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btContentLocal` WRITE;
/*!40000 ALTER TABLE `btContentLocal` DISABLE KEYS */;

INSERT INTO `btContentLocal` (`bID`, `content`)
VALUES
	(1,'	<div id=\"newsflow-header-first-run\"><h1>Welcome to concrete5.</h1>\n						<h2>It\'s easy to edit content and add pages using in-context editing.</h2></div>\n						'),
	(2,'<div class=\"newsflow-column-first-run\">\n							<h3>Building Your Own Site</h3>\n							<p>Editing with concrete5 is a breeze. Just point and click to make changes.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/editors\')\" class=\"btn primary\">Editor\'s Guide</a></p>\n							</div>'),
	(3,'<div class=\"newsflow-column-first-run\">\n							<h3>Developing Applications</h3>\n							<p>If you’re comfortable in PHP concrete5 should be a breeze to learn. Take a few moments to understand the architecture.</p>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/developers\')\" class=\"btn primary\">Developer\'s Guide</a></p>\n							</div>'),
	(4,'<div class=\"newsflow-column-first-run\">\n							<h3>Designing Websites</h3>\n							<p>Good with CSS and HTML? You can easily theme anything with concrete5.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/designers\')\" class=\"btn primary\">Designer\'s Guide</a></p>\n							</div>'),
	(5,'\n						<div class=\"newsflow-column-first-run\">\n						<h3>Business Background</h3>\n						<p>Worried about license structures, white-labeling or why concrete5 is a good choice for your agency?</p>\n						<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/executives\')\" class=\"btn primary\">Executive\'s Guide</a></p>\n						</div>'),
	(13,'<p>This is my first blog post.</p>'),
	(21,'<h3>Links:</h3>'),
	(23,'<h1><a title=\"Home\" \n                                	href=\"{CCM:CID_1}\"\n                                >Fanning Landscapes</a></h1>'),
	(24,'<h3>Sidebar</h3>'),
	(25,'<p>Everything about concrete5 is completely customizable through the CMS. This is a separate area from the main content on the homepage. You can&nbsp;<a title=\"Move blocks in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/blocks-and-areas\" target=\"_blank\">drag and drop blocks</a>&nbsp;like this around your layout.</p>'),
	(26,'<h2>Welcome to concrete5!</h2>\n                                        <p>Content Management is easy with concrete5\'s in-context editing. Just <a href=\"{CCM:CID_110}\">login</a> and you can change things as you browse your site.</p>\n                                        <p>You can watch videos and learn how to:</p>\n                                        <ul>\n                                        <li><a title=\"In-context editing CMS\" href=\"http://www.concrete5.org/documentation/general-topics/in-context-editing/\" target=\"_blank\">Edit</a>&nbsp;this page.</li>\n                                        <li>Add a <a title=\"Add a page in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add-a-page/\" target=\"_blank\">new page</a>.</li>\n                                        <li>Add some basic functionality, like&nbsp;<a title=\"Add a simple form in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add_a_form\" target=\"_blank\">a Form</a>.</li>\n                                        <li><a title=\"add-on marketplace for concrete5\" href=\"http://www.concrete5.org/marketplace/how_to_install_add_ons_and_themes_/\" target=\"_blank\">Finding &amp; adding</a>&nbsp;more functionality and themes.</li>\n                                        </ul>\n                                        <p>We\'ve taken the liberty to build out the rest of this site with some sample content that will help you learn concrete5. Wander around a bit, or click Dashboard to get to the&nbsp;<a href=\"{CCM:CID_6}\">Sitemap</a> and quickly delete the parts you don\'t want.</p>'),
	(29,'<h2>Learn More</h2>\n																<p>Visit&nbsp;<a title=\"concrete5 Content Management System\" href=\"http://www.concrete5.org/\" target=\"_blank\">concrete5.org</a>&nbsp;to learn more from the&nbsp;<a title=\"open source content management system\" href=\"http://www.concrete5.org/community\" target=\"_blank\">community</a>&nbsp;and the&nbsp;<a href=\"http://www.concrete5.org/documentation/general-topics/\" target=\"_blank\">documentation</a>. You can also browse our&nbsp;<a title=\"concrete5 marketplace\" href=\"http://www.concrete5.org/marketplace/\" target=\"_blank\">marketplace</a>&nbsp;for more&nbsp;<a title=\"Add-ons for concrete5\" href=\"http://www.concrete5.org/marketplace/addons/\" target=\"_blank\">add-ons</a>&nbsp;and&nbsp;<a title=\"Themes for concrete5\" href=\"http://www.concrete5.org/marketplace/themes/\" target=\"_blank\">themes</a>&nbsp;to quickly build the site you really need.&nbsp;</p>\n																<h3>&nbsp;</h3>\n																<h3>Getting Help</h3>\n																<p>You can get free help in the <a href=\"http://www.concrete5.org/community/forums/\" target=\"_blank\">forums</a> and post for free to the&nbsp;<a href=\"http://www.concrete5.org/community/forums/jobs1/\" target=\"_blank\">jobs board</a>.&nbsp;</p>\n																<p>You can also pay the concrete5 team of developers to help with&nbsp;<a href=\"http://www.concrete5.org/services/support/\" target=\"_blank\">any problem</a>&nbsp;you run into. We offer <a href=\"http://www.concrete5.org/services/training/\" target=\"_blank\">training courses</a>&nbsp;and&nbsp;<a href=\"http://www.concrete5.org/services/hosting/\" target=\"_blank\">hosting packages</a>, just let us know <a href=\"http://www.concrete5.org/services/professional_services/\" target=\"_blank\">how we can help</a>.</p>'),
	(33,'<h2>Contact Us</h2>\n									<p>Building a form is easy to do. Learn how to <a href=\"http://www.concrete5.org/documentation/general-topics/add_a_form\" target=\"_blank\">add a form block</a>.</p>'),
	(35,'<h3>Site Map</h3>'),
	(39,'<h3>Tags</h3>'),
	(43,'<p>Here is some sample content! I\'m writing it using composer!</p>'),
	(50,'<p>This is my first blog post.</p>'),
	(51,'<p>Rock Solid.</p>'),
	(53,'<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>'),
	(55,'<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>'),
	(57,'<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>'),
	(59,'<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>'),
	(61,'<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>');

/*!40000 ALTER TABLE `btContentLocal` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btCoreScrapbookDisplay
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btCoreScrapbookDisplay`;

CREATE TABLE `btCoreScrapbookDisplay` (
  `bID` int(10) unsigned NOT NULL,
  `bOriginalID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`bID`),
  KEY `bOriginalID` (`bOriginalID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btCoreStackDisplay
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btCoreStackDisplay`;

CREATE TABLE `btCoreStackDisplay` (
  `bID` int(10) unsigned NOT NULL,
  `stID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btCoreStackDisplay` WRITE;
/*!40000 ALTER TABLE `btCoreStackDisplay` DISABLE KEYS */;

INSERT INTO `btCoreStackDisplay` (`bID`, `stID`)
VALUES
	(28,122),
	(30,122),
	(32,122);

/*!40000 ALTER TABLE `btCoreStackDisplay` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btDashboardNewsflowLatest
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btDashboardNewsflowLatest`;

CREATE TABLE `btDashboardNewsflowLatest` (
  `bID` int(10) unsigned NOT NULL,
  `slot` varchar(1) NOT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btDashboardNewsflowLatest` WRITE;
/*!40000 ALTER TABLE `btDashboardNewsflowLatest` DISABLE KEYS */;

INSERT INTO `btDashboardNewsflowLatest` (`bID`, `slot`)
VALUES
	(8,'A'),
	(9,'B'),
	(12,'C');

/*!40000 ALTER TABLE `btDashboardNewsflowLatest` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btDateArchive
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btDateArchive`;

CREATE TABLE `btDateArchive` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `targetCID` int(11) DEFAULT NULL,
  `numMonths` int(11) DEFAULT '12',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btDateArchive` WRITE;
/*!40000 ALTER TABLE `btDateArchive` DISABLE KEYS */;

INSERT INTO `btDateArchive` (`bID`, `title`, `targetCID`, `numMonths`)
VALUES
	(41,'Archives',133,12),
	(47,'Archives',133,12);

/*!40000 ALTER TABLE `btDateArchive` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btDateNav
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btDateNav`;

CREATE TABLE `btDateNav` (
  `bID` int(10) unsigned NOT NULL,
  `num` smallint(5) unsigned NOT NULL,
  `cParentID` int(10) unsigned NOT NULL DEFAULT '1',
  `cThis` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ctID` smallint(5) unsigned DEFAULT NULL,
  `flatDisplay` int(11) DEFAULT '0',
  `defaultNode` varchar(64) DEFAULT 'current_page',
  `truncateTitles` int(11) DEFAULT '0',
  `truncateSummaries` int(11) DEFAULT '0',
  `displayFeaturedOnly` int(11) DEFAULT '0',
  `truncateChars` int(11) DEFAULT '128',
  `truncateTitleChars` int(11) DEFAULT '128',
  `showDescriptions` int(11) DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btExternalForm
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btExternalForm`;

CREATE TABLE `btExternalForm` (
  `bID` int(10) unsigned NOT NULL,
  `filename` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btFlashContent
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btFlashContent`;

CREATE TABLE `btFlashContent` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `quality` varchar(255) DEFAULT NULL,
  `minVersion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btForm
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btForm`;

CREATE TABLE `btForm` (
  `bID` int(10) unsigned NOT NULL,
  `questionSetId` int(10) unsigned DEFAULT '0',
  `surveyName` varchar(255) DEFAULT NULL,
  `thankyouMsg` text,
  `notifyMeOnSubmission` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recipientEmail` varchar(255) DEFAULT NULL,
  `displayCaptcha` int(11) DEFAULT '1',
  `redirectCID` int(11) DEFAULT '0',
  `addFilesToSet` int(11) DEFAULT '0',
  PRIMARY KEY (`bID`),
  KEY `questionSetIdForeign` (`questionSetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btForm` WRITE;
/*!40000 ALTER TABLE `btForm` DISABLE KEYS */;

INSERT INTO `btForm` (`bID`, `questionSetId`, `surveyName`, `thankyouMsg`, `notifyMeOnSubmission`, `recipientEmail`, `displayCaptcha`, `redirectCID`, `addFilesToSet`)
VALUES
	(34,1367085708,'Contact Us','Thanks!',0,'',0,0,0),
	(54,1367105635,'Contact Us','Thanks! We\'ll get in touch within 24 to 48 hours.',1,'',1,0,0),
	(58,1367105635,'Contact Us','Thanks! We\'ll get in touch within 24 to 48 hours.',1,'',1,0,0),
	(60,1367105635,'Contact Us','Thanks! We\'ll get in touch within 24 to 48 hours.',1,'',1,0,0);

/*!40000 ALTER TABLE `btForm` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btFormAnswers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btFormAnswers`;

CREATE TABLE `btFormAnswers` (
  `aID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asID` int(10) unsigned DEFAULT '0',
  `msqID` int(10) unsigned DEFAULT '0',
  `answer` varchar(255) DEFAULT NULL,
  `answerLong` text,
  PRIMARY KEY (`aID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btFormAnswerSet
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btFormAnswerSet`;

CREATE TABLE `btFormAnswerSet` (
  `asID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `questionSetId` int(10) unsigned DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uID` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`asID`),
  KEY `questionSetId` (`questionSetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btFormQuestions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btFormQuestions`;

CREATE TABLE `btFormQuestions` (
  `qID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msqID` int(10) unsigned DEFAULT '0',
  `bID` int(10) unsigned DEFAULT '0',
  `questionSetId` int(10) unsigned DEFAULT '0',
  `question` varchar(255) DEFAULT NULL,
  `inputType` varchar(255) DEFAULT NULL,
  `options` text,
  `position` int(10) unsigned DEFAULT '1000',
  `width` int(10) unsigned DEFAULT '50',
  `height` int(10) unsigned DEFAULT '3',
  `required` int(11) DEFAULT '0',
  PRIMARY KEY (`qID`),
  KEY `questionSetId` (`questionSetId`),
  KEY `msqID` (`msqID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btFormQuestions` WRITE;
/*!40000 ALTER TABLE `btFormQuestions` DISABLE KEYS */;

INSERT INTO `btFormQuestions` (`qID`, `msqID`, `bID`, `questionSetId`, `question`, `inputType`, `options`, `position`, `width`, `height`, `required`)
VALUES
	(5,4,34,1367085708,'Name','field','',0,50,3,1),
	(6,5,34,1367085708,'Email:','email','',0,50,3,1),
	(7,6,34,1367085708,'What are you contacting us about?','radios','Question%%Comment%%Urgent Issue%%To Say Hello%%Other',0,50,3,1),
	(8,7,34,1367085708,'Message','text','',0,50,3,1),
	(9,8,54,1367105635,'Name','field','',0,50,3,1),
	(10,9,54,1367105635,'Email','email','a:1:{s:22:\"send_notification_from\";i:0;}',0,50,3,1),
	(11,10,54,1367105635,'Phone','telephone','',0,50,3,0),
	(12,11,54,1367105635,'Message','field','',0,50,3,0),
	(13,8,58,1367105635,'Name','field','',0,50,3,1),
	(14,9,58,1367105635,'Email','email','a:1:{s:22:\"send_notification_from\";i:0;}',0,50,3,1),
	(15,10,58,1367105635,'Phone','telephone','',0,50,3,0),
	(16,11,58,1367105635,'Message','field','',0,50,3,0),
	(17,8,60,1367105635,'Name','field','',0,50,3,1),
	(18,9,60,1367105635,'Email','email','a:1:{s:22:\"send_notification_from\";i:0;}',0,50,3,1),
	(19,10,60,1367105635,'Phone','telephone','',0,50,3,0),
	(20,11,60,1367105635,'Message','field','',0,50,3,0);

/*!40000 ALTER TABLE `btFormQuestions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btGoogleMap
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btGoogleMap`;

CREATE TABLE `btGoogleMap` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `zoom` int(8) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btGuestBook
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btGuestBook`;

CREATE TABLE `btGuestBook` (
  `bID` int(10) unsigned NOT NULL,
  `requireApproval` int(11) DEFAULT '0',
  `title` varchar(100) DEFAULT 'Comments',
  `dateFormat` varchar(100) DEFAULT NULL,
  `displayGuestBookForm` int(11) DEFAULT '1',
  `displayCaptcha` int(11) DEFAULT '1',
  `authenticationRequired` int(11) DEFAULT '0',
  `notifyEmail` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btGuestBook` WRITE;
/*!40000 ALTER TABLE `btGuestBook` DISABLE KEYS */;

INSERT INTO `btGuestBook` (`bID`, `requireApproval`, `title`, `dateFormat`, `displayGuestBookForm`, `displayCaptcha`, `authenticationRequired`, `notifyEmail`)
VALUES
	(31,0,'Tell us what you think','M jS, Y',1,1,0,'');

/*!40000 ALTER TABLE `btGuestBook` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btGuestBookEntries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btGuestBookEntries`;

CREATE TABLE `btGuestBookEntries` (
  `bID` int(11) DEFAULT NULL,
  `cID` int(11) DEFAULT '1',
  `entryID` int(11) NOT NULL AUTO_INCREMENT,
  `uID` int(11) DEFAULT '0',
  `commentText` longtext,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `entryDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `approved` int(11) DEFAULT '1',
  PRIMARY KEY (`entryID`),
  KEY `cID` (`cID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btNavigation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btNavigation`;

CREATE TABLE `btNavigation` (
  `bID` int(10) unsigned NOT NULL,
  `orderBy` varchar(255) DEFAULT 'alpha_asc',
  `displayPages` varchar(255) DEFAULT 'top',
  `displayPagesCID` int(10) unsigned NOT NULL DEFAULT '1',
  `displayPagesIncludeSelf` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `displaySubPages` varchar(255) DEFAULT 'none',
  `displaySubPageLevels` varchar(255) DEFAULT 'none',
  `displaySubPageLevelsNum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `displayUnavailablePages` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btNavigation` WRITE;
/*!40000 ALTER TABLE `btNavigation` DISABLE KEYS */;

INSERT INTO `btNavigation` (`bID`, `orderBy`, `displayPages`, `displayPagesCID`, `displayPagesIncludeSelf`, `displaySubPages`, `displaySubPageLevels`, `displaySubPageLevelsNum`, `displayUnavailablePages`)
VALUES
	(20,'display_asc','top',0,0,'none','enough',0,0),
	(22,'display_asc','second_level',0,0,'all','all',0,0),
	(36,'display_asc','top',0,0,'all','all',0,0);

/*!40000 ALTER TABLE `btNavigation` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btNextPrevious
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btNextPrevious`;

CREATE TABLE `btNextPrevious` (
  `bID` int(10) unsigned NOT NULL,
  `linkStyle` varchar(32) DEFAULT NULL,
  `nextLabel` varchar(128) DEFAULT NULL,
  `previousLabel` varchar(128) DEFAULT NULL,
  `parentLabel` varchar(128) DEFAULT NULL,
  `showArrows` int(11) DEFAULT '1',
  `loopSequence` int(11) DEFAULT '1',
  `excludeSystemPages` int(11) DEFAULT '1',
  `orderBy` varchar(20) DEFAULT 'display_asc',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btPageList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btPageList`;

CREATE TABLE `btPageList` (
  `bID` int(10) unsigned NOT NULL,
  `num` smallint(5) unsigned NOT NULL,
  `orderBy` varchar(32) DEFAULT NULL,
  `cParentID` int(10) unsigned NOT NULL DEFAULT '1',
  `cThis` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `includeAllDescendents` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `paginate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `displayAliases` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ctID` smallint(5) unsigned DEFAULT NULL,
  `rss` int(11) DEFAULT '0',
  `rssTitle` varchar(255) DEFAULT NULL,
  `rssDescription` longtext,
  `truncateSummaries` int(11) DEFAULT '0',
  `displayFeaturedOnly` int(11) DEFAULT '0',
  `truncateChars` int(11) DEFAULT '128',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btPageList` WRITE;
/*!40000 ALTER TABLE `btPageList` DISABLE KEYS */;

INSERT INTO `btPageList` (`bID`, `num`, `orderBy`, `cParentID`, `cThis`, `includeAllDescendents`, `paginate`, `displayAliases`, `ctID`, `rss`, `rssTitle`, `rssDescription`, `truncateSummaries`, `displayFeaturedOnly`, `truncateChars`)
VALUES
	(38,12,'chrono_desc',129,0,0,1,0,4,0,'','',1,0,128);

/*!40000 ALTER TABLE `btPageList` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btRssDisplay
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btRssDisplay`;

CREATE TABLE `btRssDisplay` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `dateFormat` varchar(100) DEFAULT NULL,
  `itemsToDisplay` int(10) unsigned DEFAULT '5',
  `showSummary` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `launchInNewWindow` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btSearch
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSearch`;

CREATE TABLE `btSearch` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `buttonText` varchar(128) DEFAULT NULL,
  `baseSearchPath` varchar(255) DEFAULT NULL,
  `postTo_cID` varchar(255) DEFAULT NULL,
  `resultsURL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btSearch` WRITE;
/*!40000 ALTER TABLE `btSearch` DISABLE KEYS */;

INSERT INTO `btSearch` (`bID`, `title`, `buttonText`, `baseSearchPath`, `postTo_cID`, `resultsURL`)
VALUES
	(37,'Search This Site','Search','','',''),
	(45,'Search Blog','Search','/blog','','');

/*!40000 ALTER TABLE `btSearch` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btSlideshow
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSlideshow`;

CREATE TABLE `btSlideshow` (
  `bID` int(10) unsigned NOT NULL,
  `fsID` int(10) unsigned DEFAULT NULL,
  `playback` varchar(50) DEFAULT NULL,
  `duration` int(10) unsigned DEFAULT NULL,
  `fadeDuration` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btSlideshowImg
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSlideshowImg`;

CREATE TABLE `btSlideshowImg` (
  `slideshowImgId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(10) unsigned DEFAULT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `duration` int(10) unsigned DEFAULT NULL,
  `fadeDuration` int(10) unsigned DEFAULT NULL,
  `groupSet` int(10) unsigned DEFAULT NULL,
  `position` int(10) unsigned DEFAULT NULL,
  `imgHeight` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`slideshowImgId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btSortableFancyboxGallery
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSortableFancyboxGallery`;

CREATE TABLE `btSortableFancyboxGallery` (
  `bID` int(10) unsigned NOT NULL,
  `fsID` int(10) unsigned DEFAULT NULL,
  `fullWidth` int(10) unsigned DEFAULT NULL,
  `fullHeight` int(10) unsigned DEFAULT NULL,
  `displayColumns` int(10) unsigned DEFAULT NULL,
  `enableLightbox` tinyint(4) DEFAULT '1',
  `lightboxTransitionEffect` varchar(10) DEFAULT 'fade',
  `lightboxTitlePosition` varchar(10) DEFAULT 'inside',
  `thumbWidth` int(10) unsigned DEFAULT NULL,
  `thumbHeight` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btSortableFancyboxGallery` WRITE;
/*!40000 ALTER TABLE `btSortableFancyboxGallery` DISABLE KEYS */;

INSERT INTO `btSortableFancyboxGallery` (`bID`, `fsID`, `fullWidth`, `fullHeight`, `displayColumns`, `enableLightbox`, `lightboxTransitionEffect`, `lightboxTitlePosition`, `thumbWidth`, `thumbHeight`)
VALUES
	(52,1,800,600,4,1,'fade','outside',150,150),
	(62,1,800,600,4,1,'fade','outside',150,150);

/*!40000 ALTER TABLE `btSortableFancyboxGallery` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btSortableFancyboxGalleryPositions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSortableFancyboxGalleryPositions`;

CREATE TABLE `btSortableFancyboxGalleryPositions` (
  `bID` int(10) unsigned DEFAULT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `position` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btSortableFancyboxGalleryPositions` WRITE;
/*!40000 ALTER TABLE `btSortableFancyboxGalleryPositions` DISABLE KEYS */;

INSERT INTO `btSortableFancyboxGalleryPositions` (`bID`, `fID`, `position`)
VALUES
	(52,16,1),
	(52,15,2),
	(52,14,3),
	(52,13,4),
	(52,12,5),
	(52,11,6),
	(52,10,7),
	(52,9,8),
	(62,16,1),
	(62,15,2),
	(62,14,3),
	(62,13,4),
	(62,12,5),
	(62,11,6),
	(62,10,7),
	(62,9,8);

/*!40000 ALTER TABLE `btSortableFancyboxGalleryPositions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btSurvey
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSurvey`;

CREATE TABLE `btSurvey` (
  `bID` int(10) unsigned NOT NULL,
  `question` varchar(255) DEFAULT '',
  `requiresRegistration` int(11) DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btSurveyOptions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSurveyOptions`;

CREATE TABLE `btSurveyOptions` (
  `optionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(11) DEFAULT NULL,
  `optionName` varchar(255) DEFAULT NULL,
  `displayOrder` int(11) DEFAULT '0',
  PRIMARY KEY (`optionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btSurveyResults
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btSurveyResults`;

CREATE TABLE `btSurveyResults` (
  `resultID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `optionID` int(10) unsigned DEFAULT '0',
  `uID` int(10) unsigned DEFAULT '0',
  `bID` int(11) DEFAULT NULL,
  `cID` int(11) DEFAULT NULL,
  `ipAddress` varchar(128) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`resultID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btTags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btTags`;

CREATE TABLE `btTags` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `targetCID` int(11) DEFAULT NULL,
  `displayMode` varchar(20) DEFAULT 'page',
  `cloudCount` int(11) DEFAULT '10',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `btTags` WRITE;
/*!40000 ALTER TABLE `btTags` DISABLE KEYS */;

INSERT INTO `btTags` (`bID`, `title`, `targetCID`, `displayMode`, `cloudCount`)
VALUES
	(14,'Tags',133,'page',0),
	(40,'',133,'cloud',0),
	(46,'Tags',133,'cloud',0);

/*!40000 ALTER TABLE `btTags` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table btVideo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btVideo`;

CREATE TABLE `btVideo` (
  `bID` int(10) unsigned NOT NULL,
  `fID` int(10) unsigned DEFAULT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table btYouTube
# ------------------------------------------------------------

DROP TABLE IF EXISTS `btYouTube`;

CREATE TABLE `btYouTube` (
  `bID` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `videoURL` varchar(255) DEFAULT NULL,
  `vHeight` varchar(255) DEFAULT NULL,
  `vWidth` varchar(255) DEFAULT NULL,
  `vPlayer` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table CollectionAttributeValues
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionAttributeValues`;

CREATE TABLE `CollectionAttributeValues` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`akID`,`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `CollectionAttributeValues` WRITE;
/*!40000 ALTER TABLE `CollectionAttributeValues` DISABLE KEYS */;

INSERT INTO `CollectionAttributeValues` (`cID`, `cvID`, `akID`, `avID`)
VALUES
	(3,1,3,1),
	(3,1,4,2),
	(4,1,3,3),
	(4,1,4,4),
	(5,1,3,5),
	(5,1,4,6),
	(6,1,3,7),
	(7,1,3,8),
	(7,1,4,9),
	(8,1,3,10),
	(8,1,4,11),
	(9,1,3,12),
	(9,1,4,13),
	(11,1,3,14),
	(11,1,4,15),
	(12,1,3,16),
	(12,1,4,17),
	(13,1,3,18),
	(13,1,4,19),
	(14,1,3,21),
	(14,1,4,22),
	(14,1,5,20),
	(15,1,3,23),
	(16,1,3,24),
	(16,1,4,25),
	(17,1,3,26),
	(17,1,4,27),
	(18,1,3,28),
	(18,1,4,29),
	(19,1,3,30),
	(19,1,4,32),
	(19,1,5,31),
	(20,1,3,33),
	(20,1,4,35),
	(20,1,5,34),
	(21,1,3,36),
	(21,1,4,37),
	(22,1,3,38),
	(23,1,3,39),
	(23,1,4,40),
	(24,1,3,41),
	(24,1,4,42),
	(25,1,3,43),
	(25,1,4,44),
	(26,1,3,45),
	(26,1,4,46),
	(28,1,3,47),
	(28,1,4,48),
	(29,1,3,49),
	(30,1,3,50),
	(31,1,3,51),
	(32,1,3,52),
	(32,1,4,53),
	(34,1,3,54),
	(34,1,4,55),
	(35,1,3,56),
	(35,1,4,57),
	(36,1,3,58),
	(37,1,4,59),
	(38,1,4,60),
	(40,1,3,61),
	(40,1,4,62),
	(41,1,4,63),
	(42,1,5,64),
	(42,1,8,65),
	(43,1,3,66),
	(43,1,4,67),
	(44,1,5,68),
	(45,1,5,69),
	(46,1,3,70),
	(47,1,3,71),
	(48,1,3,72),
	(49,1,3,73),
	(50,1,3,74),
	(51,1,5,75),
	(53,1,3,76),
	(54,1,3,77),
	(55,1,3,78),
	(56,1,3,79),
	(57,1,3,80),
	(58,1,3,81),
	(60,1,3,82),
	(61,1,3,83),
	(62,1,3,84),
	(63,1,3,85),
	(64,1,3,86),
	(65,1,3,87),
	(67,1,3,88),
	(68,1,3,89),
	(69,1,3,90),
	(71,1,3,91),
	(72,1,3,92),
	(73,1,3,93),
	(74,1,3,94),
	(77,1,3,95),
	(78,1,3,96),
	(79,1,3,97),
	(80,1,3,98),
	(82,1,3,99),
	(83,1,3,100),
	(84,1,3,101),
	(85,1,3,102),
	(86,1,3,103),
	(87,1,3,104),
	(88,1,3,105),
	(89,1,3,106),
	(90,1,3,107),
	(91,1,8,108),
	(92,1,3,109),
	(93,1,3,110),
	(94,1,3,111),
	(95,1,3,112),
	(96,1,3,113),
	(97,1,3,114),
	(99,1,3,115),
	(100,1,3,116),
	(105,1,5,118),
	(105,1,8,119),
	(106,1,5,117),
	(129,1,14,136),
	(133,1,5,138),
	(133,1,6,139),
	(133,1,8,140),
	(133,1,14,141),
	(134,1,14,137),
	(135,1,14,142);

/*!40000 ALTER TABLE `CollectionAttributeValues` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Collections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Collections`;

CREATE TABLE `Collections` (
  `cID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cDateModified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cHandle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cID`),
  KEY `cDateModified` (`cDateModified`),
  KEY `cDateAdded` (`cDateAdded`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Collections` WRITE;
/*!40000 ALTER TABLE `Collections` DISABLE KEYS */;

INSERT INTO `Collections` (`cID`, `cDateAdded`, `cDateModified`, `cHandle`)
VALUES
	(1,'2013-04-27 15:01:27','2013-04-27 21:49:21','home'),
	(2,'2013-04-27 15:01:36','2013-04-27 15:01:37','dashboard'),
	(3,'2013-04-27 15:01:37','2013-04-27 15:01:37','composer'),
	(4,'2013-04-27 15:01:37','2013-04-27 15:01:37','write'),
	(5,'2013-04-27 15:01:37','2013-04-27 15:01:37','drafts'),
	(6,'2013-04-27 15:01:37','2013-04-27 15:01:37','sitemap'),
	(7,'2013-04-27 15:01:37','2013-04-27 15:01:37','full'),
	(8,'2013-04-27 15:01:37','2013-04-27 15:01:37','explore'),
	(9,'2013-04-27 15:01:37','2013-04-27 15:01:37','search'),
	(10,'2013-04-27 15:01:37','2013-04-27 15:01:37','files'),
	(11,'2013-04-27 15:01:37','2013-04-27 15:01:37','search'),
	(12,'2013-04-27 15:01:37','2013-04-27 15:01:37','attributes'),
	(13,'2013-04-27 15:01:37','2013-04-27 15:01:37','sets'),
	(14,'2013-04-27 15:01:37','2013-04-27 15:01:37','add_set'),
	(15,'2013-04-27 15:01:37','2013-04-27 15:01:37','users'),
	(16,'2013-04-27 15:01:37','2013-04-27 15:01:37','search'),
	(17,'2013-04-27 15:01:37','2013-04-27 15:01:37','groups'),
	(18,'2013-04-27 15:01:37','2013-04-27 15:01:37','attributes'),
	(19,'2013-04-27 15:01:37','2013-04-27 15:01:37','add'),
	(20,'2013-04-27 15:01:37','2013-04-27 15:01:37','add_group'),
	(21,'2013-04-27 15:01:37','2013-04-27 15:01:38','group_sets'),
	(22,'2013-04-27 15:01:38','2013-04-27 15:01:38','reports'),
	(23,'2013-04-27 15:01:38','2013-04-27 15:01:38','statistics'),
	(24,'2013-04-27 15:01:38','2013-04-27 15:01:38','forms'),
	(25,'2013-04-27 15:01:38','2013-04-27 15:01:38','surveys'),
	(26,'2013-04-27 15:01:38','2013-04-27 15:01:38','logs'),
	(27,'2013-04-27 15:01:38','2013-04-27 15:01:38','pages'),
	(28,'2013-04-27 15:01:38','2013-04-27 15:01:38','themes'),
	(29,'2013-04-27 15:01:38','2013-04-27 15:01:38','add'),
	(30,'2013-04-27 15:01:38','2013-04-27 15:01:38','inspect'),
	(31,'2013-04-27 15:01:38','2013-04-27 15:01:38','customize'),
	(32,'2013-04-27 15:01:38','2013-04-27 15:01:38','types'),
	(33,'2013-04-27 15:01:38','2013-04-27 15:01:38','add'),
	(34,'2013-04-27 15:01:38','2013-04-27 15:01:38','attributes'),
	(35,'2013-04-27 15:01:38','2013-04-27 15:01:38','single'),
	(36,'2013-04-27 15:01:38','2013-04-27 15:01:38','workflow'),
	(37,'2013-04-27 15:01:38','2013-04-27 15:01:38','list'),
	(38,'2013-04-27 15:01:38','2013-04-27 15:01:38','me'),
	(39,'2013-04-27 15:01:38','2013-04-27 15:01:38','blocks'),
	(40,'2013-04-27 15:01:38','2013-04-27 15:01:38','stacks'),
	(41,'2013-04-27 15:01:38','2013-04-27 15:01:38','permissions'),
	(42,'2013-04-27 15:01:38','2013-04-27 15:01:38','list'),
	(43,'2013-04-27 15:01:38','2013-04-27 15:01:38','types'),
	(44,'2013-04-27 15:01:38','2013-04-27 15:01:38','extend'),
	(45,'2013-04-27 15:01:38','2013-04-27 15:01:38','news'),
	(46,'2013-04-27 15:01:38','2013-04-27 15:01:38','install'),
	(47,'2013-04-27 15:01:38','2013-04-27 15:01:39','update'),
	(48,'2013-04-27 15:01:39','2013-04-27 15:01:39','connect'),
	(49,'2013-04-27 15:01:39','2013-04-27 15:01:39','themes'),
	(50,'2013-04-27 15:01:39','2013-04-27 15:01:39','add-ons'),
	(51,'2013-04-27 15:01:39','2013-04-27 15:01:39','system'),
	(52,'2013-04-27 15:01:39','2013-04-27 15:01:39','basics'),
	(53,'2013-04-27 15:01:39','2013-04-27 15:01:39','site_name'),
	(54,'2013-04-27 15:01:39','2013-04-27 15:01:39','icons'),
	(55,'2013-04-27 15:01:39','2013-04-27 15:01:39','editor'),
	(56,'2013-04-27 15:01:39','2013-04-27 15:01:39','multilingual'),
	(57,'2013-04-27 15:01:39','2013-04-27 15:01:39','timezone'),
	(58,'2013-04-27 15:01:39','2013-04-27 15:01:39','interface'),
	(59,'2013-04-27 15:01:39','2013-04-27 15:01:39','seo'),
	(60,'2013-04-27 15:01:39','2013-04-27 15:01:39','urls'),
	(61,'2013-04-27 15:01:39','2013-04-27 15:01:39','bulk_seo_tool'),
	(62,'2013-04-27 15:01:39','2013-04-27 15:01:39','tracking_codes'),
	(63,'2013-04-27 15:01:39','2013-04-27 15:01:39','excluded'),
	(64,'2013-04-27 15:01:39','2013-04-27 15:01:39','statistics'),
	(65,'2013-04-27 15:01:39','2013-04-27 15:01:39','search_index'),
	(66,'2013-04-27 15:01:39','2013-04-27 15:01:39','optimization'),
	(67,'2013-04-27 15:01:39','2013-04-27 15:01:39','cache'),
	(68,'2013-04-27 15:01:39','2013-04-27 15:01:39','clear_cache'),
	(69,'2013-04-27 15:01:39','2013-04-27 15:01:39','jobs'),
	(70,'2013-04-27 15:01:39','2013-04-27 15:01:40','permissions'),
	(71,'2013-04-27 15:01:40','2013-04-27 15:01:40','site'),
	(72,'2013-04-27 15:01:40','2013-04-27 15:01:40','files'),
	(73,'2013-04-27 15:01:40','2013-04-27 15:01:40','file_types'),
	(74,'2013-04-27 15:01:40','2013-04-27 15:01:40','tasks'),
	(75,'2013-04-27 15:01:40','2013-04-27 15:01:40','users'),
	(76,'2013-04-27 15:01:40','2013-04-27 15:01:40','advanced'),
	(77,'2013-04-27 15:01:40','2013-04-27 15:01:40','ip_blacklist'),
	(78,'2013-04-27 15:01:40','2013-04-27 15:01:40','captcha'),
	(79,'2013-04-27 15:01:40','2013-04-27 15:01:40','antispam'),
	(80,'2013-04-27 15:01:40','2013-04-27 15:01:40','maintenance_mode'),
	(81,'2013-04-27 15:01:40','2013-04-27 15:01:40','registration'),
	(82,'2013-04-27 15:01:40','2013-04-27 15:01:40','postlogin'),
	(83,'2013-04-27 15:01:40','2013-04-27 15:01:40','profiles'),
	(84,'2013-04-27 15:01:40','2013-04-27 15:01:40','public_registration'),
	(85,'2013-04-27 15:01:40','2013-04-27 15:01:40','mail'),
	(86,'2013-04-27 15:01:40','2013-04-27 15:01:40','method'),
	(87,'2013-04-27 15:01:40','2013-04-27 15:01:40','importers'),
	(88,'2013-04-27 15:01:40','2013-04-27 15:01:40','attributes'),
	(89,'2013-04-27 15:01:40','2013-04-27 15:01:40','sets'),
	(90,'2013-04-27 15:01:40','2013-04-27 15:01:40','types'),
	(91,'2013-04-27 15:01:40','2013-04-27 15:01:40','environment'),
	(92,'2013-04-27 15:01:40','2013-04-27 15:01:40','info'),
	(93,'2013-04-27 15:01:40','2013-04-27 15:01:40','debug'),
	(94,'2013-04-27 15:01:40','2013-04-27 15:01:40','logging'),
	(95,'2013-04-27 15:01:40','2013-04-27 15:01:40','file_storage_locations'),
	(96,'2013-04-27 15:01:40','2013-04-27 15:01:41','proxy'),
	(97,'2013-04-27 15:01:41','2013-04-27 15:01:41','backup_restore'),
	(98,'2013-04-27 15:01:41','2013-04-27 15:01:41','backup'),
	(99,'2013-04-27 15:01:41','2013-04-27 15:01:41','update'),
	(100,'2013-04-27 15:01:41','2013-04-27 15:01:41','database'),
	(101,'2013-04-27 15:01:41','2013-04-27 15:01:41','composer'),
	(102,'2013-04-27 15:01:41','2013-04-27 15:01:41',NULL),
	(103,'2013-04-27 15:01:41','2013-04-27 15:01:41',NULL),
	(104,'2013-04-27 15:01:41','2013-04-27 15:01:41',NULL),
	(105,'2013-04-27 15:01:41','2013-04-27 15:01:41','home'),
	(106,'2013-04-27 15:01:41','2013-04-27 15:01:41','welcome'),
	(107,'2013-04-27 15:01:44','2013-04-27 15:01:44','!drafts'),
	(108,'2013-04-27 15:01:44','2013-04-27 15:01:44','!trash'),
	(109,'2013-04-27 15:01:44','2013-04-27 15:01:44','!stacks'),
	(110,'2013-04-27 15:01:44','2013-04-27 15:01:44','login'),
	(111,'2013-04-27 15:01:44','2013-04-27 15:01:44','register'),
	(112,'2013-04-27 15:01:44','2013-04-27 15:01:45','profile'),
	(113,'2013-04-27 15:01:45','2013-04-27 15:01:45','edit'),
	(114,'2013-04-27 15:01:45','2013-04-27 15:01:45','avatar'),
	(115,'2013-04-27 15:01:45','2013-04-27 15:01:45','messages'),
	(116,'2013-04-27 15:01:45','2013-04-27 15:01:45','friends'),
	(117,'2013-04-27 15:01:45','2013-04-27 15:01:45','page_not_found'),
	(118,'2013-04-27 15:01:45','2013-04-27 15:01:45','page_forbidden'),
	(119,'2013-04-27 15:01:45','2013-04-27 15:01:45','download_file'),
	(120,'2013-04-27 15:01:45','2013-04-27 15:01:45','members'),
	(121,'2013-04-27 15:01:46','2013-04-27 15:01:46','header-nav'),
	(122,'2013-04-27 15:01:46','2013-04-27 15:01:46','side-nav'),
	(123,'2013-04-27 15:01:46','2013-04-27 15:01:46','site-name'),
	(124,'2013-04-27 15:01:47','2013-04-27 15:01:47',NULL),
	(125,'2013-04-27 15:01:47','2013-04-27 15:01:47',NULL),
	(126,'2013-04-27 15:01:47','2013-04-27 15:01:47',NULL),
	(127,'2013-04-27 15:01:47','2013-04-27 15:01:47',NULL),
	(128,'2013-04-27 15:01:47','2013-04-27 20:06:18','about'),
	(129,'2013-04-27 15:01:47','2013-04-27 20:04:52','blog'),
	(130,'2013-04-27 15:01:47','2013-04-27 20:05:17','search'),
	(131,'2013-04-27 15:01:47','2013-04-27 20:06:18','contact-us'),
	(132,'2013-04-27 15:01:47','2013-04-27 20:04:52','guestbook'),
	(133,'2013-04-27 15:01:47','2013-04-27 20:04:52','blog-archives'),
	(134,'2013-04-27 15:01:47','2013-04-27 15:01:47','hello-world'),
	(135,'2013-04-27 20:01:23','2013-04-27 20:01:32','');

/*!40000 ALTER TABLE `Collections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CollectionSearchIndexAttributes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionSearchIndexAttributes`;

CREATE TABLE `CollectionSearchIndexAttributes` (
  `cID` int(11) unsigned NOT NULL DEFAULT '0',
  `ak_meta_title` text,
  `ak_meta_description` text,
  `ak_meta_keywords` text,
  `ak_icon_dashboard` text,
  `ak_exclude_nav` tinyint(4) DEFAULT '0',
  `ak_exclude_page_list` tinyint(4) DEFAULT '0',
  `ak_header_extra_content` text,
  `ak_exclude_search_index` tinyint(4) DEFAULT '0',
  `ak_exclude_sitemapxml` tinyint(4) DEFAULT '0',
  `ak_tags` text,
  PRIMARY KEY (`cID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `CollectionSearchIndexAttributes` WRITE;
/*!40000 ALTER TABLE `CollectionSearchIndexAttributes` DISABLE KEYS */;

INSERT INTO `CollectionSearchIndexAttributes` (`cID`, `ak_meta_title`, `ak_meta_description`, `ak_meta_keywords`, `ak_icon_dashboard`, `ak_exclude_nav`, `ak_exclude_page_list`, `ak_header_extra_content`, `ak_exclude_search_index`, `ak_exclude_sitemapxml`, `ak_tags`)
VALUES
	(1,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL),
	(3,NULL,NULL,'blog, blogging','icon-book',0,0,NULL,0,0,NULL),
	(4,NULL,NULL,'new blog, write blog, blogging','icon-pencil',0,0,NULL,0,0,NULL),
	(5,NULL,NULL,'blog drafts,composer','icon-book',0,0,NULL,0,0,NULL),
	(6,NULL,NULL,'pages, add page, delete page, copy, move, alias',NULL,0,0,NULL,0,0,NULL),
	(7,NULL,NULL,'pages, add page, delete page, copy, move, alias','icon-home',0,0,NULL,0,0,NULL),
	(8,NULL,NULL,'pages, add page, delete page, copy, move, alias, bulk','icon-road',0,0,NULL,0,0,NULL),
	(9,NULL,NULL,'find page, search page, search, find, pages, sitemap','icon-search',0,0,NULL,0,0,NULL),
	(11,NULL,NULL,'add file, delete file, copy, move, alias, resize, crop, rename, images, title, attribute','icon-picture',0,0,NULL,0,0,NULL),
	(12,NULL,NULL,'file, file attributes, title, attribute, description, rename','icon-cog',0,0,NULL,0,0,NULL),
	(13,NULL,NULL,'files, category, categories','icon-list-alt',0,0,NULL,0,0,NULL),
	(14,NULL,NULL,'new file set','icon-plus-sign',1,0,NULL,0,0,NULL),
	(15,NULL,NULL,'users, groups, people, find, delete user, remove user, change password, password',NULL,0,0,NULL,0,0,NULL),
	(16,NULL,NULL,'find, search, people, delete user, remove user, change password, password','icon-user',0,0,NULL,0,0,NULL),
	(17,NULL,NULL,'user, group, people, permissions, access, expire','icon-globe',0,0,NULL,0,0,NULL),
	(18,NULL,NULL,'user attributes, user data, gather data, registration data','icon-cog',0,0,NULL,0,0,NULL),
	(19,NULL,NULL,'new user, create','icon-plus-sign',1,0,NULL,0,0,NULL),
	(20,NULL,NULL,'new user group, new group, group, create','icon-plus',1,0,NULL,0,0,NULL),
	(21,NULL,NULL,'group set','icon-list',0,0,NULL,0,0,NULL),
	(22,NULL,NULL,'forms, log, error, email, mysql, exception, survey',NULL,0,0,NULL,0,0,NULL),
	(23,NULL,NULL,'hits, pageviews, visitors, activity','icon-signal',0,0,NULL,0,0,NULL),
	(24,NULL,NULL,'forms, questions, response, data','icon-briefcase',0,0,NULL,0,0,NULL),
	(25,NULL,NULL,'questions, quiz, response','icon-tasks',0,0,NULL,0,0,NULL),
	(26,NULL,NULL,'forms, log, error, email, mysql, exception, survey, history','icon-time',0,0,NULL,0,0,NULL),
	(28,NULL,NULL,'new theme, theme, active theme, change theme, template, css','icon-font',0,0,NULL,0,0,NULL),
	(29,NULL,NULL,'theme',NULL,0,0,NULL,0,0,NULL),
	(30,NULL,NULL,'page types',NULL,0,0,NULL,0,0,NULL),
	(31,NULL,NULL,'custom theme, change theme, custom css, css',NULL,0,0,NULL,0,0,NULL),
	(32,NULL,NULL,'page type defaults, global block, global area, starter, template','icon-file',0,0,NULL,0,0,NULL),
	(34,NULL,NULL,'page attributes, custom','icon-cog',0,0,NULL,0,0,NULL),
	(35,NULL,NULL,'single, page, custom, application','icon-wrench',0,0,NULL,0,0,NULL),
	(36,NULL,NULL,'add workflow, remove workflow',NULL,0,0,NULL,0,0,NULL),
	(37,NULL,NULL,NULL,'icon-list',0,0,NULL,0,0,NULL),
	(38,NULL,NULL,NULL,'icon-user',0,0,NULL,0,0,NULL),
	(40,NULL,NULL,'stacks, reusable content, scrapbook, copy, paste, paste block, copy block, site name, logo','icon-th',0,0,NULL,0,0,NULL),
	(41,NULL,NULL,NULL,'icon-lock',0,0,NULL,0,0,NULL),
	(42,NULL,NULL,NULL,NULL,1,0,NULL,1,0,NULL),
	(43,NULL,NULL,'block, refresh, custom','icon-wrench',0,0,NULL,0,0,NULL),
	(44,NULL,NULL,NULL,NULL,1,0,NULL,0,0,NULL),
	(45,NULL,NULL,NULL,NULL,1,0,NULL,0,0,NULL),
	(46,NULL,NULL,'add-on, addon, ecommerce, install, discussions, forums, themes, templates, blocks',NULL,0,0,NULL,0,0,NULL),
	(47,NULL,NULL,'update, upgrade',NULL,0,0,NULL,0,0,NULL),
	(48,NULL,NULL,'concrete5.org, my account, marketplace',NULL,0,0,NULL,0,0,NULL),
	(49,NULL,NULL,'buy theme, new theme, marketplace, template',NULL,0,0,NULL,0,0,NULL),
	(50,NULL,NULL,'buy addon, buy add on, buy add-on, purchase addon, purchase add on, purchase add-on, find addon, new addon, marketplace',NULL,0,0,NULL,0,0,NULL),
	(51,NULL,NULL,NULL,NULL,1,0,NULL,0,0,NULL),
	(53,NULL,NULL,'website name, title',NULL,0,0,NULL,0,0,NULL),
	(54,NULL,NULL,'logo, favicon, iphone, icon, bookmark',NULL,0,0,NULL,0,0,NULL),
	(55,NULL,NULL,'tinymce, content block, fonts, editor, tinymce, content, overlay',NULL,0,0,NULL,0,0,NULL),
	(56,NULL,NULL,'translate, translation, internationalization, multilingual, translate',NULL,0,0,NULL,0,0,NULL),
	(57,NULL,NULL,'timezone, profile, locale',NULL,0,0,NULL,0,0,NULL),
	(58,NULL,NULL,'interface, quick nav, dashboard background, background image',NULL,0,0,NULL,0,0,NULL),
	(60,NULL,NULL,'vanity, pretty url, seo, pageview, view',NULL,0,0,NULL,0,0,NULL),
	(61,NULL,NULL,'bulk, seo, change keywords, engine, optimization, search',NULL,0,0,NULL,0,0,NULL),
	(62,NULL,NULL,'traffic, statistics, google analytics, quant, pageviews, hits',NULL,0,0,NULL,0,0,NULL),
	(63,NULL,NULL,'pretty, slug',NULL,0,0,NULL,0,0,NULL),
	(64,NULL,NULL,'turn off statistics, tracking, statistics, pageviews, hits',NULL,0,0,NULL,0,0,NULL),
	(65,NULL,NULL,'configure search, site search, search option',NULL,0,0,NULL,0,0,NULL),
	(67,NULL,NULL,'cache option, change cache, override, turn on cache, turn off cache, no cache, page cache, caching',NULL,0,0,NULL,0,0,NULL),
	(68,NULL,NULL,'cache option, turn off cache, no cache, page cache, caching',NULL,0,0,NULL,0,0,NULL),
	(69,NULL,NULL,'index search, reindex search, build sitemap, sitemap.xml, clear old versions, page versions, remove old',NULL,0,0,NULL,0,0,NULL),
	(71,NULL,NULL,'editors, hide site, offline, private, public, access',NULL,0,0,NULL,0,0,NULL),
	(72,NULL,NULL,'file options, file manager, upload, modify',NULL,0,0,NULL,0,0,NULL),
	(73,NULL,NULL,'security, files, media, extension, manager, upload',NULL,0,0,NULL,0,0,NULL),
	(74,NULL,NULL,'security, actions, administrator, admin, package, marketplace, search',NULL,0,0,NULL,0,0,NULL),
	(77,NULL,NULL,'security, lock ip, lock out, block ip, address, restrict, access',NULL,0,0,NULL,0,0,NULL),
	(78,NULL,NULL,'security, registration',NULL,0,0,NULL,0,0,NULL),
	(79,NULL,NULL,'antispam, block spam, security',NULL,0,0,NULL,0,0,NULL),
	(80,NULL,NULL,'lock site, under construction, hide, hidden',NULL,0,0,NULL,0,0,NULL),
	(82,NULL,NULL,'profile, login, redirect, specific, dashboard, administrators',NULL,0,0,NULL,0,0,NULL),
	(83,NULL,NULL,'member profile, member page,community, forums, social, avatar',NULL,0,0,NULL,0,0,NULL),
	(84,NULL,NULL,'signup, new user, community',NULL,0,0,NULL,0,0,NULL),
	(85,NULL,NULL,'smtp, mail settings',NULL,0,0,NULL,0,0,NULL),
	(86,NULL,NULL,'email server, mail settings, mail configuration, external, internal',NULL,0,0,NULL,0,0,NULL),
	(87,NULL,NULL,'email server, mail settings, mail configuration, private message, message system, import, email, message',NULL,0,0,NULL,0,0,NULL),
	(88,NULL,NULL,'attribute configuration',NULL,0,0,NULL,0,0,NULL),
	(89,NULL,NULL,'attributes, sets',NULL,0,0,NULL,0,0,NULL),
	(90,NULL,NULL,'attributes, types',NULL,0,0,NULL,0,0,NULL),
	(91,NULL,NULL,NULL,NULL,0,0,NULL,1,0,NULL),
	(92,NULL,NULL,'overrides, system info, debug, support,help',NULL,0,0,NULL,0,0,NULL),
	(93,NULL,NULL,'errors,exceptions, develop, support, help',NULL,0,0,NULL,0,0,NULL),
	(94,NULL,NULL,'email, logging, logs, smtp, pop, errors, mysql, errors, log',NULL,0,0,NULL,0,0,NULL),
	(95,NULL,NULL,'security, alternate storage, hide files',NULL,0,0,NULL,0,0,NULL),
	(96,NULL,NULL,'network, proxy server',NULL,0,0,NULL,0,0,NULL),
	(97,NULL,NULL,'export, backup, database, sql, mysql, encryption, restore',NULL,0,0,NULL,0,0,NULL),
	(99,NULL,NULL,'upgrade, new version, update',NULL,0,0,NULL,0,0,NULL),
	(100,NULL,NULL,'export, database, xml, starting, points, schema, refresh, custom, tables',NULL,0,0,NULL,0,0,NULL),
	(105,NULL,NULL,NULL,NULL,1,0,NULL,1,0,NULL),
	(106,NULL,NULL,NULL,NULL,1,0,NULL,0,0,NULL),
	(128,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL),
	(129,NULL,NULL,NULL,NULL,0,0,NULL,0,0,''),
	(130,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL),
	(131,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL),
	(132,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL),
	(133,NULL,NULL,NULL,NULL,1,1,NULL,1,0,''),
	(134,NULL,NULL,NULL,NULL,0,0,NULL,0,0,'\ncomposer\nhello\nworld\nfirst post\n');

/*!40000 ALTER TABLE `CollectionSearchIndexAttributes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CollectionVersionAreaLayouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionVersionAreaLayouts`;

CREATE TABLE `CollectionVersionAreaLayouts` (
  `cvalID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned DEFAULT '0',
  `cvID` int(10) unsigned DEFAULT '0',
  `arHandle` varchar(255) DEFAULT NULL,
  `layoutID` int(10) unsigned NOT NULL DEFAULT '0',
  `position` int(10) DEFAULT '1000',
  `areaNameNumber` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`cvalID`),
  KEY `areaLayoutsIndex` (`cID`,`cvID`,`arHandle`),
  KEY `cID` (`cID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table CollectionVersionAreaStyles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionVersionAreaStyles`;

CREATE TABLE `CollectionVersionAreaStyles` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `csrID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`arHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table CollectionVersionBlocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionVersionBlocks`;

CREATE TABLE `CollectionVersionBlocks` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '1',
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `cbDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `isOriginal` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cbOverrideAreaPermissions` tinyint(1) NOT NULL DEFAULT '0',
  `cbIncludeAll` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`bID`,`arHandle`),
  KEY `cbIncludeAll` (`cbIncludeAll`),
  KEY `isOriginal` (`isOriginal`),
  KEY `bID` (`bID`),
  KEY `cIDcvID` (`cID`,`cvID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `CollectionVersionBlocks` WRITE;
/*!40000 ALTER TABLE `CollectionVersionBlocks` DISABLE KEYS */;

INSERT INTO `CollectionVersionBlocks` (`cID`, `cvID`, `bID`, `arHandle`, `cbDisplayOrder`, `isOriginal`, `cbOverrideAreaPermissions`, `cbIncludeAll`)
VALUES
	(1,1,24,'Sidebar',0,1,0,0),
	(1,1,25,'Sidebar',1,1,0,0),
	(1,1,26,'Main',0,1,0,0),
	(1,1,27,'Header Image',0,1,0,0),
	(1,2,24,'Sidebar',0,0,0,0),
	(1,2,25,'Sidebar',1,0,0,0),
	(1,2,26,'Main',0,0,0,0),
	(1,2,27,'Header Image',0,0,0,0),
	(1,3,24,'Sidebar',0,0,0,0),
	(1,3,25,'Sidebar',1,0,0,0),
	(1,3,26,'Main',0,0,0,0),
	(1,3,27,'Header Image',0,0,0,0),
	(1,4,24,'Sidebar',0,0,0,0),
	(1,4,25,'Sidebar',1,0,0,0),
	(1,4,26,'Main',0,0,0,0),
	(1,4,27,'Header Image',0,0,0,0),
	(1,4,51,'Top Block',0,1,0,0),
	(1,5,24,'Sidebar',0,0,0,0),
	(1,5,25,'Sidebar',1,0,0,0),
	(1,5,26,'Main',0,0,0,0),
	(1,5,27,'Header Image',0,0,0,0),
	(1,5,51,'Top Block',0,0,0,0),
	(1,5,52,'Gallery Block',0,1,0,0),
	(1,5,53,'About Block',0,1,0,0),
	(1,5,54,'Contact Block',0,1,0,0),
	(1,6,24,'Sidebar',0,0,0,0),
	(1,6,25,'Sidebar',1,0,0,0),
	(1,6,26,'Main',0,0,0,0),
	(1,6,27,'Header Image',0,0,0,0),
	(1,6,51,'Top Block',1,0,0,0),
	(1,6,52,'Gallery Block',0,0,0,0),
	(1,6,53,'About Block',0,0,0,0),
	(1,6,54,'Contact Block',0,0,0,0),
	(1,6,55,'Services Block',0,1,0,0),
	(1,6,56,'Top Block',0,1,0,0),
	(1,7,24,'Sidebar',0,0,0,0),
	(1,7,25,'Sidebar',1,0,0,0),
	(1,7,26,'Main',0,0,0,0),
	(1,7,27,'Header Image',0,0,0,0),
	(1,7,51,'Top Block',1,0,0,0),
	(1,7,52,'Gallery Block',0,0,0,0),
	(1,7,53,'About Block',0,0,0,0),
	(1,7,54,'Contact Block',0,0,0,0),
	(1,7,55,'Services Block',0,0,0,0),
	(1,7,56,'Top Block',0,0,0,0),
	(1,7,57,'Contact Block',1,1,0,0),
	(1,8,24,'Sidebar',0,0,0,0),
	(1,8,25,'Sidebar',1,0,0,0),
	(1,8,26,'Main',0,0,0,0),
	(1,8,27,'Header Image',0,0,0,0),
	(1,8,51,'Top Block',1,0,0,0),
	(1,8,52,'Gallery Block',0,0,0,0),
	(1,8,53,'About Block',0,0,0,0),
	(1,8,55,'Services Block',0,0,0,0),
	(1,8,56,'Top Block',0,0,0,0),
	(1,8,57,'Contact Block',1,0,0,0),
	(1,8,58,'Contact Block',0,1,0,0),
	(1,9,24,'Sidebar',0,0,0,0),
	(1,9,25,'Sidebar',1,0,0,0),
	(1,9,26,'Main',0,0,0,0),
	(1,9,27,'Header Image',0,0,0,0),
	(1,9,51,'Top Block',1,0,0,0),
	(1,9,52,'Gallery Block',0,0,0,0),
	(1,9,53,'About Block',0,0,0,0),
	(1,9,55,'Services Block',0,0,0,0),
	(1,9,56,'Top Block',0,0,0,0),
	(1,9,58,'Contact Block',0,0,0,0),
	(1,9,59,'Contact Block',1,1,0,0),
	(1,10,24,'Sidebar',0,0,0,0),
	(1,10,25,'Sidebar',1,0,0,0),
	(1,10,26,'Main',0,0,0,0),
	(1,10,27,'Header Image',0,0,0,0),
	(1,10,51,'Top Block',1,0,0,0),
	(1,10,52,'Gallery Block',0,0,0,0),
	(1,10,53,'About Block',0,0,0,0),
	(1,10,55,'Services Block',0,0,0,0),
	(1,10,56,'Top Block',0,0,0,0),
	(1,10,60,'Contact Block',0,1,0,0),
	(1,10,61,'Contact Block',1,1,0,0),
	(1,11,24,'Sidebar',0,0,0,0),
	(1,11,25,'Sidebar',1,0,0,0),
	(1,11,26,'Main',0,0,0,0),
	(1,11,27,'Header Image',0,0,0,0),
	(1,11,51,'Top Block',1,0,0,0),
	(1,11,53,'About Block',0,0,0,0),
	(1,11,55,'Services Block',0,0,0,0),
	(1,11,56,'Top Block',0,0,0,0),
	(1,11,60,'Contact Block',0,0,0,0),
	(1,11,61,'Contact Block',1,0,0,0),
	(1,11,62,'Gallery Block',0,1,0,0),
	(105,1,6,'Primary',0,1,0,0),
	(105,1,7,'Primary',1,1,0,0),
	(105,1,8,'Secondary 1',0,1,0,0),
	(105,1,9,'Secondary 2',0,1,0,0),
	(105,1,10,'Secondary 3',0,1,0,0),
	(105,1,11,'Secondary 4',0,1,0,0),
	(105,1,12,'Secondary 5',0,1,0,0),
	(106,1,1,'Header',0,1,0,0),
	(106,1,2,'Column 1',0,1,0,0),
	(106,1,3,'Column 2',0,1,0,0),
	(106,1,4,'Column 3',0,1,0,0),
	(106,1,5,'Column 4',0,1,0,0),
	(121,1,20,'Main',0,1,0,0),
	(122,1,21,'Main',0,1,0,0),
	(122,1,22,'Main',1,1,0,0),
	(123,1,23,'Main',0,1,0,0),
	(124,1,13,'Main',0,1,0,0),
	(124,1,14,'Sidebar',0,1,0,0),
	(124,1,15,'Thumbnail Image',0,1,0,0),
	(124,1,16,'Header Image',0,1,0,0),
	(125,1,17,'Header Image',0,1,0,0),
	(126,1,18,'Header Image',0,1,0,0),
	(127,1,19,'Header Image',0,1,0,0),
	(128,1,18,'Header Image',0,0,0,0),
	(128,1,28,'Sidebar',0,1,0,0),
	(128,1,29,'Main',0,1,0,0),
	(129,1,19,'Header Image',0,0,0,0),
	(129,1,38,'Main',0,1,0,0),
	(129,1,39,'Sidebar',0,1,0,0),
	(129,1,40,'Sidebar',1,1,0,0),
	(129,1,41,'Sidebar',2,1,0,0),
	(130,1,19,'Header Image',0,0,0,0),
	(130,1,35,'Sidebar',0,1,0,0),
	(130,1,36,'Sidebar',1,1,0,0),
	(130,1,37,'Main',0,1,0,0),
	(131,1,18,'Header Image',0,0,0,0),
	(131,1,32,'Sidebar',0,1,0,0),
	(131,1,33,'Main',0,1,0,0),
	(131,1,34,'Main',1,1,0,0),
	(132,1,19,'Header Image',0,0,0,0),
	(132,1,30,'Sidebar',0,1,0,0),
	(132,1,31,'Main',0,1,0,1),
	(133,1,19,'Header Image',0,0,0,0),
	(133,1,45,'Main',0,1,0,0),
	(133,1,46,'Sidebar',0,1,0,0),
	(133,1,47,'Sidebar',1,1,0,0),
	(134,1,14,'Sidebar',0,0,0,0),
	(134,1,42,'Header Image',0,1,0,0),
	(134,1,43,'Main',0,1,0,0),
	(134,1,44,'Thumbnail Image',0,1,0,0),
	(135,1,14,'Sidebar',0,0,0,0),
	(135,1,48,'Header Image',0,1,0,0),
	(135,1,49,'Thumbnail Image',0,1,0,0),
	(135,1,50,'Main',0,1,0,0);

/*!40000 ALTER TABLE `CollectionVersionBlocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CollectionVersionBlocksOutputCache
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionVersionBlocksOutputCache`;

CREATE TABLE `CollectionVersionBlocksOutputCache` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '1',
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `btCachedBlockOutput` longtext,
  `btCachedBlockOutputExpires` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`bID`,`arHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `CollectionVersionBlocksOutputCache` WRITE;
/*!40000 ALTER TABLE `CollectionVersionBlocksOutputCache` DISABLE KEYS */;

INSERT INTO `CollectionVersionBlocksOutputCache` (`cID`, `cvID`, `bID`, `arHandle`, `btCachedBlockOutput`, `btCachedBlockOutputExpires`)
VALUES
	(1,1,23,'Site Name','<h1><a title=\"Home\" \n                                	href=\"/\"\n                                >Fanning Landscapes</a></h1>',1524852279),
	(1,1,24,'Sidebar','<h3>Sidebar</h3>',1524852279),
	(1,1,25,'Sidebar','<p>Everything about concrete5 is completely customizable through the CMS. This is a separate area from the main content on the homepage. You can&nbsp;<a title=\"Move blocks in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/blocks-and-areas\" target=\"_blank\">drag and drop blocks</a>&nbsp;like this around your layout.</p>',1524852279),
	(1,1,26,'Main','<h2>Welcome to concrete5!</h2>\n                                        <p>Content Management is easy with concrete5\'s in-context editing. Just <a href=\"/index.php/login/\">login</a> and you can change things as you browse your site.</p>\n                                        <p>You can watch videos and learn how to:</p>\n                                        <ul>\n                                        <li><a title=\"In-context editing CMS\" href=\"http://www.concrete5.org/documentation/general-topics/in-context-editing/\" target=\"_blank\">Edit</a>&nbsp;this page.</li>\n                                        <li>Add a <a title=\"Add a page in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add-a-page/\" target=\"_blank\">new page</a>.</li>\n                                        <li>Add some basic functionality, like&nbsp;<a title=\"Add a simple form in concrete5\" href=\"http://www.concrete5.org/documentation/general-topics/add_a_form\" target=\"_blank\">a Form</a>.</li>\n                                        <li><a title=\"add-on marketplace for concrete5\" href=\"http://www.concrete5.org/marketplace/how_to_install_add_ons_and_themes_/\" target=\"_blank\">Finding &amp; adding</a>&nbsp;more functionality and themes.</li>\n                                        </ul>\n                                        <p>We\'ve taken the liberty to build out the rest of this site with some sample content that will help you learn concrete5. Wander around a bit, or click Dashboard to get to the&nbsp;<a href=\"/index.php/dashboard/sitemap/\">Sitemap</a> and quickly delete the parts you don\'t want.</p>',1524852279),
	(1,1,27,'Header Image','<img border=\"0\" class=\"ccm-image-block\" alt=\"\" src=\"/files/2913/6708/5705/england_village.jpg\" width=\"960\" height=\"212\" />',1524852279),
	(1,3,23,'Site Name','<h1><a title=\"Home\" \n                                	href=\"/\"\n                                >Fanning Landscapes</a></h1>',1524870383),
	(1,4,23,'Site Name','<h1><a title=\"Home\" \n                                	href=\"/\"\n                                >Fanning Landscapes</a></h1>',1524870456),
	(1,4,51,'Top Block','<p>Rock Solid.</p>',1524870451),
	(1,5,23,'Site Name','<h1><a title=\"Home\" \n                                	href=\"/\"\n                                >Fanning Landscapes</a></h1>',1524871956),
	(1,5,51,'Top Block','<p>Rock Solid.</p>',1524871956),
	(1,5,53,'About Block','<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>',1524872007),
	(1,6,23,'Site Name','<h1><a title=\"Home\" \n                                	href=\"/\"\n                                >Fanning Landscapes</a></h1>',1524874290),
	(1,6,51,'Top Block','<p>Rock Solid.</p>',1524874290),
	(1,6,53,'About Block','<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>',1524874290),
	(1,6,55,'Services Block','<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>',1524874083),
	(1,6,56,'Top Block','<a href=\"/\"><img border=\"0\" class=\"ccm-image-block\" alt=\"Home\" src=\"/files/8113/6710/7776/logo-revised.png\" width=\"334\" height=\"102\" /></a>',1524874241),
	(1,7,51,'Top Block','<p>Rock Solid.</p>',1524875864),
	(1,7,53,'About Block','<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>',1524875864),
	(1,7,55,'Services Block','<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>',1524875864),
	(1,7,56,'Top Block','<a href=\"/\"><img border=\"0\" class=\"ccm-image-block\" alt=\"Home\" src=\"/files/8113/6710/7776/logo-revised.png\" width=\"334\" height=\"102\" /></a>',1524875864),
	(1,7,57,'Contact Block','<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>',1524875857),
	(1,8,51,'Top Block','<p>Rock Solid.</p>',1524876059),
	(1,8,53,'About Block','<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>',1524876059),
	(1,8,55,'Services Block','<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>',1524876059),
	(1,8,56,'Top Block','<a href=\"/\"><img border=\"0\" class=\"ccm-image-block\" alt=\"Home\" src=\"/files/8113/6710/7776/logo-revised.png\" width=\"334\" height=\"102\" /></a>',1524876059),
	(1,8,57,'Contact Block','<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>',1524876059),
	(1,9,51,'Top Block','<p>Rock Solid.</p>',1524876225),
	(1,9,53,'About Block','<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>',1524876225),
	(1,9,55,'Services Block','<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>',1524876225),
	(1,9,56,'Top Block','<a href=\"/\"><img border=\"0\" class=\"ccm-image-block\" alt=\"Home\" src=\"/files/8113/6710/7776/logo-revised.png\" width=\"334\" height=\"102\" /></a>',1524876225),
	(1,9,57,'Contact Block','<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>',1524876226),
	(1,9,59,'Contact Block','<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>',1524876237),
	(1,10,51,'Top Block','<p>Rock Solid.</p>',1524876363),
	(1,10,53,'About Block','<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>',1524876364),
	(1,10,55,'Services Block','<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>',1524876364),
	(1,10,56,'Top Block','<a href=\"/\"><img border=\"0\" class=\"ccm-image-block\" alt=\"Home\" src=\"/files/8113/6710/7776/logo-revised.png\" width=\"334\" height=\"102\" /></a>',1524876363),
	(1,10,59,'Contact Block','<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>',1524876364),
	(1,10,61,'Contact Block','<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>',1524876376),
	(1,11,51,'Top Block','<p>Rock Solid.</p>',1524876540),
	(1,11,53,'About Block','<p>Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties.</p>\r\n<p>FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida.</p>\r\n<p>After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.</p>',1524876540),
	(1,11,55,'Services Block','<div class=\"list-column\">\r\n<h3>Hardscapes</h3>\r\n<ul>\r\n<li>Retaining Walls</li>\r\n<li>Interlock Driveways</li>\r\n<li>Pool Surrounds</li>\r\n<li>Garden Walls</li>\r\n<li>Interlock Walkways</li>\r\n<li>Stone Stairways</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Softscapes</h3>\r\n<ul>\r\n<li>Gardening Services</li>\r\n<li>Grading</li>\r\n<li>Lawns</li>\r\n<li>Drainage Solutions</li>\r\n</ul>\r\n</div>\r\n<div class=\"list-column\">\r\n<h3>Specialty</h3>\r\n<ul>\r\n<li>Outdoor Living Spaces</li>\r\n<li>Golf Greens</li>\r\n<li>Water Features</li>\r\n<li>Fire Pits</li>\r\n</ul>\r\n</div>',1524876540),
	(1,11,56,'Top Block','<a href=\"/\"><img border=\"0\" class=\"ccm-image-block\" alt=\"Home\" src=\"/files/8113/6710/7776/logo-revised.png\" width=\"334\" height=\"102\" /></a>',1524876540),
	(1,11,61,'Contact Block','<p>902.754.3636</p>\r\n<p><a href=\"mailto:dennis@fanninglandscapes.com\">dennis@fanninglandscapes.com</a></p>',1524876540),
	(106,1,1,'Header','	<div id=\"newsflow-header-first-run\"><h1>Welcome to concrete5.</h1>\n						<h2>It\'s easy to edit content and add pages using in-context editing.</h2></div>\n						',1524852281),
	(106,1,2,'Column 1','<div class=\"newsflow-column-first-run\">\n							<h3>Building Your Own Site</h3>\n							<p>Editing with concrete5 is a breeze. Just point and click to make changes.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/editors\')\" class=\"btn primary\">Editor\'s Guide</a></p>\n							</div>',1524852281),
	(106,1,3,'Column 2','<div class=\"newsflow-column-first-run\">\n							<h3>Developing Applications</h3>\n							<p>If you’re comfortable in PHP concrete5 should be a breeze to learn. Take a few moments to understand the architecture.</p>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/developers\')\" class=\"btn primary\">Developer\'s Guide</a></p>\n							</div>',1524852281),
	(106,1,4,'Column 3','<div class=\"newsflow-column-first-run\">\n							<h3>Designing Websites</h3>\n							<p>Good with CSS and HTML? You can easily theme anything with concrete5.</p>\n							<br/>\n							<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/designers\')\" class=\"btn primary\">Designer\'s Guide</a></p>\n							</div>',1524852281),
	(106,1,5,'Column 4','\n						<div class=\"newsflow-column-first-run\">\n						<h3>Business Background</h3>\n						<p>Worried about license structures, white-labeling or why concrete5 is a good choice for your agency?</p>\n						<p><a href=\"javascript:void(0)\" onclick=\"ccm_getNewsflowByPath(\'/welcome/executives\')\" class=\"btn primary\">Executive\'s Guide</a></p>\n						</div>',1524852281),
	(128,1,23,'Site Name','<h1><a title=\"Home\" \n                                	href=\"/\"\n                                >Fanning Landscapes</a></h1>',1524870219),
	(130,1,23,'Site Name','<h1><a title=\"Home\" \n                                	href=\"/\"\n                                >Fanning Landscapes</a></h1>',1524870299);

/*!40000 ALTER TABLE `CollectionVersionBlocksOutputCache` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CollectionVersionBlockStyles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionVersionBlockStyles`;

CREATE TABLE `CollectionVersionBlockStyles` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `arHandle` varchar(255) NOT NULL,
  `csrID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`bID`,`arHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `CollectionVersionBlockStyles` WRITE;
/*!40000 ALTER TABLE `CollectionVersionBlockStyles` DISABLE KEYS */;

INSERT INTO `CollectionVersionBlockStyles` (`cID`, `cvID`, `bID`, `arHandle`, `csrID`)
VALUES
	(1,2,24,'Sidebar',0),
	(1,2,25,'Sidebar',0),
	(1,2,26,'Main',0),
	(1,2,27,'Header Image',0),
	(1,3,24,'Sidebar',0),
	(1,3,25,'Sidebar',0),
	(1,3,26,'Main',0),
	(1,3,27,'Header Image',0),
	(1,4,24,'Sidebar',0),
	(1,4,25,'Sidebar',0),
	(1,4,26,'Main',0),
	(1,4,27,'Header Image',0),
	(1,5,24,'Sidebar',0),
	(1,5,25,'Sidebar',0),
	(1,5,26,'Main',0),
	(1,5,27,'Header Image',0),
	(1,5,51,'Top Block',0),
	(1,7,24,'Sidebar',0),
	(1,7,25,'Sidebar',0),
	(1,7,26,'Main',0),
	(1,7,27,'Header Image',0),
	(1,7,51,'Top Block',0),
	(1,7,52,'Gallery Block',0),
	(1,7,53,'About Block',0),
	(1,7,54,'Contact Block',0),
	(1,7,55,'Services Block',0),
	(1,7,56,'Top Block',0),
	(1,8,24,'Sidebar',0),
	(1,8,25,'Sidebar',0),
	(1,8,26,'Main',0),
	(1,8,27,'Header Image',0),
	(1,8,51,'Top Block',0),
	(1,8,52,'Gallery Block',0),
	(1,8,53,'About Block',0),
	(1,8,55,'Services Block',0),
	(1,8,56,'Top Block',0),
	(1,8,57,'Contact Block',1),
	(1,8,58,'Contact Block',2),
	(1,9,24,'Sidebar',0),
	(1,9,25,'Sidebar',0),
	(1,9,26,'Main',0),
	(1,9,27,'Header Image',0),
	(1,9,51,'Top Block',0),
	(1,9,52,'Gallery Block',0),
	(1,9,53,'About Block',0),
	(1,9,55,'Services Block',0),
	(1,9,56,'Top Block',0),
	(1,9,58,'Contact Block',3),
	(1,9,59,'Contact Block',4),
	(1,10,24,'Sidebar',0),
	(1,10,25,'Sidebar',0),
	(1,10,26,'Main',0),
	(1,10,27,'Header Image',0),
	(1,10,51,'Top Block',0),
	(1,10,52,'Gallery Block',0),
	(1,10,53,'About Block',0),
	(1,10,55,'Services Block',0),
	(1,10,56,'Top Block',0),
	(1,10,60,'Contact Block',5),
	(1,10,61,'Contact Block',6),
	(1,11,24,'Sidebar',0),
	(1,11,25,'Sidebar',0),
	(1,11,26,'Main',0),
	(1,11,27,'Header Image',0),
	(1,11,51,'Top Block',0),
	(1,11,53,'About Block',0),
	(1,11,55,'Services Block',0),
	(1,11,56,'Top Block',0),
	(1,11,60,'Contact Block',5),
	(1,11,61,'Contact Block',6),
	(1,11,62,'Gallery Block',0),
	(128,1,18,'Header Image',0),
	(129,1,19,'Header Image',0),
	(130,1,19,'Header Image',0),
	(131,1,18,'Header Image',0),
	(132,1,19,'Header Image',0),
	(133,1,19,'Header Image',0),
	(134,1,14,'Sidebar',0),
	(135,1,14,'Sidebar',0),
	(135,1,48,'Header Image',0),
	(135,1,49,'Thumbnail Image',0),
	(135,1,50,'Main',0);

/*!40000 ALTER TABLE `CollectionVersionBlockStyles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CollectionVersionRelatedEdits
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionVersionRelatedEdits`;

CREATE TABLE `CollectionVersionRelatedEdits` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '0',
  `cRelationID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvRelationID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`cvID`,`cRelationID`,`cvRelationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table CollectionVersions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CollectionVersions`;

CREATE TABLE `CollectionVersions` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvID` int(10) unsigned NOT NULL DEFAULT '1',
  `cvName` text,
  `cvHandle` varchar(255) DEFAULT NULL,
  `cvDescription` text,
  `cvDatePublic` datetime DEFAULT NULL,
  `cvDateCreated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cvComments` varchar(255) DEFAULT NULL,
  `cvIsApproved` tinyint(1) NOT NULL DEFAULT '0',
  `cvIsNew` tinyint(1) NOT NULL DEFAULT '0',
  `cvAuthorUID` int(10) unsigned DEFAULT NULL,
  `cvApproverUID` int(10) unsigned DEFAULT NULL,
  `ptID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `cvActivateDatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`cID`,`cvID`),
  KEY `cvIsApproved` (`cvIsApproved`),
  KEY `ctID` (`ctID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `CollectionVersions` WRITE;
/*!40000 ALTER TABLE `CollectionVersions` DISABLE KEYS */;

INSERT INTO `CollectionVersions` (`cID`, `cvID`, `cvName`, `cvHandle`, `cvDescription`, `cvDatePublic`, `cvDateCreated`, `cvComments`, `cvIsApproved`, `cvIsNew`, `cvAuthorUID`, `cvApproverUID`, `ptID`, `ctID`, `cvActivateDatetime`)
VALUES
	(1,1,'Home','home','','2013-04-27 15:01:27','2013-04-27 15:01:27','Initial Version',0,0,1,NULL,5,7,NULL),
	(1,2,'Home','home','','2013-04-27 15:01:27','2013-04-27 20:05:50','New Version 2',0,0,1,1,5,5,NULL),
	(1,3,'Home','home','','2013-04-27 15:01:27','2013-04-27 20:06:05','Version 3',0,0,1,1,5,5,NULL),
	(1,4,'Home','home','','2013-04-27 15:01:27','2013-04-27 20:07:31','Version 4',0,0,1,1,5,5,NULL),
	(1,5,'Home','home','','2013-04-27 15:01:27','2013-04-27 20:32:12','Added initial content.',0,0,1,1,5,5,NULL),
	(1,6,'Home','home','','2013-04-27 15:01:27','2013-04-27 21:08:02','Version 6',0,0,1,1,5,5,NULL),
	(1,7,'Home','home','','2013-04-27 15:01:27','2013-04-27 21:37:36','Version 7',0,0,1,1,5,5,NULL),
	(1,8,'Home','home','','2013-04-27 15:01:27','2013-04-27 21:40:57','Version 8',0,0,1,1,5,5,NULL),
	(1,9,'Home','home','','2013-04-27 15:01:27','2013-04-27 21:43:44','Version 9',0,0,1,1,5,5,NULL),
	(1,10,'Home','home','','2013-04-27 15:01:27','2013-04-27 21:46:03','Version 10',0,0,1,1,5,5,NULL),
	(1,11,'Home','home','','2013-04-27 15:01:27','2013-04-27 21:47:30','Version 11',1,0,1,1,5,5,NULL),
	(2,1,'Dashboard','dashboard','','2013-04-27 15:01:36','2013-04-27 15:01:36','Initial Version',1,0,1,NULL,5,0,NULL),
	(3,1,'Composer','composer','Write for your site.','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(4,1,'Write','write','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(5,1,'Drafts','drafts','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(6,1,'Sitemap','sitemap','Whole world at a glance.','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(7,1,'Full Sitemap','full','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(8,1,'Flat View','explore','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(9,1,'Page Search','search','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(10,1,'Files','files','All documents and images.','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(11,1,'File Manager','search','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(12,1,'Attributes','attributes','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(13,1,'File Sets','sets','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(14,1,'Add File Set','add_set','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(15,1,'Members','users','Add and manage the user accounts and groups on your website.','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(16,1,'Search Users','search','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(17,1,'User Groups','groups','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(18,1,'Attributes','attributes','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(19,1,'Add User','add','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(20,1,'Add Group','add_group','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(21,1,'Group Sets','group_sets','','2013-04-27 15:01:37','2013-04-27 15:01:37','Initial Version',1,0,1,NULL,5,0,NULL),
	(22,1,'Reports','reports','Get data from forms and logs.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(23,1,'Statistics','statistics','View your site activity.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(24,1,'Form Results','forms','Get submission data.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(25,1,'Surveys','surveys','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(26,1,'Logs','logs','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(27,1,'Pages & Themes','pages','Reskin your site.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(28,1,'Themes','themes','Reskin your site.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(29,1,'Add','add','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(30,1,'Inspect','inspect','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(31,1,'Customize','customize','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(32,1,'Page Types','types','What goes in your site.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(33,1,'Add Page Type','add','Add page types to your site.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(34,1,'Attributes','attributes','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(35,1,'Single Pages','single','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(36,1,'Workflow','workflow','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(37,1,'Workflow List','list','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(38,1,'Waiting for Me','me','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(39,1,'Stacks & Blocks','blocks','Manage sitewide content and administer block types.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(40,1,'Stacks','stacks','Share content across your site.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(41,1,'Block & Stack Permissions','permissions','Control who can add blocks and stacks on your site.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(42,1,'Stack List','list','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(43,1,'Block Types','types','Manage the installed block types in your site.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(44,1,'Extend concrete5','extend','Connect to the concrete5 marketplace, install custom add-ons, and download updates for marketplace add-ons and themes.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(45,1,'Dashboard','news','','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(46,1,'Add Functionality','install','Install add-ons & themes.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(47,1,'Update Add-Ons','update','Update your installed packages.','2013-04-27 15:01:38','2013-04-27 15:01:38','Initial Version',1,0,1,NULL,5,0,NULL),
	(48,1,'Connect to the Community','connect','Connect to the concrete5 community.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(49,1,'Get More Themes','themes','Download themes from concrete5.org.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(50,1,'Get More Add-Ons','add-ons','Download add-ons from concrete5.org.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(51,1,'System & Settings','system','Secure and setup your site.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(52,1,'Basics','basics','Basic information about your website.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(53,1,'Site Name','site_name','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(54,1,'Bookmark Icons','icons','Bookmark icon and mobile home screen icon setup.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(55,1,'Rich Text Editor','editor','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(56,1,'Languages','multilingual','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(57,1,'Time Zone','timezone','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(58,1,'Interface Preferences','interface','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(59,1,'SEO & Statistics','seo','Enable pretty URLs, statistics and tracking codes.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(60,1,'Pretty URLs','urls','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(61,1,'Bulk SEO Updater','bulk_seo_tool','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(62,1,'Tracking Codes','tracking_codes','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(63,1,'Excluded URL Word List','excluded','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(64,1,'Statistics','statistics','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(65,1,'Search Index','search_index','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(66,1,'Optimization','optimization','Keep your site running well.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(67,1,'Cache & Speed Settings','cache','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(68,1,'Clear Cache','clear_cache','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(69,1,'Automated Jobs','jobs','','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(70,1,'Permissions & Access','permissions','Control who sees and edits your site.','2013-04-27 15:01:39','2013-04-27 15:01:39','Initial Version',1,0,1,NULL,5,0,NULL),
	(71,1,'Site Access','site','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(72,1,'File Manager Permissions','files','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(73,1,'Allowed File Types','file_types','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(74,1,'Task Permissions','tasks','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(75,1,'User Permissions','users','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(76,1,'Advanced Permissions','advanced','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(77,1,'IP Blacklist','ip_blacklist','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(78,1,'Captcha Setup','captcha','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(79,1,'Spam Control','antispam','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(80,1,'Maintenance Mode','maintenance_mode','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(81,1,'Login & Registration','registration','Change login behaviors and setup public profiles.','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(82,1,'Login Destination','postlogin','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(83,1,'Public Profiles','profiles','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(84,1,'Public Registration','public_registration','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(85,1,'Email','mail','Control how your site send and processes mail.','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(86,1,'SMTP Method','method','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(87,1,'Email Importers','importers','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(88,1,'Attributes','attributes','Setup attributes for pages, users, files and more.','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(89,1,'Sets','sets','Group attributes into sets for easier organization','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(90,1,'Types','types','Choose which attribute types are available for different items.','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(91,1,'Environment','environment','Advanced settings for web developers.','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(92,1,'Environment Information','info','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(93,1,'Debug Settings','debug','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(94,1,'Logging Settings','logging','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(95,1,'File Storage Locations','file_storage_locations','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(96,1,'Proxy Server','proxy','','2013-04-27 15:01:40','2013-04-27 15:01:40','Initial Version',1,0,1,NULL,5,0,NULL),
	(97,1,'Backup & Restore','backup_restore','Backup or restore your website.','2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,1,NULL,5,0,NULL),
	(98,1,'Backup Database','backup','','2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,1,NULL,5,0,NULL),
	(99,1,'Update concrete5','update','','2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,1,NULL,5,0,NULL),
	(100,1,'Database XML','database','','2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,1,NULL,5,0,NULL),
	(101,1,'Composer','composer','','2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,1,NULL,5,0,NULL),
	(102,1,'',NULL,NULL,'2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,NULL,NULL,0,1,NULL),
	(103,1,'',NULL,NULL,'2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,NULL,NULL,0,2,NULL),
	(104,1,'',NULL,NULL,'2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,NULL,NULL,0,3,NULL),
	(105,1,'Customize Dashboard Home','home','','2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,1,NULL,5,2,NULL),
	(106,1,'Welcome to concrete5','welcome','Learn about how to use concrete5, how to develop for concrete5, and get general help.','2013-04-27 15:01:41','2013-04-27 15:01:41','Initial Version',1,0,1,NULL,5,3,NULL),
	(107,1,'Drafts','!drafts','','2013-04-27 15:01:44','2013-04-27 15:01:44','Initial Version',1,0,1,NULL,5,0,NULL),
	(108,1,'Trash','!trash','','2013-04-27 15:01:44','2013-04-27 15:01:44','Initial Version',1,0,1,NULL,5,0,NULL),
	(109,1,'Stacks','!stacks','','2013-04-27 15:01:44','2013-04-27 15:01:44','Initial Version',1,0,1,NULL,5,0,NULL),
	(110,1,'Login','login','','2013-04-27 15:01:44','2013-04-27 15:01:44','Initial Version',1,0,1,NULL,5,0,NULL),
	(111,1,'Register','register','','2013-04-27 15:01:44','2013-04-27 15:01:44','Initial Version',1,0,1,NULL,5,0,NULL),
	(112,1,'Profile','profile','','2013-04-27 15:01:44','2013-04-27 15:01:44','Initial Version',1,0,1,NULL,5,0,NULL),
	(113,1,'Edit','edit','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(114,1,'Avatar','avatar','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(115,1,'Messages','messages','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(116,1,'Friends','friends','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(117,1,'Page Not Found','page_not_found','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(118,1,'Page Forbidden','page_forbidden','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(119,1,'Download File','download_file','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(120,1,'Members','members','','2013-04-27 15:01:45','2013-04-27 15:01:45','Initial Version',1,0,1,NULL,5,0,NULL),
	(121,1,'Header Nav','header-nav',NULL,'2013-04-27 15:01:46','2013-04-27 15:01:46','Initial Version',1,0,1,NULL,5,1,NULL),
	(122,1,'Side Nav','side-nav',NULL,'2013-04-27 15:01:46','2013-04-27 15:01:46','Initial Version',1,0,1,NULL,5,1,NULL),
	(123,1,'Site Name','site-name',NULL,'2013-04-27 15:01:46','2013-04-27 15:01:46','Initial Version',1,0,1,NULL,5,1,NULL),
	(124,1,'',NULL,NULL,'2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,NULL,NULL,0,4,NULL),
	(125,1,'',NULL,NULL,'2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,NULL,NULL,0,5,NULL),
	(126,1,'',NULL,NULL,'2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,NULL,NULL,0,6,NULL),
	(127,1,'',NULL,NULL,'2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,NULL,NULL,0,7,NULL),
	(128,1,'About','about','','2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,1,NULL,5,6,NULL),
	(129,1,'Blog','blog','','2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,1,NULL,5,7,NULL),
	(130,1,'Search','search','','2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,1,NULL,5,7,NULL),
	(131,1,'Contact Us','contact-us','','2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,1,NULL,5,6,NULL),
	(132,1,'Guestbook','guestbook','','2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,1,NULL,5,7,NULL),
	(133,1,'Blog Archives','blog-archives','','2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,1,NULL,5,7,NULL),
	(134,1,'Hello World','hello-world','This is my first blog post!','2013-04-27 15:01:47','2013-04-27 15:01:47','Initial Version',1,0,1,NULL,5,4,NULL),
	(135,1,'','','','2013-04-27 20:01:00','2013-04-27 20:01:23','Initial Version',0,1,1,NULL,5,4,NULL);

/*!40000 ALTER TABLE `CollectionVersions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ComposerContentLayout
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ComposerContentLayout`;

CREATE TABLE `ComposerContentLayout` (
  `cclID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `displayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `ccFilename` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`cclID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `ComposerContentLayout` WRITE;
/*!40000 ALTER TABLE `ComposerContentLayout` DISABLE KEYS */;

INSERT INTO `ComposerContentLayout` (`cclID`, `bID`, `akID`, `displayOrder`, `ctID`, `ccFilename`)
VALUES
	(1,16,0,1,4,'header.php'),
	(2,15,0,2,4,'thumbnail.php'),
	(3,13,0,3,4,''),
	(4,0,14,4,4,NULL);

/*!40000 ALTER TABLE `ComposerContentLayout` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ComposerDrafts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ComposerDrafts`;

CREATE TABLE `ComposerDrafts` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cpPublishParentID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `ComposerDrafts` WRITE;
/*!40000 ALTER TABLE `ComposerDrafts` DISABLE KEYS */;

INSERT INTO `ComposerDrafts` (`cID`, `cpPublishParentID`)
VALUES
	(135,129);

/*!40000 ALTER TABLE `ComposerDrafts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ComposerTypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ComposerTypes`;

CREATE TABLE `ComposerTypes` (
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctComposerPublishPageMethod` varchar(64) NOT NULL DEFAULT 'CHOOSE',
  `ctComposerPublishPageTypeID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctComposerPublishPageParentID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ctID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `ComposerTypes` WRITE;
/*!40000 ALTER TABLE `ComposerTypes` DISABLE KEYS */;

INSERT INTO `ComposerTypes` (`ctID`, `ctComposerPublishPageMethod`, `ctComposerPublishPageTypeID`, `ctComposerPublishPageParentID`)
VALUES
	(4,'PARENT',0,129);

/*!40000 ALTER TABLE `ComposerTypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Config`;

CREATE TABLE `Config` (
  `cfKey` varchar(64) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cfValue` longtext,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cfKey`,`uID`),
  KEY `uID` (`uID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Config` WRITE;
/*!40000 ALTER TABLE `Config` DISABLE KEYS */;

INSERT INTO `Config` (`cfKey`, `timestamp`, `cfValue`, `uID`, `pkgID`)
VALUES
	('ACCESS_ENTITY_UPDATED','2013-04-27 15:01:45','1367085705',0,0),
	('ANTISPAM_LOG_SPAM','2013-04-27 15:01:45','1',0,0),
	('APP_VERSION_LATEST','2013-04-27 15:01:50','5.6.1.2',0,0),
	('DO_PAGE_REINDEX_CHECK','2013-04-27 21:49:23','0',0,0),
	('ENABLE_BLOCK_CACHE','2013-04-27 15:01:45','1',0,0),
	('ENABLE_LOG_EMAILS','2013-04-27 15:01:45','1',0,0),
	('ENABLE_LOG_ERRORS','2013-04-27 15:01:45','1',0,0),
	('ENABLE_MARKETPLACE_SUPPORT','2013-04-27 15:01:45','1',0,0),
	('ENABLE_OVERRIDE_CACHE','2013-04-27 15:01:45','1',0,0),
	('FULL_PAGE_CACHE_GLOBAL','2013-04-27 15:01:45','0',0,0),
	('MARKETPLACE_SITE_TOKEN','2013-04-27 20:26:09','NoLmlliMyOJc3tR57bqzuR9RaThFOFKA1IO2mwFIz5nhUGrVgYKMB5iW7C4p3HMp',0,0),
	('MARKETPLACE_SITE_URL_TOKEN','2013-04-27 20:26:09','r9y8jvfeizbw3lvvwaszb9p7',0,0),
	('NEWSFLOW_LAST_VIEWED','2013-04-27 15:05:17','1367085917',1,0),
	('SEEN_INTRODUCTION','2013-04-27 15:04:39','1',0,0),
	('SITE','2013-04-27 15:01:49','Fanning Landscapes',0,0),
	('SITE_APP_VERSION','2013-04-27 15:01:49','5.6.1.2',0,0),
	('SITE_DEBUG_LEVEL','2013-04-27 15:01:45','1',0,0),
	('SITE_INSTALLED_APP_VERSION','2013-04-27 15:01:49','5.6.1.2',0,0);

/*!40000 ALTER TABLE `Config` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CustomStylePresets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CustomStylePresets`;

CREATE TABLE `CustomStylePresets` (
  `cspID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cspName` varchar(255) NOT NULL,
  `csrID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cspID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table CustomStyleRules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CustomStyleRules`;

CREATE TABLE `CustomStyleRules` (
  `csrID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `css_id` varchar(128) DEFAULT NULL,
  `css_class` varchar(128) DEFAULT NULL,
  `css_serialized` text,
  `css_custom` text,
  PRIMARY KEY (`csrID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `CustomStyleRules` WRITE;
/*!40000 ALTER TABLE `CustomStyleRules` DISABLE KEYS */;

INSERT INTO `CustomStyleRules` (`csrID`, `css_id`, `css_class`, `css_serialized`, `css_custom`)
VALUES
	(1,'','block','a:20:{s:11:\"font_family\";s:7:\"inherit\";s:5:\"color\";s:0:\"\";s:9:\"font_size\";s:0:\"\";s:11:\"line_height\";s:0:\"\";s:10:\"text_align\";s:0:\"\";s:16:\"background_color\";s:0:\"\";s:12:\"border_style\";s:4:\"none\";s:12:\"border_color\";s:0:\"\";s:12:\"border_width\";s:1:\"0\";s:15:\"border_position\";s:4:\"full\";s:10:\"margin_top\";s:0:\"\";s:12:\"margin_right\";s:0:\"\";s:13:\"margin_bottom\";s:0:\"\";s:11:\"margin_left\";s:0:\"\";s:11:\"padding_top\";s:0:\"\";s:13:\"padding_right\";s:0:\"\";s:14:\"padding_bottom\";s:0:\"\";s:12:\"padding_left\";s:0:\"\";s:16:\"background_image\";s:1:\"0\";s:17:\"background_repeat\";s:9:\"no-repeat\";}',''),
	(2,'','block','a:20:{s:11:\"font_family\";s:7:\"inherit\";s:5:\"color\";s:0:\"\";s:9:\"font_size\";s:0:\"\";s:11:\"line_height\";s:0:\"\";s:10:\"text_align\";s:0:\"\";s:16:\"background_color\";s:0:\"\";s:12:\"border_style\";s:4:\"none\";s:12:\"border_color\";s:0:\"\";s:12:\"border_width\";s:1:\"0\";s:15:\"border_position\";s:4:\"full\";s:10:\"margin_top\";s:0:\"\";s:12:\"margin_right\";s:0:\"\";s:13:\"margin_bottom\";s:0:\"\";s:11:\"margin_left\";s:0:\"\";s:11:\"padding_top\";s:0:\"\";s:13:\"padding_right\";s:0:\"\";s:14:\"padding_bottom\";s:0:\"\";s:12:\"padding_left\";s:0:\"\";s:16:\"background_image\";s:1:\"0\";s:17:\"background_repeat\";s:9:\"no-repeat\";}',''),
	(3,'','block','a:20:{s:11:\"font_family\";s:7:\"inherit\";s:5:\"color\";s:0:\"\";s:9:\"font_size\";s:0:\"\";s:11:\"line_height\";s:0:\"\";s:10:\"text_align\";s:0:\"\";s:16:\"background_color\";s:0:\"\";s:12:\"border_style\";s:4:\"none\";s:12:\"border_color\";s:0:\"\";s:12:\"border_width\";s:1:\"0\";s:15:\"border_position\";s:4:\"full\";s:10:\"margin_top\";s:0:\"\";s:12:\"margin_right\";s:0:\"\";s:13:\"margin_bottom\";s:0:\"\";s:11:\"margin_left\";s:0:\"\";s:11:\"padding_top\";s:0:\"\";s:13:\"padding_right\";s:0:\"\";s:14:\"padding_bottom\";s:0:\"\";s:12:\"padding_left\";s:0:\"\";s:16:\"background_image\";s:1:\"0\";s:17:\"background_repeat\";s:9:\"no-repeat\";}','left'),
	(4,'','block','a:20:{s:11:\"font_family\";s:7:\"inherit\";s:5:\"color\";s:0:\"\";s:9:\"font_size\";s:0:\"\";s:11:\"line_height\";s:0:\"\";s:10:\"text_align\";s:0:\"\";s:16:\"background_color\";s:0:\"\";s:12:\"border_style\";s:4:\"none\";s:12:\"border_color\";s:0:\"\";s:12:\"border_width\";s:1:\"0\";s:15:\"border_position\";s:4:\"full\";s:10:\"margin_top\";s:0:\"\";s:12:\"margin_right\";s:0:\"\";s:13:\"margin_bottom\";s:0:\"\";s:11:\"margin_left\";s:0:\"\";s:11:\"padding_top\";s:0:\"\";s:13:\"padding_right\";s:0:\"\";s:14:\"padding_bottom\";s:0:\"\";s:12:\"padding_left\";s:0:\"\";s:16:\"background_image\";s:1:\"0\";s:17:\"background_repeat\";s:9:\"no-repeat\";}','right'),
	(5,'','block left','a:20:{s:11:\"font_family\";s:7:\"inherit\";s:5:\"color\";s:0:\"\";s:9:\"font_size\";s:0:\"\";s:11:\"line_height\";s:0:\"\";s:10:\"text_align\";s:0:\"\";s:16:\"background_color\";s:0:\"\";s:12:\"border_style\";s:4:\"none\";s:12:\"border_color\";s:0:\"\";s:12:\"border_width\";s:1:\"0\";s:15:\"border_position\";s:4:\"full\";s:10:\"margin_top\";s:0:\"\";s:12:\"margin_right\";s:0:\"\";s:13:\"margin_bottom\";s:0:\"\";s:11:\"margin_left\";s:0:\"\";s:11:\"padding_top\";s:0:\"\";s:13:\"padding_right\";s:0:\"\";s:14:\"padding_bottom\";s:0:\"\";s:12:\"padding_left\";s:0:\"\";s:16:\"background_image\";s:1:\"0\";s:17:\"background_repeat\";s:9:\"no-repeat\";}',''),
	(6,'','block right','a:20:{s:11:\"font_family\";s:7:\"inherit\";s:5:\"color\";s:0:\"\";s:9:\"font_size\";s:0:\"\";s:11:\"line_height\";s:0:\"\";s:10:\"text_align\";s:0:\"\";s:16:\"background_color\";s:0:\"\";s:12:\"border_style\";s:4:\"none\";s:12:\"border_color\";s:0:\"\";s:12:\"border_width\";s:1:\"0\";s:15:\"border_position\";s:4:\"full\";s:10:\"margin_top\";s:0:\"\";s:12:\"margin_right\";s:0:\"\";s:13:\"margin_bottom\";s:0:\"\";s:11:\"margin_left\";s:0:\"\";s:11:\"padding_top\";s:0:\"\";s:13:\"padding_right\";s:0:\"\";s:14:\"padding_bottom\";s:0:\"\";s:12:\"padding_left\";s:0:\"\";s:16:\"background_image\";s:1:\"0\";s:17:\"background_repeat\";s:9:\"no-repeat\";}','');

/*!40000 ALTER TABLE `CustomStyleRules` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table DownloadStatistics
# ------------------------------------------------------------

DROP TABLE IF EXISTS `DownloadStatistics`;

CREATE TABLE `DownloadStatistics` (
  `dsID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fID` int(10) unsigned NOT NULL,
  `fvID` int(10) unsigned NOT NULL,
  `uID` int(10) unsigned NOT NULL,
  `rcID` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table FileAttributeValues
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileAttributeValues`;

CREATE TABLE `FileAttributeValues` (
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fID`,`fvID`,`akID`,`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `FileAttributeValues` WRITE;
/*!40000 ALTER TABLE `FileAttributeValues` DISABLE KEYS */;

INSERT INTO `FileAttributeValues` (`fID`, `fvID`, `akID`, `avID`)
VALUES
	(9,1,12,143),
	(9,1,13,144),
	(10,1,12,145),
	(10,1,13,146),
	(11,1,12,147),
	(11,1,13,148),
	(12,1,12,149),
	(12,1,13,150),
	(13,1,12,151),
	(13,1,13,152),
	(14,1,12,153),
	(14,1,13,154),
	(15,1,12,155),
	(15,1,13,156),
	(16,1,12,157),
	(16,1,13,158),
	(17,1,12,159),
	(17,1,13,160);

/*!40000 ALTER TABLE `FileAttributeValues` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FilePermissionAssignments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FilePermissionAssignments`;

CREATE TABLE `FilePermissionAssignments` (
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fID`,`paID`,`pkID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table FilePermissionFileTypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FilePermissionFileTypes`;

CREATE TABLE `FilePermissionFileTypes` (
  `fsID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(32) NOT NULL,
  PRIMARY KEY (`fsID`,`gID`,`uID`,`extension`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table FilePermissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FilePermissions`;

CREATE TABLE `FilePermissions` (
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `canRead` int(4) NOT NULL DEFAULT '0',
  `canWrite` int(4) NOT NULL DEFAULT '0',
  `canAdmin` int(4) NOT NULL DEFAULT '0',
  `canSearch` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fID`,`gID`,`uID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Files
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Files`;

CREATE TABLE `Files` (
  `fID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fDateAdded` datetime DEFAULT NULL,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `fslID` int(10) unsigned NOT NULL DEFAULT '0',
  `ocID` int(10) unsigned NOT NULL DEFAULT '0',
  `fOverrideSetPermissions` int(1) NOT NULL DEFAULT '0',
  `fPassword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fID`,`uID`,`fslID`),
  KEY `fOverrideSetPermissions` (`fOverrideSetPermissions`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Files` WRITE;
/*!40000 ALTER TABLE `Files` DISABLE KEYS */;

INSERT INTO `Files` (`fID`, `fDateAdded`, `uID`, `fslID`, `ocID`, `fOverrideSetPermissions`, `fPassword`)
VALUES
	(9,'2013-04-27 20:29:49',1,0,0,0,NULL),
	(10,'2013-04-27 20:30:45',1,0,0,0,NULL),
	(11,'2013-04-27 20:30:47',1,0,0,0,NULL),
	(12,'2013-04-27 20:30:49',1,0,0,0,NULL),
	(13,'2013-04-27 20:30:51',1,0,0,0,NULL),
	(14,'2013-04-27 20:30:53',1,0,0,0,NULL),
	(15,'2013-04-27 20:30:55',1,0,0,0,NULL),
	(16,'2013-04-27 20:30:57',1,0,0,0,NULL),
	(17,'2013-04-27 21:09:37',1,0,1,0,NULL);

/*!40000 ALTER TABLE `Files` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FileSearchIndexAttributes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileSearchIndexAttributes`;

CREATE TABLE `FileSearchIndexAttributes` (
  `fID` int(11) unsigned NOT NULL DEFAULT '0',
  `ak_width` decimal(14,4) DEFAULT '0.0000',
  `ak_height` decimal(14,4) DEFAULT '0.0000',
  PRIMARY KEY (`fID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `FileSearchIndexAttributes` WRITE;
/*!40000 ALTER TABLE `FileSearchIndexAttributes` DISABLE KEYS */;

INSERT INTO `FileSearchIndexAttributes` (`fID`, `ak_width`, `ak_height`)
VALUES
	(1,960.0000,212.0000),
	(2,960.0000,212.0000),
	(3,960.0000,212.0000),
	(4,960.0000,212.0000),
	(5,960.0000,212.0000),
	(6,960.0000,212.0000),
	(7,960.0000,212.0000),
	(8,150.0000,150.0000),
	(9,3264.0000,2448.0000),
	(10,3264.0000,2448.0000),
	(11,3264.0000,2448.0000),
	(12,3264.0000,2448.0000),
	(13,3264.0000,2448.0000),
	(14,3264.0000,2448.0000),
	(15,3264.0000,2448.0000),
	(16,3264.0000,2448.0000),
	(17,334.0000,102.0000);

/*!40000 ALTER TABLE `FileSearchIndexAttributes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FileSetFiles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileSetFiles`;

CREATE TABLE `FileSetFiles` (
  `fsfID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fID` int(10) unsigned NOT NULL,
  `fsID` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fsDisplayOrder` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fsfID`),
  KEY `fID` (`fID`),
  KEY `fsID` (`fsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `FileSetFiles` WRITE;
/*!40000 ALTER TABLE `FileSetFiles` DISABLE KEYS */;

INSERT INTO `FileSetFiles` (`fsfID`, `fID`, `fsID`, `timestamp`, `fsDisplayOrder`)
VALUES
	(1,16,1,'2013-04-27 20:31:36',0),
	(2,15,1,'2013-04-27 20:31:36',1),
	(3,14,1,'2013-04-27 20:31:36',2),
	(4,13,1,'2013-04-27 20:31:36',3),
	(5,12,1,'2013-04-27 20:31:36',4),
	(6,11,1,'2013-04-27 20:31:36',5),
	(7,10,1,'2013-04-27 20:31:36',6),
	(8,9,1,'2013-04-27 20:31:36',7);

/*!40000 ALTER TABLE `FileSetFiles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FileSetPermissionAssignments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileSetPermissionAssignments`;

CREATE TABLE `FileSetPermissionAssignments` (
  `fsID` int(10) unsigned NOT NULL DEFAULT '0',
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fsID`,`paID`,`pkID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `FileSetPermissionAssignments` WRITE;
/*!40000 ALTER TABLE `FileSetPermissionAssignments` DISABLE KEYS */;

INSERT INTO `FileSetPermissionAssignments` (`fsID`, `paID`, `pkID`)
VALUES
	(0,36,34),
	(0,37,35),
	(0,38,36),
	(0,39,37),
	(0,40,38),
	(0,41,39),
	(0,42,41),
	(0,43,40),
	(0,44,42);

/*!40000 ALTER TABLE `FileSetPermissionAssignments` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FileSetPermissionFileTypeAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileSetPermissionFileTypeAccessList`;

CREATE TABLE `FileSetPermissionFileTypeAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table FileSetPermissionFileTypeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileSetPermissionFileTypeAccessListCustom`;

CREATE TABLE `FileSetPermissionFileTypeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(64) NOT NULL,
  PRIMARY KEY (`paID`,`peID`,`extension`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table FileSets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileSets`;

CREATE TABLE `FileSets` (
  `fsID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fsName` varchar(64) NOT NULL,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `fsType` int(4) NOT NULL,
  `fsOverrideGlobalPermissions` int(4) DEFAULT NULL,
  PRIMARY KEY (`fsID`),
  KEY `fsOverrideGlobalPermissions` (`fsOverrideGlobalPermissions`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `FileSets` WRITE;
/*!40000 ALTER TABLE `FileSets` DISABLE KEYS */;

INSERT INTO `FileSets` (`fsID`, `fsName`, `uID`, `fsType`, `fsOverrideGlobalPermissions`)
VALUES
	(1,'Hardscapes',1,1,0);

/*!40000 ALTER TABLE `FileSets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FileSetSavedSearches
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileSetSavedSearches`;

CREATE TABLE `FileSetSavedSearches` (
  `fsID` int(10) unsigned NOT NULL DEFAULT '0',
  `fsSearchRequest` text,
  `fsResultColumns` text,
  PRIMARY KEY (`fsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table FileStorageLocations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileStorageLocations`;

CREATE TABLE `FileStorageLocations` (
  `fslID` int(10) unsigned NOT NULL DEFAULT '0',
  `fslName` varchar(255) NOT NULL,
  `fslDirectory` varchar(255) NOT NULL,
  PRIMARY KEY (`fslID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table FileVersionLog
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileVersionLog`;

CREATE TABLE `FileVersionLog` (
  `fvlID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvUpdateTypeID` int(3) unsigned NOT NULL DEFAULT '0',
  `fvUpdateTypeAttributeID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fvlID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `FileVersionLog` WRITE;
/*!40000 ALTER TABLE `FileVersionLog` DISABLE KEYS */;

INSERT INTO `FileVersionLog` (`fvlID`, `fID`, `fvID`, `fvUpdateTypeID`, `fvUpdateTypeAttributeID`)
VALUES
	(17,9,1,5,12),
	(18,9,1,5,13),
	(19,10,1,5,12),
	(20,10,1,5,13),
	(21,11,1,5,12),
	(22,11,1,5,13),
	(23,12,1,5,12),
	(24,12,1,5,13),
	(25,13,1,5,12),
	(26,13,1,5,13),
	(27,14,1,5,12),
	(28,14,1,5,13),
	(29,15,1,5,12),
	(30,15,1,5,13),
	(31,16,1,5,12),
	(32,16,1,5,13),
	(33,17,1,5,12),
	(34,17,1,5,13);

/*!40000 ALTER TABLE `FileVersionLog` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FileVersions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FileVersions`;

CREATE TABLE `FileVersions` (
  `fID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvFilename` varchar(255) NOT NULL,
  `fvPrefix` varchar(12) DEFAULT NULL,
  `fvGenericType` int(3) unsigned NOT NULL DEFAULT '0',
  `fvSize` int(20) unsigned NOT NULL DEFAULT '0',
  `fvTitle` varchar(255) DEFAULT NULL,
  `fvDescription` text,
  `fvTags` varchar(255) DEFAULT NULL,
  `fvIsApproved` int(10) unsigned NOT NULL DEFAULT '1',
  `fvDateAdded` datetime DEFAULT NULL,
  `fvApproverUID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvAuthorUID` int(10) unsigned NOT NULL DEFAULT '0',
  `fvActivateDatetime` datetime DEFAULT NULL,
  `fvHasThumbnail1` int(1) NOT NULL DEFAULT '0',
  `fvHasThumbnail2` int(1) NOT NULL DEFAULT '0',
  `fvHasThumbnail3` int(1) NOT NULL DEFAULT '0',
  `fvExtension` varchar(32) DEFAULT NULL,
  `fvType` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fID`,`fvID`),
  KEY `fvExtension` (`fvType`),
  KEY `fvTitle` (`fvTitle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `FileVersions` WRITE;
/*!40000 ALTER TABLE `FileVersions` DISABLE KEYS */;

INSERT INTO `FileVersions` (`fID`, `fvID`, `fvFilename`, `fvPrefix`, `fvGenericType`, `fvSize`, `fvTitle`, `fvDescription`, `fvTags`, `fvIsApproved`, `fvDateAdded`, `fvApproverUID`, `fvAuthorUID`, `fvActivateDatetime`, `fvHasThumbnail1`, `fvHasThumbnail2`, `fvHasThumbnail3`, `fvExtension`, `fvType`)
VALUES
	(9,1,'IMG_0106.JPG','941367105389',1,3751673,'IMG_0106.JPG','','',1,'2013-04-27 20:29:49',1,1,'2013-04-27 20:29:49',1,1,0,'JPG',1),
	(10,1,'IMG_0103.JPG','481367105445',1,3964124,'IMG_0103.JPG','','',1,'2013-04-27 20:30:45',1,1,'2013-04-27 20:30:45',1,1,0,'JPG',1),
	(11,1,'IMG_0106.JPG','731367105447',1,3751673,'IMG_0106.JPG','','',1,'2013-04-27 20:30:47',1,1,'2013-04-27 20:30:47',1,1,0,'JPG',1),
	(12,1,'IMG_0116.JPG','521367105449',1,2603943,'IMG_0116.JPG','','',1,'2013-04-27 20:30:49',1,1,'2013-04-27 20:30:49',1,1,0,'JPG',1),
	(13,1,'IMG_0119.JPG','101367105451',1,2168338,'IMG_0119.JPG','','',1,'2013-04-27 20:30:51',1,1,'2013-04-27 20:30:51',1,1,0,'JPG',1),
	(14,1,'IMG_0123.JPG','121367105453',1,2341260,'IMG_0123.JPG','','',1,'2013-04-27 20:30:53',1,1,'2013-04-27 20:30:53',1,1,0,'JPG',1),
	(15,1,'IMG_0126.JPG','261367105455',1,3557650,'IMG_0126.JPG','','',1,'2013-04-27 20:30:55',1,1,'2013-04-27 20:30:55',1,1,0,'JPG',1),
	(16,1,'IMG_0477.JPG','231367105457',1,2323357,'IMG_0477.JPG','','',1,'2013-04-27 20:30:57',1,1,'2013-04-27 20:30:57',1,1,0,'JPG',1),
	(17,1,'logo-revised.png','811367107776',1,7290,'logo-revised.png','','',1,'2013-04-27 21:09:37',1,1,'2013-04-27 21:09:37',1,1,0,'png',1);

/*!40000 ALTER TABLE `FileVersions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Groups`;

CREATE TABLE `Groups` (
  `gID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gName` varchar(128) NOT NULL,
  `gDescription` varchar(255) NOT NULL,
  `gUserExpirationIsEnabled` int(1) NOT NULL DEFAULT '0',
  `gUserExpirationMethod` varchar(12) DEFAULT NULL,
  `gUserExpirationSetDateTime` datetime DEFAULT NULL,
  `gUserExpirationInterval` int(10) unsigned NOT NULL DEFAULT '0',
  `gUserExpirationAction` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`gID`),
  UNIQUE KEY `gName` (`gName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Groups` WRITE;
/*!40000 ALTER TABLE `Groups` DISABLE KEYS */;

INSERT INTO `Groups` (`gID`, `gName`, `gDescription`, `gUserExpirationIsEnabled`, `gUserExpirationMethod`, `gUserExpirationSetDateTime`, `gUserExpirationInterval`, `gUserExpirationAction`)
VALUES
	(1,'Guest','The guest group represents unregistered visitors to your site.',0,NULL,NULL,0,NULL),
	(2,'Registered Users','The registered users group represents all user accounts.',0,NULL,NULL,0,NULL),
	(3,'Administrators','',0,NULL,NULL,0,NULL);

/*!40000 ALTER TABLE `Groups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table GroupSetGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `GroupSetGroups`;

CREATE TABLE `GroupSetGroups` (
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `gsID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gID`,`gsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table GroupSets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `GroupSets`;

CREATE TABLE `GroupSets` (
  `gsID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gsName` varchar(255) DEFAULT NULL,
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Jobs`;

CREATE TABLE `Jobs` (
  `jID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jName` varchar(100) NOT NULL,
  `jDescription` varchar(255) NOT NULL,
  `jDateInstalled` datetime DEFAULT NULL,
  `jDateLastRun` datetime DEFAULT NULL,
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  `jLastStatusText` varchar(255) DEFAULT NULL,
  `jLastStatusCode` smallint(4) NOT NULL DEFAULT '0',
  `jStatus` varchar(14) NOT NULL DEFAULT 'ENABLED',
  `jHandle` varchar(255) NOT NULL,
  `jNotUninstallable` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Jobs` WRITE;
/*!40000 ALTER TABLE `Jobs` DISABLE KEYS */;

INSERT INTO `Jobs` (`jID`, `jName`, `jDescription`, `jDateInstalled`, `jDateLastRun`, `pkgID`, `jLastStatusText`, `jLastStatusCode`, `jStatus`, `jHandle`, `jNotUninstallable`)
VALUES
	(1,'Index Search Engine','Index the site to allow searching to work quickly and accurately.','2013-04-27 15:01:36',NULL,0,NULL,0,'ENABLED','index_search',1),
	(2,'Generate the sitemap.xml file','Generate the sitemap.xml file that search engines use to crawl your site.','2013-04-27 15:01:36',NULL,0,NULL,0,'ENABLED','generate_sitemap',0),
	(3,'Process Email Posts','Polls an email account and grabs private messages/postings that are sent there..','2013-04-27 15:01:36',NULL,0,NULL,0,'ENABLED','process_email',0),
	(4,'Remove Old Page Versions','Removes all except the 10 most recent page versions for each page.','2013-04-27 15:01:36',NULL,0,NULL,0,'ENABLED','remove_old_page_versions',0);

/*!40000 ALTER TABLE `Jobs` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table JobsLog
# ------------------------------------------------------------

DROP TABLE IF EXISTS `JobsLog`;

CREATE TABLE `JobsLog` (
  `jlID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jID` int(10) unsigned NOT NULL,
  `jlMessage` varchar(255) NOT NULL,
  `jlTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jlError` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`jlID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table LayoutPresets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LayoutPresets`;

CREATE TABLE `LayoutPresets` (
  `lpID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lpName` varchar(128) NOT NULL,
  `layoutID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`lpID`),
  UNIQUE KEY `layoutID` (`layoutID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Layouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Layouts`;

CREATE TABLE `Layouts` (
  `layoutID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `layout_rows` int(5) NOT NULL DEFAULT '3',
  `layout_columns` int(3) NOT NULL DEFAULT '3',
  `spacing` int(3) NOT NULL DEFAULT '3',
  `breakpoints` varchar(255) NOT NULL DEFAULT '',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`layoutID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Logs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Logs`;

CREATE TABLE `Logs` (
  `logID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logType` varchar(64) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logText` longtext,
  `logUserID` int(10) unsigned DEFAULT NULL,
  `logIsInternal` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`logID`),
  KEY `logType` (`logType`),
  KEY `logIsInternal` (`logIsInternal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table MailImporters
# ------------------------------------------------------------

DROP TABLE IF EXISTS `MailImporters`;

CREATE TABLE `MailImporters` (
  `miID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `miHandle` varchar(64) NOT NULL,
  `miServer` varchar(255) DEFAULT NULL,
  `miUsername` varchar(255) DEFAULT NULL,
  `miPassword` varchar(255) DEFAULT NULL,
  `miEncryption` varchar(32) DEFAULT NULL,
  `miIsEnabled` int(1) NOT NULL DEFAULT '0',
  `miEmail` varchar(255) DEFAULT NULL,
  `miPort` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned DEFAULT NULL,
  `miConnectionMethod` varchar(8) DEFAULT 'POP',
  PRIMARY KEY (`miID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `MailImporters` WRITE;
/*!40000 ALTER TABLE `MailImporters` DISABLE KEYS */;

INSERT INTO `MailImporters` (`miID`, `miHandle`, `miServer`, `miUsername`, `miPassword`, `miEncryption`, `miIsEnabled`, `miEmail`, `miPort`, `pkgID`, `miConnectionMethod`)
VALUES
	(1,'private_message',NULL,NULL,NULL,NULL,0,NULL,0,0,'POP');

/*!40000 ALTER TABLE `MailImporters` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table MailValidationHashes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `MailValidationHashes`;

CREATE TABLE `MailValidationHashes` (
  `mvhID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `miID` int(10) unsigned NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `mHash` varchar(128) NOT NULL,
  `mDateGenerated` int(10) unsigned NOT NULL DEFAULT '0',
  `mDateRedeemed` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`mvhID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Packages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Packages`;

CREATE TABLE `Packages` (
  `pkgID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pkgName` varchar(255) NOT NULL,
  `pkgHandle` varchar(64) NOT NULL,
  `pkgDescription` text,
  `pkgDateInstalled` datetime NOT NULL,
  `pkgIsInstalled` tinyint(1) NOT NULL DEFAULT '1',
  `pkgVersion` varchar(32) DEFAULT NULL,
  `pkgAvailableVersion` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`pkgID`),
  UNIQUE KEY `pkgHandle` (`pkgHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Packages` WRITE;
/*!40000 ALTER TABLE `Packages` DISABLE KEYS */;

INSERT INTO `Packages` (`pkgID`, `pkgName`, `pkgHandle`, `pkgDescription`, `pkgDateInstalled`, `pkgIsInstalled`, `pkgVersion`, `pkgAvailableVersion`)
VALUES
	(1,'Sortable Fancybox Gallery','sortable_fancybox_gallery','Displays images in a fileset (with an optional lightbox), and allows you to change their display order via drag-and-drop.','2013-04-27 20:27:40',1,'1.17',NULL);

/*!40000 ALTER TABLE `Packages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PagePaths
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePaths`;

CREATE TABLE `PagePaths` (
  `ppID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned DEFAULT '0',
  `cPath` text,
  `ppIsCanonical` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ppID`),
  KEY `cID` (`cID`),
  KEY `ppIsCanonical` (`ppIsCanonical`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PagePaths` WRITE;
/*!40000 ALTER TABLE `PagePaths` DISABLE KEYS */;

INSERT INTO `PagePaths` (`ppID`, `cID`, `cPath`, `ppIsCanonical`)
VALUES
	(1,2,'/dashboard','1'),
	(2,3,'/dashboard/composer','1'),
	(3,4,'/dashboard/composer/write','1'),
	(4,5,'/dashboard/composer/drafts','1'),
	(5,6,'/dashboard/sitemap','1'),
	(6,7,'/dashboard/sitemap/full','1'),
	(7,8,'/dashboard/sitemap/explore','1'),
	(8,9,'/dashboard/sitemap/search','1'),
	(9,10,'/dashboard/files','1'),
	(10,11,'/dashboard/files/search','1'),
	(11,12,'/dashboard/files/attributes','1'),
	(12,13,'/dashboard/files/sets','1'),
	(13,14,'/dashboard/files/add_set','1'),
	(14,15,'/dashboard/users','1'),
	(15,16,'/dashboard/users/search','1'),
	(16,17,'/dashboard/users/groups','1'),
	(17,18,'/dashboard/users/attributes','1'),
	(18,19,'/dashboard/users/add','1'),
	(19,20,'/dashboard/users/add_group','1'),
	(20,21,'/dashboard/users/group_sets','1'),
	(21,22,'/dashboard/reports','1'),
	(22,23,'/dashboard/reports/statistics','1'),
	(23,24,'/dashboard/reports/forms','1'),
	(24,25,'/dashboard/reports/surveys','1'),
	(25,26,'/dashboard/reports/logs','1'),
	(26,27,'/dashboard/pages','1'),
	(27,28,'/dashboard/pages/themes','1'),
	(28,29,'/dashboard/pages/themes/add','1'),
	(29,30,'/dashboard/pages/themes/inspect','1'),
	(30,31,'/dashboard/pages/themes/customize','1'),
	(31,32,'/dashboard/pages/types','1'),
	(32,33,'/dashboard/pages/types/add','1'),
	(33,34,'/dashboard/pages/attributes','1'),
	(34,35,'/dashboard/pages/single','1'),
	(35,36,'/dashboard/workflow','1'),
	(36,37,'/dashboard/workflow/list','1'),
	(37,38,'/dashboard/workflow/me','1'),
	(38,39,'/dashboard/blocks','1'),
	(39,40,'/dashboard/blocks/stacks','1'),
	(40,41,'/dashboard/blocks/permissions','1'),
	(41,42,'/dashboard/blocks/stacks/list','1'),
	(42,43,'/dashboard/blocks/types','1'),
	(43,44,'/dashboard/extend','1'),
	(44,45,'/dashboard/news','1'),
	(45,46,'/dashboard/extend/install','1'),
	(46,47,'/dashboard/extend/update','1'),
	(47,48,'/dashboard/extend/connect','1'),
	(48,49,'/dashboard/extend/themes','1'),
	(49,50,'/dashboard/extend/add-ons','1'),
	(50,51,'/dashboard/system','1'),
	(51,52,'/dashboard/system/basics','1'),
	(52,53,'/dashboard/system/basics/site_name','1'),
	(53,54,'/dashboard/system/basics/icons','1'),
	(54,55,'/dashboard/system/basics/editor','1'),
	(55,56,'/dashboard/system/basics/multilingual','1'),
	(56,57,'/dashboard/system/basics/timezone','1'),
	(57,58,'/dashboard/system/basics/interface','1'),
	(58,59,'/dashboard/system/seo','1'),
	(59,60,'/dashboard/system/seo/urls','1'),
	(60,61,'/dashboard/system/seo/bulk_seo_tool','1'),
	(61,62,'/dashboard/system/seo/tracking_codes','1'),
	(62,63,'/dashboard/system/seo/excluded','1'),
	(63,64,'/dashboard/system/seo/statistics','1'),
	(64,65,'/dashboard/system/seo/search_index','1'),
	(65,66,'/dashboard/system/optimization','1'),
	(66,67,'/dashboard/system/optimization/cache','1'),
	(67,68,'/dashboard/system/optimization/clear_cache','1'),
	(68,69,'/dashboard/system/optimization/jobs','1'),
	(69,70,'/dashboard/system/permissions','1'),
	(70,71,'/dashboard/system/permissions/site','1'),
	(71,72,'/dashboard/system/permissions/files','1'),
	(72,73,'/dashboard/system/permissions/file_types','1'),
	(73,74,'/dashboard/system/permissions/tasks','1'),
	(74,75,'/dashboard/system/permissions/users','1'),
	(75,76,'/dashboard/system/permissions/advanced','1'),
	(76,77,'/dashboard/system/permissions/ip_blacklist','1'),
	(77,78,'/dashboard/system/permissions/captcha','1'),
	(78,79,'/dashboard/system/permissions/antispam','1'),
	(79,80,'/dashboard/system/permissions/maintenance_mode','1'),
	(80,81,'/dashboard/system/registration','1'),
	(81,82,'/dashboard/system/registration/postlogin','1'),
	(82,83,'/dashboard/system/registration/profiles','1'),
	(83,84,'/dashboard/system/registration/public_registration','1'),
	(84,85,'/dashboard/system/mail','1'),
	(85,86,'/dashboard/system/mail/method','1'),
	(86,87,'/dashboard/system/mail/importers','1'),
	(87,88,'/dashboard/system/attributes','1'),
	(88,89,'/dashboard/system/attributes/sets','1'),
	(89,90,'/dashboard/system/attributes/types','1'),
	(90,91,'/dashboard/system/environment','1'),
	(91,92,'/dashboard/system/environment/info','1'),
	(92,93,'/dashboard/system/environment/debug','1'),
	(93,94,'/dashboard/system/environment/logging','1'),
	(94,95,'/dashboard/system/environment/file_storage_locations','1'),
	(95,96,'/dashboard/system/environment/proxy','1'),
	(96,97,'/dashboard/system/backup_restore','1'),
	(97,98,'/dashboard/system/backup_restore/backup','1'),
	(98,99,'/dashboard/system/backup_restore/update','1'),
	(99,100,'/dashboard/system/backup_restore/database','1'),
	(100,101,'/dashboard/pages/types/composer','1'),
	(101,105,'/dashboard/home','1'),
	(102,106,'/dashboard/welcome','1'),
	(103,107,'/!drafts','1'),
	(104,108,'/!trash','1'),
	(105,109,'/!stacks','1'),
	(106,110,'/login','1'),
	(107,111,'/register','1'),
	(108,112,'/profile','1'),
	(109,113,'/profile/edit','1'),
	(110,114,'/profile/avatar','1'),
	(111,115,'/profile/messages','1'),
	(112,116,'/profile/friends','1'),
	(113,117,'/page_not_found','1'),
	(114,118,'/page_forbidden','1'),
	(115,119,'/download_file','1'),
	(116,120,'/members','1'),
	(117,121,'/!stacks/header-nav','1'),
	(118,122,'/!stacks/side-nav','1'),
	(119,123,'/!stacks/site-name','1'),
	(127,129,'/!trash/blog','1'),
	(129,134,'/!trash/blog/hello-world','1'),
	(130,132,'/!trash/guestbook','1'),
	(131,133,'/!trash/blog-archives','1'),
	(132,130,'/!trash/search','1'),
	(133,128,'/!trash/about','1'),
	(135,131,'/!trash/contact-us','1');

/*!40000 ALTER TABLE `PagePaths` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PagePermissionAssignments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePermissionAssignments`;

CREATE TABLE `PagePermissionAssignments` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkID` int(10) unsigned NOT NULL DEFAULT '0',
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`pkID`,`paID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PagePermissionAssignments` WRITE;
/*!40000 ALTER TABLE `PagePermissionAssignments` DISABLE KEYS */;

INSERT INTO `PagePermissionAssignments` (`cID`, `pkID`, `paID`)
VALUES
	(1,1,45),
	(1,2,46),
	(1,3,47),
	(1,4,48),
	(1,5,49),
	(1,6,50),
	(1,7,51),
	(1,8,52),
	(1,9,53),
	(1,10,54),
	(1,11,55),
	(1,12,56),
	(1,13,57),
	(1,14,58),
	(1,15,59),
	(2,1,18),
	(2,2,19),
	(2,3,24),
	(2,4,20),
	(2,5,21),
	(2,6,26),
	(2,7,28),
	(2,8,30),
	(2,9,27),
	(2,10,31),
	(2,11,32),
	(2,12,22),
	(2,13,25),
	(2,14,23),
	(2,15,29),
	(42,1,33),
	(110,1,34),
	(111,1,35);

/*!40000 ALTER TABLE `PagePermissionAssignments` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PagePermissionPageTypeAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePermissionPageTypeAccessList`;

CREATE TABLE `PagePermissionPageTypeAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  `externalLink` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PagePermissionPageTypeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePermissionPageTypeAccessListCustom`;

CREATE TABLE `PagePermissionPageTypeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`ctID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PagePermissionPropertyAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePermissionPropertyAccessList`;

CREATE TABLE `PagePermissionPropertyAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `name` int(1) unsigned DEFAULT '0',
  `publicDateTime` int(1) unsigned DEFAULT '0',
  `uID` int(1) unsigned DEFAULT '0',
  `description` int(1) unsigned DEFAULT '0',
  `paths` int(1) unsigned DEFAULT '0',
  `attributePermission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PagePermissionPropertyAttributeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePermissionPropertyAttributeAccessListCustom`;

CREATE TABLE `PagePermissionPropertyAttributeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PagePermissionThemeAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePermissionThemeAccessList`;

CREATE TABLE `PagePermissionThemeAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PagePermissionThemeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PagePermissionThemeAccessListCustom`;

CREATE TABLE `PagePermissionThemeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `ptID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`ptID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Pages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Pages`;

CREATE TABLE `Pages` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `cIsTemplate` int(1) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned DEFAULT NULL,
  `cIsCheckedOut` tinyint(1) NOT NULL DEFAULT '0',
  `cCheckedOutUID` int(10) unsigned DEFAULT NULL,
  `cCheckedOutDatetime` datetime DEFAULT NULL,
  `cCheckedOutDatetimeLastEdit` datetime DEFAULT NULL,
  `cOverrideTemplatePermissions` tinyint(1) NOT NULL DEFAULT '1',
  `cInheritPermissionsFromCID` int(10) unsigned NOT NULL DEFAULT '0',
  `cInheritPermissionsFrom` varchar(8) NOT NULL DEFAULT 'PARENT',
  `cFilename` varchar(255) DEFAULT NULL,
  `cPointerID` int(10) unsigned NOT NULL DEFAULT '0',
  `cPointerExternalLink` varchar(255) DEFAULT NULL,
  `cPointerExternalLinkNewWindow` tinyint(1) NOT NULL DEFAULT '0',
  `cIsActive` tinyint(1) NOT NULL DEFAULT '1',
  `cChildren` int(10) unsigned NOT NULL DEFAULT '0',
  `cDisplayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  `cParentID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  `cCacheFullPageContent` int(4) NOT NULL DEFAULT '-1',
  `cCacheFullPageContentOverrideLifetime` varchar(32) NOT NULL DEFAULT '0',
  `cCacheFullPageContentLifetimeCustom` int(10) unsigned NOT NULL DEFAULT '0',
  `cIsSystemPage` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`),
  KEY `cParentID` (`cParentID`),
  KEY `cIsActive` (`cIsActive`),
  KEY `cCheckedOutUID` (`cCheckedOutUID`),
  KEY `uID` (`uID`),
  KEY `cPointerID` (`cPointerID`),
  KEY `cIsTemplate` (`cIsTemplate`),
  KEY `cIsSystemPage` (`cIsSystemPage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Pages` WRITE;
/*!40000 ALTER TABLE `Pages` DISABLE KEYS */;

INSERT INTO `Pages` (`cID`, `cIsTemplate`, `uID`, `cIsCheckedOut`, `cCheckedOutUID`, `cCheckedOutDatetime`, `cCheckedOutDatetimeLastEdit`, `cOverrideTemplatePermissions`, `cInheritPermissionsFromCID`, `cInheritPermissionsFrom`, `cFilename`, `cPointerID`, `cPointerExternalLink`, `cPointerExternalLinkNewWindow`, `cIsActive`, `cChildren`, `cDisplayOrder`, `cParentID`, `pkgID`, `cCacheFullPageContent`, `cCacheFullPageContentOverrideLifetime`, `cCacheFullPageContentLifetimeCustom`, `cIsSystemPage`)
VALUES
	(1,0,1,0,NULL,NULL,NULL,1,1,'OVERRIDE',NULL,0,NULL,0,1,11,0,0,0,-1,'0',0,0),
	(2,0,1,0,NULL,NULL,NULL,1,2,'OVERRIDE','/dashboard/view.php',0,NULL,0,1,13,0,0,0,-1,'0',0,1),
	(3,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/composer/view.php',0,NULL,0,1,2,0,2,0,-1,'0',0,1),
	(4,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/composer/write.php',0,NULL,0,1,0,0,3,0,-1,'0',0,1),
	(5,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/composer/drafts.php',0,NULL,0,1,0,1,3,0,-1,'0',0,1),
	(6,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/sitemap/view.php',0,NULL,0,1,3,1,2,0,-1,'0',0,1),
	(7,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/sitemap/full.php',0,NULL,0,1,0,0,6,0,-1,'0',0,1),
	(8,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/sitemap/explore.php',0,NULL,0,1,0,1,6,0,-1,'0',0,1),
	(9,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/sitemap/search.php',0,NULL,0,1,0,2,6,0,-1,'0',0,1),
	(10,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/files/view.php',0,NULL,0,1,4,2,2,0,-1,'0',0,1),
	(11,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/files/search.php',0,NULL,0,1,0,0,10,0,-1,'0',0,1),
	(12,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/files/attributes.php',0,NULL,0,1,0,1,10,0,-1,'0',0,1),
	(13,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/files/sets.php',0,NULL,0,1,0,2,10,0,-1,'0',0,1),
	(14,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/files/add_set.php',0,NULL,0,1,0,3,10,0,-1,'0',0,1),
	(15,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/users/view.php',0,NULL,0,1,6,3,2,0,-1,'0',0,1),
	(16,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/users/search.php',0,NULL,0,1,0,0,15,0,-1,'0',0,1),
	(17,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/users/groups.php',0,NULL,0,1,0,1,15,0,-1,'0',0,1),
	(18,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/users/attributes.php',0,NULL,0,1,0,2,15,0,-1,'0',0,1),
	(19,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/users/add.php',0,NULL,0,1,0,3,15,0,-1,'0',0,1),
	(20,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/users/add_group.php',0,NULL,0,1,0,4,15,0,-1,'0',0,1),
	(21,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/users/group_sets.php',0,NULL,0,1,0,5,15,0,-1,'0',0,1),
	(22,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/reports.php',0,NULL,0,1,4,4,2,0,-1,'0',0,1),
	(23,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/reports/statistics.php',0,NULL,0,1,0,0,22,0,-1,'0',0,1),
	(24,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/reports/forms.php',0,NULL,0,1,0,1,22,0,-1,'0',0,1),
	(25,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/reports/surveys.php',0,NULL,0,1,0,2,22,0,-1,'0',0,1),
	(26,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/reports/logs.php',0,NULL,0,1,0,3,22,0,-1,'0',0,1),
	(27,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/view.php',0,NULL,0,1,4,5,2,0,-1,'0',0,1),
	(28,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/themes/view.php',0,NULL,0,1,3,0,27,0,-1,'0',0,1),
	(29,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/themes/add.php',0,NULL,0,1,0,0,28,0,-1,'0',0,1),
	(30,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/themes/inspect.php',0,NULL,0,1,0,1,28,0,-1,'0',0,1),
	(31,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/themes/customize.php',0,NULL,0,1,0,2,28,0,-1,'0',0,1),
	(32,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/types/view.php',0,NULL,0,1,2,1,27,0,-1,'0',0,1),
	(33,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/types/add.php',0,NULL,0,1,0,0,32,0,-1,'0',0,1),
	(34,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/attributes.php',0,NULL,0,1,0,2,27,0,-1,'0',0,1),
	(35,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/single.php',0,NULL,0,1,0,3,27,0,-1,'0',0,1),
	(36,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/workflow/view.php',0,NULL,0,1,2,6,2,0,-1,'0',0,1),
	(37,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/workflow/list.php',0,NULL,0,1,0,0,36,0,-1,'0',0,1),
	(38,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/workflow/me.php',0,NULL,0,1,0,1,36,0,-1,'0',0,1),
	(39,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/blocks/view.php',0,NULL,0,1,3,7,2,0,-1,'0',0,1),
	(40,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/blocks/stacks/view.php',0,NULL,0,1,1,0,39,0,-1,'0',0,1),
	(41,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/blocks/permissions.php',0,NULL,0,1,0,1,39,0,-1,'0',0,1),
	(42,0,1,0,NULL,NULL,NULL,1,42,'OVERRIDE','/dashboard/blocks/stacks/list/view.php',0,NULL,0,1,0,0,40,0,-1,'0',0,1),
	(43,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/blocks/types/view.php',0,NULL,0,1,0,2,39,0,-1,'0',0,1),
	(44,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/extend/view.php',0,NULL,0,1,5,8,2,0,-1,'0',0,1),
	(45,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/news.php',0,NULL,0,1,0,9,2,0,-1,'0',0,1),
	(46,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/extend/install.php',0,NULL,0,1,0,0,44,0,-1,'0',0,1),
	(47,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/extend/update.php',0,NULL,0,1,0,1,44,0,-1,'0',0,1),
	(48,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/extend/connect.php',0,NULL,0,1,0,2,44,0,-1,'0',0,1),
	(49,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/extend/themes.php',0,NULL,0,1,0,3,44,0,-1,'0',0,1),
	(50,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/extend/add-ons.php',0,NULL,0,1,0,4,44,0,-1,'0',0,1),
	(51,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/view.php',0,NULL,0,1,9,10,2,0,-1,'0',0,1),
	(52,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/basics/view.php',0,NULL,0,1,6,0,51,0,-1,'0',0,1),
	(53,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/basics/site_name.php',0,NULL,0,1,0,0,52,0,-1,'0',0,1),
	(54,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/basics/icons.php',0,NULL,0,1,0,1,52,0,-1,'0',0,1),
	(55,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/basics/editor.php',0,NULL,0,1,0,2,52,0,-1,'0',0,1),
	(56,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/basics/multilingual/view.php',0,NULL,0,1,0,3,52,0,-1,'0',0,1),
	(57,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/basics/timezone.php',0,NULL,0,1,0,4,52,0,-1,'0',0,1),
	(58,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/basics/interface.php',0,NULL,0,1,0,5,52,0,-1,'0',0,1),
	(59,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/seo/view.php',0,NULL,0,1,6,1,51,0,-1,'0',0,1),
	(60,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/seo/urls.php',0,NULL,0,1,0,0,59,0,-1,'0',0,1),
	(61,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/seo/bulk_seo_tool.php',0,NULL,0,1,0,1,59,0,-1,'0',0,1),
	(62,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/seo/tracking_codes.php',0,NULL,0,1,0,2,59,0,-1,'0',0,1),
	(63,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/seo/excluded.php',0,NULL,0,1,0,3,59,0,-1,'0',0,1),
	(64,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/seo/statistics.php',0,NULL,0,1,0,4,59,0,-1,'0',0,1),
	(65,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/seo/search_index.php',0,NULL,0,1,0,5,59,0,-1,'0',0,1),
	(66,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/optimization/view.php',0,NULL,0,1,3,2,51,0,-1,'0',0,1),
	(67,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/optimization/cache.php',0,NULL,0,1,0,0,66,0,-1,'0',0,1),
	(68,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/optimization/clear_cache.php',0,NULL,0,1,0,1,66,0,-1,'0',0,1),
	(69,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/optimization/jobs.php',0,NULL,0,1,0,2,66,0,-1,'0',0,1),
	(70,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/view.php',0,NULL,0,1,10,3,51,0,-1,'0',0,1),
	(71,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/site.php',0,NULL,0,1,0,0,70,0,-1,'0',0,1),
	(72,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/files.php',0,NULL,0,1,0,1,70,0,-1,'0',0,1),
	(73,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/file_types.php',0,NULL,0,1,0,2,70,0,-1,'0',0,1),
	(74,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/tasks.php',0,NULL,0,1,0,3,70,0,-1,'0',0,1),
	(75,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/users.php',0,NULL,0,1,0,4,70,0,-1,'0',0,1),
	(76,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/advanced.php',0,NULL,0,1,0,5,70,0,-1,'0',0,1),
	(77,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/ip_blacklist.php',0,NULL,0,1,0,6,70,0,-1,'0',0,1),
	(78,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/captcha.php',0,NULL,0,1,0,7,70,0,-1,'0',0,1),
	(79,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/antispam.php',0,NULL,0,1,0,8,70,0,-1,'0',0,1),
	(80,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/permissions/maintenance_mode.php',0,NULL,0,1,0,9,70,0,-1,'0',0,1),
	(81,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/registration/view.php',0,NULL,0,1,3,4,51,0,-1,'0',0,1),
	(82,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/registration/postlogin.php',0,NULL,0,1,0,0,81,0,-1,'0',0,1),
	(83,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/registration/profiles.php',0,NULL,0,1,0,1,81,0,-1,'0',0,1),
	(84,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/registration/public_registration.php',0,NULL,0,1,0,2,81,0,-1,'0',0,1),
	(85,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/mail/view.php',0,NULL,0,1,2,5,51,0,-1,'0',0,1),
	(86,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/mail/method.php',0,NULL,0,1,0,0,85,0,-1,'0',0,1),
	(87,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/mail/importers.php',0,NULL,0,1,0,1,85,0,-1,'0',0,1),
	(88,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/attributes/view.php',0,NULL,0,1,2,6,51,0,-1,'0',0,1),
	(89,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/attributes/sets.php',0,NULL,0,1,0,0,88,0,-1,'0',0,1),
	(90,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/attributes/types.php',0,NULL,0,1,0,1,88,0,-1,'0',0,1),
	(91,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/environment/view.php',0,NULL,0,1,5,7,51,0,-1,'0',0,1),
	(92,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/environment/info.php',0,NULL,0,1,0,0,91,0,-1,'0',0,1),
	(93,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/environment/debug.php',0,NULL,0,1,0,1,91,0,-1,'0',0,1),
	(94,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/environment/logging.php',0,NULL,0,1,0,2,91,0,-1,'0',0,1),
	(95,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/environment/file_storage_locations.php',0,NULL,0,1,0,3,91,0,-1,'0',0,1),
	(96,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/environment/proxy.php',0,NULL,0,1,0,4,91,0,-1,'0',0,1),
	(97,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/backup_restore/view.php',0,NULL,0,1,3,8,51,0,-1,'0',0,1),
	(98,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/backup_restore/backup.php',0,NULL,0,1,0,0,97,0,-1,'0',0,1),
	(99,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/backup_restore/update.php',0,NULL,0,1,0,1,97,0,-1,'0',0,1),
	(100,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/system/backup_restore/database.php',0,NULL,0,1,0,2,97,0,-1,'0',0,1),
	(101,0,1,0,NULL,NULL,NULL,1,2,'PARENT','/dashboard/pages/types/composer.php',0,NULL,0,1,0,1,32,0,-1,'0',0,1),
	(102,1,NULL,0,NULL,NULL,NULL,1,0,'PARENT',NULL,0,NULL,0,1,0,0,0,0,-1,'0',0,0),
	(103,1,NULL,0,NULL,NULL,NULL,1,0,'PARENT',NULL,0,NULL,0,1,0,0,0,0,-1,'0',0,0),
	(104,1,NULL,0,NULL,NULL,NULL,1,0,'PARENT',NULL,0,NULL,0,1,0,0,0,0,-1,'0',0,0),
	(105,0,1,0,NULL,NULL,NULL,1,2,'PARENT',NULL,0,NULL,0,1,0,11,2,0,-1,'0',0,1),
	(106,0,1,0,NULL,NULL,NULL,1,2,'PARENT',NULL,0,NULL,0,1,0,12,2,0,-1,'0',0,1),
	(107,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/!drafts/view.php',0,NULL,0,1,1,0,0,0,-1,'0',0,1),
	(108,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/!trash/view.php',0,NULL,0,1,6,0,0,0,-1,'0',0,1),
	(109,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/!stacks/view.php',0,NULL,0,1,3,0,0,0,-1,'0',0,1),
	(110,0,1,0,NULL,NULL,NULL,1,110,'OVERRIDE','/login.php',0,NULL,0,1,0,0,0,0,-1,'0',0,1),
	(111,0,1,0,NULL,NULL,NULL,1,111,'OVERRIDE','/register.php',0,NULL,0,1,0,0,0,0,-1,'0',0,1),
	(112,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/profile/view.php',0,NULL,0,1,4,0,1,0,-1,'0',0,1),
	(113,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/profile/edit.php',0,NULL,0,1,0,0,112,0,-1,'0',0,1),
	(114,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/profile/avatar.php',0,NULL,0,1,0,1,112,0,-1,'0',0,1),
	(115,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/profile/messages.php',0,NULL,0,1,0,2,112,0,-1,'0',0,1),
	(116,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/profile/friends.php',0,NULL,0,1,0,3,112,0,-1,'0',0,1),
	(117,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/page_not_found.php',0,NULL,0,1,0,1,0,0,-1,'0',0,1),
	(118,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/page_forbidden.php',0,NULL,0,1,0,1,0,0,-1,'0',0,1),
	(119,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/download_file.php',0,NULL,0,1,0,1,1,0,-1,'0',0,1),
	(120,0,1,0,NULL,NULL,NULL,1,1,'PARENT','/members.php',0,NULL,0,1,0,2,1,0,-1,'0',0,1),
	(121,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,1,0,0,109,0,-1,'0',0,1),
	(122,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,1,0,1,109,0,-1,'0',0,1),
	(123,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,1,0,2,109,0,-1,'0',0,1),
	(124,1,NULL,0,NULL,NULL,NULL,1,0,'PARENT',NULL,0,NULL,0,1,0,0,0,0,-1,'0',0,0),
	(125,1,NULL,0,NULL,NULL,NULL,1,0,'PARENT',NULL,0,NULL,0,1,0,0,0,0,-1,'0',0,0),
	(126,1,NULL,0,NULL,NULL,NULL,1,0,'PARENT',NULL,0,NULL,0,1,0,0,0,0,-1,'0',0,0),
	(127,1,NULL,0,NULL,NULL,NULL,1,0,'PARENT',NULL,0,NULL,0,1,0,0,0,0,-1,'0',0,0),
	(128,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,0,0,4,108,0,-1,'0',0,1),
	(129,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,0,1,0,108,0,-1,'0',0,1),
	(130,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,0,0,3,108,0,-1,'0',0,1),
	(131,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,0,0,5,108,0,-1,'0',0,1),
	(132,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,0,0,1,108,0,-1,'0',0,1),
	(133,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,0,0,2,108,0,-1,'0',0,1),
	(134,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,1,0,1,129,0,-1,'0',0,1),
	(135,0,1,0,NULL,NULL,NULL,1,1,'PARENT',NULL,0,NULL,0,0,0,0,107,0,-1,'0',0,0);

/*!40000 ALTER TABLE `Pages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PageSearchIndex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PageSearchIndex`;

CREATE TABLE `PageSearchIndex` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text,
  `cName` varchar(255) DEFAULT NULL,
  `cDescription` text,
  `cPath` text,
  `cDatePublic` datetime DEFAULT NULL,
  `cDateLastIndexed` datetime DEFAULT NULL,
  `cDateLastSitemapped` datetime DEFAULT NULL,
  `cRequiresReindex` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`cID`),
  KEY `cDateLastIndexed` (`cDateLastIndexed`),
  KEY `cDateLastSitemapped` (`cDateLastSitemapped`),
  KEY `cRequiresReindex` (`cRequiresReindex`),
  FULLTEXT KEY `cName` (`cName`),
  FULLTEXT KEY `cDescription` (`cDescription`),
  FULLTEXT KEY `content` (`content`),
  FULLTEXT KEY `content2` (`cName`,`cDescription`,`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `PageSearchIndex` WRITE;
/*!40000 ALTER TABLE `PageSearchIndex` DISABLE KEYS */;

INSERT INTO `PageSearchIndex` (`cID`, `content`, `cName`, `cDescription`, `cPath`, `cDatePublic`, `cDateLastIndexed`, `cDateLastSitemapped`, `cRequiresReindex`)
VALUES
	(3,'','Composer','Write for your site.','/dashboard/composer','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(4,'','Write','','/dashboard/composer/write','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(5,'','Drafts','','/dashboard/composer/drafts','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(6,'','Sitemap','Whole world at a glance.','/dashboard/sitemap','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(7,'','Full Sitemap','','/dashboard/sitemap/full','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(8,'','Flat View','','/dashboard/sitemap/explore','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(9,'','Page Search','','/dashboard/sitemap/search','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(11,'','File Manager','','/dashboard/files/search','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(12,'','Attributes','','/dashboard/files/attributes','2013-04-27 15:01:37','2013-04-27 15:01:41',NULL,0),
	(13,'','File Sets','','/dashboard/files/sets','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(14,'','Add File Set','','/dashboard/files/add_set','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(15,'','Members','Add and manage the user accounts and groups on your website.','/dashboard/users','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(16,'','Search Users','','/dashboard/users/search','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(17,'','User Groups','','/dashboard/users/groups','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(18,'','Attributes','','/dashboard/users/attributes','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(19,'','Add User','','/dashboard/users/add','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(20,'','Add Group','','/dashboard/users/add_group','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(21,'','Group Sets','','/dashboard/users/group_sets','2013-04-27 15:01:37','2013-04-27 15:01:42',NULL,0),
	(22,'','Reports','Get data from forms and logs.','/dashboard/reports','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(23,'','Statistics','View your site activity.','/dashboard/reports/statistics','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(24,'','Form Results','Get submission data.','/dashboard/reports/forms','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(25,'','Surveys','','/dashboard/reports/surveys','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(26,'','Logs','','/dashboard/reports/logs','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(28,'','Themes','Reskin your site.','/dashboard/pages/themes','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(29,'','Add','','/dashboard/pages/themes/add','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(30,'','Inspect','','/dashboard/pages/themes/inspect','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(31,'','Customize','','/dashboard/pages/themes/customize','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(32,'','Page Types','What goes in your site.','/dashboard/pages/types','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(34,'','Attributes','','/dashboard/pages/attributes','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(35,'','Single Pages','','/dashboard/pages/single','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(36,'','Workflow','','/dashboard/workflow','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(37,'','Workflow List','','/dashboard/workflow/list','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(38,'','Waiting for Me','','/dashboard/workflow/me','2013-04-27 15:01:38','2013-04-27 15:01:42',NULL,0),
	(40,'','Stacks','Share content across your site.','/dashboard/blocks/stacks','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(41,'','Block & Stack Permissions','Control who can add blocks and stacks on your site.','/dashboard/blocks/permissions','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(42,'','Stack List','','/dashboard/blocks/stacks/list','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(43,'','Block Types','Manage the installed block types in your site.','/dashboard/blocks/types','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(44,'','Extend concrete5','Connect to the concrete5 marketplace, install custom add-ons, and download updates for marketplace add-ons and themes.','/dashboard/extend','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(45,'','Dashboard','','/dashboard/news','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(46,'','Add Functionality','Install add-ons & themes.','/dashboard/extend/install','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(47,'','Update Add-Ons','Update your installed packages.','/dashboard/extend/update','2013-04-27 15:01:38','2013-04-27 15:01:43',NULL,0),
	(48,'','Connect to the Community','Connect to the concrete5 community.','/dashboard/extend/connect','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(49,'','Get More Themes','Download themes from concrete5.org.','/dashboard/extend/themes','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(50,'','Get More Add-Ons','Download add-ons from concrete5.org.','/dashboard/extend/add-ons','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(51,'','System & Settings','Secure and setup your site.','/dashboard/system','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(53,'','Site Name','','/dashboard/system/basics/site_name','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(54,'','Bookmark Icons','Bookmark icon and mobile home screen icon setup.','/dashboard/system/basics/icons','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(55,'','Rich Text Editor','','/dashboard/system/basics/editor','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(56,'','Languages','','/dashboard/system/basics/multilingual','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(57,'','Time Zone','','/dashboard/system/basics/timezone','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(58,'','Interface Preferences','','/dashboard/system/basics/interface','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(60,'','Pretty URLs','','/dashboard/system/seo/urls','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(61,'','Bulk SEO Updater','','/dashboard/system/seo/bulk_seo_tool','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(62,'','Tracking Codes','','/dashboard/system/seo/tracking_codes','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(63,'','Excluded URL Word List','','/dashboard/system/seo/excluded','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(64,'','Statistics','','/dashboard/system/seo/statistics','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(65,'','Search Index','','/dashboard/system/seo/search_index','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(67,'','Cache & Speed Settings','','/dashboard/system/optimization/cache','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(68,'','Clear Cache','','/dashboard/system/optimization/clear_cache','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(69,'','Automated Jobs','','/dashboard/system/optimization/jobs','2013-04-27 15:01:39','2013-04-27 15:01:43',NULL,0),
	(71,'','Site Access','','/dashboard/system/permissions/site','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(72,'','File Manager Permissions','','/dashboard/system/permissions/files','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(73,'','Allowed File Types','','/dashboard/system/permissions/file_types','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(74,'','Task Permissions','','/dashboard/system/permissions/tasks','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(77,'','IP Blacklist','','/dashboard/system/permissions/ip_blacklist','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(78,'','Captcha Setup','','/dashboard/system/permissions/captcha','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(79,'','Spam Control','','/dashboard/system/permissions/antispam','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(80,'','Maintenance Mode','','/dashboard/system/permissions/maintenance_mode','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(82,'','Login Destination','','/dashboard/system/registration/postlogin','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(83,'','Public Profiles','','/dashboard/system/registration/profiles','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(84,'','Public Registration','','/dashboard/system/registration/public_registration','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(85,'','Email','Control how your site send and processes mail.','/dashboard/system/mail','2013-04-27 15:01:40','2013-04-27 15:01:43',NULL,0),
	(86,'','SMTP Method','','/dashboard/system/mail/method','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(87,'','Email Importers','','/dashboard/system/mail/importers','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(88,'','Attributes','Setup attributes for pages, users, files and more.','/dashboard/system/attributes','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(89,'','Sets','Group attributes into sets for easier organization','/dashboard/system/attributes/sets','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(90,'','Types','Choose which attribute types are available for different items.','/dashboard/system/attributes/types','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(91,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),
	(92,'','Environment Information','','/dashboard/system/environment/info','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(93,'','Debug Settings','','/dashboard/system/environment/debug','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(94,'','Logging Settings','','/dashboard/system/environment/logging','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(95,'','File Storage Locations','','/dashboard/system/environment/file_storage_locations','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(96,'','Proxy Server','','/dashboard/system/environment/proxy','2013-04-27 15:01:40','2013-04-27 15:01:44',NULL,0),
	(97,'','Backup & Restore','Backup or restore your website.','/dashboard/system/backup_restore','2013-04-27 15:01:41','2013-04-27 15:01:44',NULL,0),
	(99,'','Update concrete5','','/dashboard/system/backup_restore/update','2013-04-27 15:01:41','2013-04-27 15:01:44',NULL,0),
	(100,'','Database XML','','/dashboard/system/backup_restore/database','2013-04-27 15:01:41','2013-04-27 15:01:44',NULL,0),
	(106,'	Welcome to concrete5.\n						It\'s easy to edit content and add pages using in-context editing. \n						 \n							Building Your Own Site\n							 Editing with concrete5 is a breeze. Just point and click to make changes. \n							 \n							 Editor\'s Guide \n							  \n							Developing Applications\n							 If you’re comfortable in PHP concrete5 should be a breeze to learn. Take a few moments to understand the architecture. \n							 Developer\'s Guide \n							  \n							Designing Websites\n							 Good with CSS and HTML? You can easily theme anything with concrete5. \n							 \n							 Designer\'s Guide \n							  \n						\n						Business Background\n						 Worried about license structures, white-labeling or why concrete5 is a good choice for your agency? \n						 Executive\'s Guide \n						  ','Welcome to concrete5','Learn about how to use concrete5, how to develop for concrete5, and get general help.','/dashboard/welcome','2013-04-27 15:01:41','2013-04-27 15:01:44',NULL,0),
	(105,'','Customize Dashboard Home','','/dashboard/home','2013-04-27 15:01:41','2013-04-27 15:01:44',NULL,0),
	(1,'Sidebar  Everything about concrete5 is completely customizable through the CMS. This is a separate area from the main content on the homepage. You can&nbsp;drag and drop blocks&nbsp;like this around your layout.  Welcome to concrete5!\n                                         Content Management is easy with concrete5\'s in-context editing. Just login and you can change things as you browse your site. \n                                         You can watch videos and learn how to: \n                                        \n                                        Edit&nbsp;this page.\n                                        Add a new page.\n                                        Add some basic functionality, like&nbsp;a Form.\n                                        Finding &amp; adding&nbsp;more functionality and themes.\n                                        \n                                         We\'ve taken the liberty to build out the rest of this site with some sample content that will help you learn concrete5. Wander around a bit, or click Dashboard to get to the&nbsp;Sitemap and quickly delete the parts you don\'t want.   Rock Solid.   Dedicated to quality work and craftsmanship, Fanning Landscape Solutions Limited is a landscape design and construction company specializing in hardscape features for both commercial and residential properties. \r\n FLS founder, Dennis Fanning, is an award winning craftsman with 15 years of landscaping experience. Dennis earned a degree in Turf Management &amp; Landscape Technology from Lake City College in Lake City, Florida. \r\n After working in the landscaping industry in Florida, the Carolinas and Virginia, Dennis returned home to bring his skills and keen eye for landscape design to Nova Scotia.  \r\nHardscapes\r\n\r\nRetaining Walls\r\nInterlock Driveways\r\nPool Surrounds\r\nGarden Walls\r\nInterlock Walkways\r\nStone Stairways\r\n\r\n \r\n\r\nSoftscapes\r\n\r\nGardening Services\r\nGrading\r\nLawns\r\nDrainage Solutions\r\n\r\n \r\n\r\nSpecialty\r\n\r\nOutdoor Living Spaces\r\nGolf Greens\r\nWater Features\r\nFire Pits\r\n\r\n   902.754.3636 \r\n dennis@fanninglandscapes.com  ','Home','',NULL,'2013-04-27 15:01:27','2013-04-27 21:49:23',NULL,0),
	(128,'Learn More\n																 Visit&nbsp;concrete5.org&nbsp;to learn more from the&nbsp;community&nbsp;and the&nbsp;documentation. You can also browse our&nbsp;marketplace&nbsp;for more&nbsp;add-ons&nbsp;and&nbsp;themes&nbsp;to quickly build the site you really need.&nbsp; \n																&nbsp;\n																Getting Help\n																 You can get free help in the forums and post for free to the&nbsp;jobs board.&nbsp; \n																 You can also pay the concrete5 team of developers to help with&nbsp;any problem&nbsp;you run into. We offer training courses&nbsp;and&nbsp;hosting packages, just let us know how we can help.  ','About','','/about','2013-04-27 15:01:47','2013-04-27 15:01:47',NULL,0),
	(132,'','Guestbook','','/about/guestbook','2013-04-27 15:01:47','2013-04-27 15:01:48',NULL,0),
	(131,'Contact Us\n									 Building a form is easy to do. Learn how to add a form block.  ','Contact Us','','/about/contact-us','2013-04-27 15:01:47','2013-04-27 15:01:48',NULL,0),
	(130,'Site Map ','Search','','/search','2013-04-27 15:01:47','2013-04-27 15:01:48',NULL,0),
	(129,'Tags ','Blog','','/blog','2013-04-27 15:01:47','2013-04-27 15:01:48',NULL,0),
	(134,' Here is some sample content! I\'m writing it using composer!  ','Hello World','This is my first blog post!','/blog/hello-world','2013-04-27 15:01:47','2013-04-27 15:01:48',NULL,0),
	(133,'','Blog Archives','','/blog/blog-archives','2013-04-27 15:01:47','2013-04-27 15:01:49',NULL,0);

/*!40000 ALTER TABLE `PageSearchIndex` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PageStatistics
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PageStatistics`;

CREATE TABLE `PageStatistics` (
  `pstID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pstID`),
  KEY `cID` (`cID`),
  KEY `date` (`date`),
  KEY `uID` (`uID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `PageStatistics` WRITE;
/*!40000 ALTER TABLE `PageStatistics` DISABLE KEYS */;

INSERT INTO `PageStatistics` (`pstID`, `cID`, `date`, `timestamp`, `uID`)
VALUES
	(1,1,'2013-04-27','2013-04-27 15:04:39',1),
	(2,106,'2013-04-27','2013-04-27 15:04:41',1),
	(3,106,'2013-04-27','2013-04-27 15:05:17',1),
	(4,2,'2013-04-27','2013-04-27 15:44:11',1),
	(5,28,'2013-04-27','2013-04-27 15:44:17',1),
	(6,28,'2013-04-27','2013-04-27 19:57:52',1),
	(7,30,'2013-04-27','2013-04-27 19:57:52',1),
	(8,28,'2013-04-27','2013-04-27 19:58:02',1),
	(9,28,'2013-04-27','2013-04-27 19:58:06',1),
	(10,28,'2013-04-27','2013-04-27 19:58:10',1),
	(11,1,'2013-04-27','2013-04-27 19:58:13',1),
	(12,2,'2013-04-27','2013-04-27 19:58:22',1),
	(13,35,'2013-04-27','2013-04-27 19:59:17',1),
	(14,2,'2013-04-27','2013-04-27 19:59:26',1),
	(15,7,'2013-04-27','2013-04-27 19:59:50',1),
	(16,7,'2013-04-27','2013-04-27 20:00:00',1),
	(17,2,'2013-04-27','2013-04-27 20:00:07',1),
	(18,2,'2013-04-27','2013-04-27 20:00:08',1),
	(19,11,'2013-04-27','2013-04-27 20:00:10',1),
	(20,2,'2013-04-27','2013-04-27 20:00:18',1),
	(21,4,'2013-04-27','2013-04-27 20:01:23',1),
	(22,4,'2013-04-27','2013-04-27 20:01:23',1),
	(23,4,'2013-04-27','2013-04-27 20:01:24',1),
	(24,4,'2013-04-27','2013-04-27 20:01:31',1),
	(25,2,'2013-04-27','2013-04-27 20:01:34',1),
	(26,9,'2013-04-27','2013-04-27 20:01:38',1),
	(27,2,'2013-04-27','2013-04-27 20:02:09',1),
	(28,34,'2013-04-27','2013-04-27 20:02:15',1),
	(29,2,'2013-04-27','2013-04-27 20:02:21',1),
	(30,37,'2013-04-27','2013-04-27 20:02:29',1),
	(31,2,'2013-04-27','2013-04-27 20:02:31',1),
	(32,40,'2013-04-27','2013-04-27 20:03:25',1),
	(33,40,'2013-04-27','2013-04-27 20:03:31',1),
	(34,1,'2013-04-27','2013-04-27 20:03:37',1),
	(35,128,'2013-04-27','2013-04-27 20:03:39',1),
	(36,1,'2013-04-27','2013-04-27 20:03:42',1),
	(37,2,'2013-04-27','2013-04-27 20:04:38',1),
	(38,9,'2013-04-27','2013-04-27 20:04:41',1),
	(39,130,'2013-04-27','2013-04-27 20:04:58',1),
	(40,2,'2013-04-27','2013-04-27 20:05:02',1),
	(41,8,'2013-04-27','2013-04-27 20:05:05',1),
	(42,2,'2013-04-27','2013-04-27 20:05:07',1),
	(43,9,'2013-04-27','2013-04-27 20:05:09',1),
	(44,1,'2013-04-27','2013-04-27 20:06:23',1),
	(45,1,'2013-04-27','2013-04-27 20:06:28',1),
	(46,1,'2013-04-27','2013-04-27 20:06:36',1),
	(47,1,'2013-04-27','2013-04-27 20:07:10',1),
	(48,1,'2013-04-27','2013-04-27 20:07:13',1),
	(49,1,'2013-04-27','2013-04-27 20:07:36',1),
	(50,1,'2013-04-27','2013-04-27 20:08:20',1),
	(51,1,'2013-04-27','2013-04-27 20:08:22',1),
	(52,1,'2013-04-27','2013-04-27 20:08:30',1),
	(53,2,'2013-04-27','2013-04-27 20:22:46',1),
	(54,43,'2013-04-27','2013-04-27 20:23:09',1),
	(55,43,'2013-04-27','2013-04-27 20:23:46',1),
	(56,2,'2013-04-27','2013-04-27 20:25:21',1),
	(57,50,'2013-04-27','2013-04-27 20:25:34',1),
	(58,48,'2013-04-27','2013-04-27 20:25:34',1),
	(59,48,'2013-04-27','2013-04-27 20:26:09',1),
	(60,48,'2013-04-27','2013-04-27 20:26:09',1),
	(61,50,'2013-04-27','2013-04-27 20:26:18',1),
	(62,50,'2013-04-27','2013-04-27 20:26:34',1),
	(63,50,'2013-04-27','2013-04-27 20:26:39',1),
	(64,50,'2013-04-27','2013-04-27 20:26:43',1),
	(65,50,'2013-04-27','2013-04-27 20:26:48',1),
	(66,50,'2013-04-27','2013-04-27 20:26:53',1),
	(67,50,'2013-04-27','2013-04-27 20:26:59',1),
	(68,50,'2013-04-27','2013-04-27 20:27:08',1),
	(69,50,'2013-04-27','2013-04-27 20:27:13',1),
	(70,50,'2013-04-27','2013-04-27 20:27:19',1),
	(71,50,'2013-04-27','2013-04-27 20:27:25',1),
	(72,46,'2013-04-27','2013-04-27 20:27:36',1),
	(73,46,'2013-04-27','2013-04-27 20:27:40',1),
	(74,46,'2013-04-27','2013-04-27 20:27:40',1),
	(75,46,'2013-04-27','2013-04-27 20:27:46',1),
	(76,43,'2013-04-27','2013-04-27 20:27:51',1),
	(77,43,'2013-04-27','2013-04-27 20:27:55',1),
	(78,1,'2013-04-27','2013-04-27 20:28:01',1),
	(79,1,'2013-04-27','2013-04-27 20:28:06',1),
	(80,1,'2013-04-27','2013-04-27 20:28:08',1),
	(81,1,'2013-04-27','2013-04-27 20:32:36',1),
	(82,1,'2013-04-27','2013-04-27 20:35:40',1),
	(83,1,'2013-04-27','2013-04-27 21:00:19',1),
	(84,1,'2013-04-27','2013-04-27 21:00:21',1),
	(85,1,'2013-04-27','2013-04-27 21:11:30',1),
	(86,1,'2013-04-27','2013-04-27 21:11:42',1),
	(87,1,'2013-04-27','2013-04-27 21:12:11',1),
	(88,1,'2013-04-27','2013-04-27 21:12:59',1),
	(89,1,'2013-04-27','2013-04-27 21:13:24',1),
	(90,1,'2013-04-27','2013-04-27 21:13:55',1),
	(91,1,'2013-04-27','2013-04-27 21:13:57',1),
	(92,1,'2013-04-27','2013-04-27 21:14:42',1),
	(93,1,'2013-04-27','2013-04-27 21:14:44',1),
	(94,1,'2013-04-27','2013-04-27 21:16:19',1),
	(95,1,'2013-04-27','2013-04-27 21:16:57',1),
	(96,1,'2013-04-27','2013-04-27 21:17:32',1),
	(97,1,'2013-04-27','2013-04-27 21:17:59',1),
	(98,1,'2013-04-27','2013-04-27 21:18:54',1),
	(99,1,'2013-04-27','2013-04-27 21:20:01',1),
	(100,1,'2013-04-27','2013-04-27 21:20:03',1),
	(101,1,'2013-04-27','2013-04-27 21:20:26',1),
	(102,1,'2013-04-27','2013-04-27 21:21:02',1),
	(103,1,'2013-04-27','2013-04-27 21:21:19',1),
	(104,1,'2013-04-27','2013-04-27 21:21:30',1),
	(105,1,'2013-04-27','2013-04-27 21:21:33',1),
	(106,1,'2013-04-27','2013-04-27 21:22:28',1),
	(107,1,'2013-04-27','2013-04-27 21:22:30',1),
	(108,1,'2013-04-27','2013-04-27 21:25:01',1),
	(109,1,'2013-04-27','2013-04-27 21:25:03',1),
	(110,1,'2013-04-27','2013-04-27 21:26:48',1),
	(111,1,'2013-04-27','2013-04-27 21:26:50',1),
	(112,1,'2013-04-27','2013-04-27 21:27:05',1),
	(113,1,'2013-04-27','2013-04-27 21:27:07',1),
	(114,1,'2013-04-27','2013-04-27 21:27:30',1),
	(115,1,'2013-04-27','2013-04-27 21:27:32',1),
	(116,1,'2013-04-27','2013-04-27 21:28:36',1),
	(117,1,'2013-04-27','2013-04-27 21:28:52',1),
	(118,1,'2013-04-27','2013-04-27 21:29:00',1),
	(119,1,'2013-04-27','2013-04-27 21:29:15',1),
	(120,1,'2013-04-27','2013-04-27 21:29:17',1),
	(121,1,'2013-04-27','2013-04-27 21:29:40',1),
	(122,1,'2013-04-27','2013-04-27 21:29:42',1),
	(123,1,'2013-04-27','2013-04-27 21:30:04',1),
	(124,1,'2013-04-27','2013-04-27 21:30:06',1),
	(125,1,'2013-04-27','2013-04-27 21:30:55',1),
	(126,1,'2013-04-27','2013-04-27 21:30:57',1),
	(127,1,'2013-04-27','2013-04-27 21:32:42',1),
	(128,1,'2013-04-27','2013-04-27 21:32:45',1),
	(129,1,'2013-04-27','2013-04-27 21:35:19',1),
	(130,1,'2013-04-27','2013-04-27 21:35:21',1),
	(131,1,'2013-04-27','2013-04-27 21:35:51',1),
	(132,1,'2013-04-27','2013-04-27 21:37:43',1),
	(133,1,'2013-04-27','2013-04-27 21:38:47',1),
	(134,1,'2013-04-27','2013-04-27 21:38:48',1),
	(135,1,'2013-04-27','2013-04-27 21:40:18',1),
	(136,1,'2013-04-27','2013-04-27 21:40:20',1),
	(137,1,'2013-04-27','2013-04-27 21:40:57',1),
	(138,1,'2013-04-27','2013-04-27 21:40:58',1),
	(139,1,'2013-04-27','2013-04-27 21:41:00',1),
	(140,1,'2013-04-27','2013-04-27 21:41:13',1),
	(141,1,'2013-04-27','2013-04-27 21:41:14',1),
	(142,1,'2013-04-27','2013-04-27 21:41:19',1),
	(143,1,'2013-04-27','2013-04-27 21:42:01',1),
	(144,1,'2013-04-27','2013-04-27 21:42:03',1),
	(145,1,'2013-04-27','2013-04-27 21:42:49',1),
	(146,1,'2013-04-27','2013-04-27 21:42:51',1),
	(147,1,'2013-04-27','2013-04-27 21:43:24',1),
	(148,1,'2013-04-27','2013-04-27 21:43:25',1),
	(149,1,'2013-04-27','2013-04-27 21:43:45',1),
	(150,1,'2013-04-27','2013-04-27 21:43:45',1),
	(151,1,'2013-04-27','2013-04-27 21:43:57',1),
	(152,1,'2013-04-27','2013-04-27 21:43:57',1),
	(153,1,'2013-04-27','2013-04-27 21:44:02',1),
	(154,1,'2013-04-27','2013-04-27 21:44:33',1),
	(155,1,'2013-04-27','2013-04-27 21:45:09',1),
	(156,1,'2013-04-27','2013-04-27 21:45:30',1),
	(157,1,'2013-04-27','2013-04-27 21:45:45',1),
	(158,1,'2013-04-27','2013-04-27 21:45:46',1),
	(159,1,'2013-04-27','2013-04-27 21:46:03',1),
	(160,1,'2013-04-27','2013-04-27 21:46:03',1),
	(161,1,'2013-04-27','2013-04-27 21:46:15',1),
	(162,1,'2013-04-27','2013-04-27 21:46:16',1),
	(163,1,'2013-04-27','2013-04-27 21:46:22',1),
	(164,1,'2013-04-27','2013-04-27 21:46:30',1),
	(165,1,'2013-04-27','2013-04-27 21:46:49',1),
	(166,1,'2013-04-27','2013-04-27 21:46:51',1),
	(167,1,'2013-04-27','2013-04-27 21:47:14',1),
	(168,1,'2013-04-27','2013-04-27 21:49:00',1),
	(169,1,'2013-04-27','2013-04-27 21:49:21',1),
	(170,1,'2013-04-27','2013-04-27 21:54:42',1),
	(171,1,'2013-04-27','2013-04-27 22:04:35',1),
	(172,1,'2013-04-27','2013-04-27 22:05:56',1),
	(173,1,'2013-04-27','2013-04-27 22:06:54',1),
	(174,1,'2013-04-27','2013-04-27 22:06:56',1),
	(175,1,'2013-04-27','2013-04-27 22:08:39',1),
	(176,1,'2013-04-27','2013-04-27 22:08:41',1),
	(177,1,'2013-04-27','2013-04-27 22:09:16',1),
	(178,1,'2013-04-27','2013-04-27 22:09:19',1),
	(179,1,'2013-04-27','2013-04-27 22:09:24',1),
	(180,1,'2013-04-27','2013-04-27 22:09:26',1),
	(181,1,'2013-04-27','2013-04-27 22:09:34',1),
	(182,1,'2013-04-27','2013-04-27 22:09:36',1),
	(183,1,'2013-04-27','2013-04-27 22:10:29',1),
	(184,1,'2013-04-27','2013-04-27 22:10:31',1);

/*!40000 ALTER TABLE `PageStatistics` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PageThemes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PageThemes`;

CREATE TABLE `PageThemes` (
  `ptID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ptHandle` varchar(64) NOT NULL,
  `ptName` varchar(255) DEFAULT NULL,
  `ptDescription` text,
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ptID`),
  UNIQUE KEY `ptHandle` (`ptHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PageThemes` WRITE;
/*!40000 ALTER TABLE `PageThemes` DISABLE KEYS */;

INSERT INTO `PageThemes` (`ptID`, `ptHandle`, `ptName`, `ptDescription`, `pkgID`)
VALUES
	(1,'default','Plain Yogurt','Plain Yogurt is concrete5\'s default theme.',0),
	(2,'greensalad','Green Salad Theme','This is concrete5\'s Green Salad site theme.',0),
	(3,'dark_chocolate','Dark Chocolate','Dark Chocolate is concrete5\'s default theme in black.',0),
	(4,'greek_yogurt','Greek Yogurt','An elegant theme for concrete5.',0),
	(5,'fls','Fanning Landscapes','Custom theme for fanninglandscapes.com.',0);

/*!40000 ALTER TABLE `PageThemes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PageThemeStyles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PageThemeStyles`;

CREATE TABLE `PageThemeStyles` (
  `ptID` int(10) unsigned NOT NULL DEFAULT '0',
  `ptsHandle` varchar(128) NOT NULL,
  `ptsValue` longtext,
  `ptsType` varchar(32) NOT NULL,
  PRIMARY KEY (`ptID`,`ptsHandle`,`ptsType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PageTypeAttributes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PageTypeAttributes`;

CREATE TABLE `PageTypeAttributes` (
  `ctID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ctID`,`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PageTypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PageTypes`;

CREATE TABLE `PageTypes` (
  `ctID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctHandle` varchar(32) NOT NULL,
  `ctIcon` varchar(128) DEFAULT NULL,
  `ctName` varchar(90) NOT NULL,
  `ctIsInternal` tinyint(1) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ctID`),
  UNIQUE KEY `ctHandle` (`ctHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PageTypes` WRITE;
/*!40000 ALTER TABLE `PageTypes` DISABLE KEYS */;

INSERT INTO `PageTypes` (`ctID`, `ctHandle`, `ctIcon`, `ctName`, `ctIsInternal`, `pkgID`)
VALUES
	(1,'core_stack','main.png','Stack',1,0),
	(2,'dashboard_primary_five','main.png','Dashboard Primary + Five',1,0),
	(3,'dashboard_header_four_col','main.png','Dashboard Header + Four Column',1,0),
	(4,'blog_entry','template1.png','Blog Entry',0,0),
	(5,'full','main.png','Full',0,0),
	(6,'left_sidebar','template1.png','Left Sidebar',0,0),
	(7,'right_sidebar','right_sidebar.png','Right Sidebar',0,0);

/*!40000 ALTER TABLE `PageTypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PageWorkflowProgress
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PageWorkflowProgress`;

CREATE TABLE `PageWorkflowProgress` (
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  `wpID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cID`,`wpID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PermissionAccess
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccess`;

CREATE TABLE `PermissionAccess` (
  `paID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paIsInUse` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionAccess` WRITE;
/*!40000 ALTER TABLE `PermissionAccess` DISABLE KEYS */;

INSERT INTO `PermissionAccess` (`paID`, `paIsInUse`)
VALUES
	(1,1),
	(2,1),
	(3,1),
	(4,1),
	(5,1),
	(6,1),
	(7,1),
	(8,1),
	(9,1),
	(10,1),
	(11,1),
	(12,1),
	(13,1),
	(14,1),
	(15,1),
	(16,1),
	(17,1),
	(18,1),
	(19,1),
	(20,1),
	(21,1),
	(22,1),
	(23,1),
	(24,1),
	(25,1),
	(26,1),
	(27,1),
	(28,1),
	(29,1),
	(30,1),
	(31,1),
	(32,1),
	(33,1),
	(34,1),
	(35,1),
	(36,1),
	(37,1),
	(38,1),
	(39,1),
	(40,1),
	(41,1),
	(42,1),
	(43,1),
	(44,1),
	(45,1),
	(46,1),
	(47,1),
	(48,1),
	(49,1),
	(50,1),
	(51,1),
	(52,1),
	(53,1),
	(54,1),
	(55,1),
	(56,1),
	(57,1),
	(58,1),
	(59,1);

/*!40000 ALTER TABLE `PermissionAccess` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionAccessEntities
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessEntities`;

CREATE TABLE `PermissionAccessEntities` (
  `peID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `petID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`peID`),
  KEY `petID` (`petID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionAccessEntities` WRITE;
/*!40000 ALTER TABLE `PermissionAccessEntities` DISABLE KEYS */;

INSERT INTO `PermissionAccessEntities` (`peID`, `petID`)
VALUES
	(1,1),
	(2,1),
	(3,1),
	(4,5),
	(5,6);

/*!40000 ALTER TABLE `PermissionAccessEntities` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionAccessEntityGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessEntityGroups`;

CREATE TABLE `PermissionAccessEntityGroups` (
  `pegID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pegID`),
  KEY `gID` (`gID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionAccessEntityGroups` WRITE;
/*!40000 ALTER TABLE `PermissionAccessEntityGroups` DISABLE KEYS */;

INSERT INTO `PermissionAccessEntityGroups` (`pegID`, `peID`, `gID`)
VALUES
	(1,1,3),
	(2,2,1),
	(3,3,2);

/*!40000 ALTER TABLE `PermissionAccessEntityGroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionAccessEntityGroupSets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessEntityGroupSets`;

CREATE TABLE `PermissionAccessEntityGroupSets` (
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `gsID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`peID`,`gsID`),
  KEY `gsID` (`gsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PermissionAccessEntityTypeCategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessEntityTypeCategories`;

CREATE TABLE `PermissionAccessEntityTypeCategories` (
  `petID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkCategoryID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`petID`,`pkCategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionAccessEntityTypeCategories` WRITE;
/*!40000 ALTER TABLE `PermissionAccessEntityTypeCategories` DISABLE KEYS */;

INSERT INTO `PermissionAccessEntityTypeCategories` (`petID`, `pkCategoryID`)
VALUES
	(1,1),
	(1,5),
	(1,6),
	(1,7),
	(1,8),
	(1,9),
	(1,10),
	(1,11),
	(1,12),
	(1,13),
	(1,14),
	(2,1),
	(2,5),
	(2,6),
	(2,7),
	(2,8),
	(2,9),
	(2,10),
	(2,11),
	(2,12),
	(2,13),
	(2,14),
	(3,1),
	(3,5),
	(3,6),
	(3,7),
	(3,8),
	(3,9),
	(3,10),
	(3,11),
	(3,12),
	(3,13),
	(3,14),
	(4,1),
	(4,5),
	(4,6),
	(4,7),
	(4,8),
	(4,9),
	(4,10),
	(4,11),
	(4,12),
	(4,13),
	(4,14),
	(5,1),
	(6,6),
	(6,7);

/*!40000 ALTER TABLE `PermissionAccessEntityTypeCategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionAccessEntityTypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessEntityTypes`;

CREATE TABLE `PermissionAccessEntityTypes` (
  `petID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `petHandle` varchar(255) NOT NULL,
  `petName` varchar(255) NOT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`petID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionAccessEntityTypes` WRITE;
/*!40000 ALTER TABLE `PermissionAccessEntityTypes` DISABLE KEYS */;

INSERT INTO `PermissionAccessEntityTypes` (`petID`, `petHandle`, `petName`, `pkgID`)
VALUES
	(1,'group','Group',0),
	(2,'user','User',0),
	(3,'group_set','Group Set',0),
	(4,'group_combination','Group Combination',0),
	(5,'page_owner','Page Owner',0),
	(6,'file_uploader','File Uploader',0);

/*!40000 ALTER TABLE `PermissionAccessEntityTypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionAccessEntityUsers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessEntityUsers`;

CREATE TABLE `PermissionAccessEntityUsers` (
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`peID`,`uID`),
  KEY `uID` (`uID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PermissionAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessList`;

CREATE TABLE `PermissionAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `pdID` int(10) unsigned NOT NULL DEFAULT '0',
  `accessType` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`),
  KEY `accessType` (`accessType`),
  KEY `peID` (`peID`),
  KEY `peID_accessType` (`peID`,`accessType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionAccessList` WRITE;
/*!40000 ALTER TABLE `PermissionAccessList` DISABLE KEYS */;

INSERT INTO `PermissionAccessList` (`paID`, `peID`, `pdID`, `accessType`)
VALUES
	(1,1,0,10),
	(2,1,0,10),
	(3,1,0,10),
	(4,1,0,10),
	(5,1,0,10),
	(6,1,0,10),
	(7,1,0,10),
	(8,1,0,10),
	(9,1,0,10),
	(10,1,0,10),
	(11,1,0,10),
	(12,1,0,10),
	(13,1,0,10),
	(14,1,0,10),
	(15,1,0,10),
	(16,1,0,10),
	(17,1,0,10),
	(18,1,0,10),
	(19,1,0,10),
	(20,1,0,10),
	(21,1,0,10),
	(22,1,0,10),
	(23,1,0,10),
	(24,1,0,10),
	(25,1,0,10),
	(26,1,0,10),
	(27,1,0,10),
	(28,1,0,10),
	(29,1,0,10),
	(30,1,0,10),
	(31,1,0,10),
	(32,1,0,10),
	(33,2,0,10),
	(34,2,0,10),
	(34,3,0,10),
	(35,2,0,10),
	(36,1,0,10),
	(36,2,0,10),
	(37,1,0,10),
	(38,1,0,10),
	(39,1,0,10),
	(40,1,0,10),
	(41,1,0,10),
	(42,1,0,10),
	(43,1,0,10),
	(44,1,0,10),
	(45,2,0,10),
	(46,1,0,10),
	(47,1,0,10),
	(48,1,0,10),
	(49,1,0,10),
	(50,1,0,10),
	(51,1,0,10),
	(52,1,0,10),
	(53,1,0,10),
	(54,1,0,10),
	(55,1,0,10),
	(56,1,0,10),
	(57,1,0,10),
	(58,1,0,10),
	(59,1,0,10);

/*!40000 ALTER TABLE `PermissionAccessList` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionAccessWorkflows
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAccessWorkflows`;

CREATE TABLE `PermissionAccessWorkflows` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `wfID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`wfID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PermissionAssignments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionAssignments`;

CREATE TABLE `PermissionAssignments` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `pkID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`pkID`),
  KEY `pkID` (`pkID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionAssignments` WRITE;
/*!40000 ALTER TABLE `PermissionAssignments` DISABLE KEYS */;

INSERT INTO `PermissionAssignments` (`paID`, `pkID`)
VALUES
	(1,16),
	(2,17),
	(3,54),
	(4,55),
	(5,56),
	(6,57),
	(7,59),
	(8,60),
	(9,61),
	(10,62),
	(11,63),
	(12,65),
	(13,66),
	(14,67),
	(15,68),
	(16,69),
	(17,70);

/*!40000 ALTER TABLE `PermissionAssignments` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionDurationObjects
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionDurationObjects`;

CREATE TABLE `PermissionDurationObjects` (
  `pdID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pdObject` text,
  PRIMARY KEY (`pdID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table PermissionKeyCategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionKeyCategories`;

CREATE TABLE `PermissionKeyCategories` (
  `pkCategoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pkCategoryHandle` varchar(255) NOT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pkCategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionKeyCategories` WRITE;
/*!40000 ALTER TABLE `PermissionKeyCategories` DISABLE KEYS */;

INSERT INTO `PermissionKeyCategories` (`pkCategoryID`, `pkCategoryHandle`, `pkgID`)
VALUES
	(1,'page',NULL),
	(2,'single_page',NULL),
	(3,'stack',NULL),
	(4,'composer_page',NULL),
	(5,'user',NULL),
	(6,'file_set',NULL),
	(7,'file',NULL),
	(8,'area',NULL),
	(9,'block_type',NULL),
	(10,'block',NULL),
	(11,'admin',NULL),
	(12,'sitemap',NULL),
	(13,'marketplace_newsflow',NULL),
	(14,'basic_workflow',NULL);

/*!40000 ALTER TABLE `PermissionKeyCategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionKeys
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionKeys`;

CREATE TABLE `PermissionKeys` (
  `pkID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pkHandle` varchar(255) NOT NULL,
  `pkName` varchar(255) NOT NULL,
  `pkCanTriggerWorkflow` int(1) NOT NULL DEFAULT '0',
  `pkHasCustomClass` int(1) NOT NULL DEFAULT '0',
  `pkDescription` varchar(255) DEFAULT NULL,
  `pkCategoryID` int(10) unsigned DEFAULT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pkID`),
  UNIQUE KEY `akHandle` (`pkHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `PermissionKeys` WRITE;
/*!40000 ALTER TABLE `PermissionKeys` DISABLE KEYS */;

INSERT INTO `PermissionKeys` (`pkID`, `pkHandle`, `pkName`, `pkCanTriggerWorkflow`, `pkHasCustomClass`, `pkDescription`, `pkCategoryID`, `pkgID`)
VALUES
	(1,'view_page','View',0,0,'Can see a page exists and read its content.',1,0),
	(2,'view_page_versions','View Versions',0,0,'Can view the page versions dialog and read past versions of a page.',1,0),
	(3,'preview_page_as_user','Preview Page As User',0,0,'Ability to see what this page will look like at a specific time in the future as a specific user.',1,0),
	(4,'edit_page_properties','Edit Properties',0,1,'Ability to change anything in the Page Properties menu.',1,0),
	(5,'edit_page_contents','Edit Contents',0,0,'Ability to make edits to at least some of the content in the page. You can lock down different block areas and specific blocks by clicking Permissions on them as well. ',1,0),
	(6,'edit_page_speed_settings','Edit Speed Settings',0,0,'Ability to change caching settings.',1,0),
	(7,'edit_page_theme','Change Theme',0,1,'Ability to change just the theme for this page.',1,0),
	(8,'edit_page_type','Change Page Type',0,0,'Ability to change just the page type for this page, also check out Theme permissions.',1,0),
	(9,'edit_page_permissions','Edit Permissions',1,0,'Ability to change permissions for this page. Warning: by granting this a user could give themselves more access.',1,0),
	(10,'delete_page','Delete',1,0,'Ability to move this page to the site\'s Trash.',1,0),
	(11,'delete_page_versions','Delete Versions',1,0,'Ability to remove old versions of this page.',1,0),
	(12,'approve_page_versions','Approve Changes',1,0,'Can publish an unapproved version of the page.',1,0),
	(13,'add_subpage','Add Sub-Page',0,1,'Can add a page beneath the current page.',1,0),
	(14,'move_or_copy_page','Move or Copy Page',1,0,'Can move or copy this page to another location.',1,0),
	(15,'schedule_page_contents_guest_access','Schedule Guest Access',0,0,'Can control scheduled guest access to this page.',1,0),
	(16,'add_block','Add Block',0,1,'Can add a block to any area on the site. If someone is added here they can add blocks to any area (unless that area has permissions that override these global permissions.)',9,0),
	(17,'add_stack','Add Stack',0,0,'Can add a stack or block from a stack to any area on the site. If someone is added here they can add stacks to any area (unless that area has permissions that override these global permissions.)',9,0),
	(18,'view_area','View Area',0,0,'Can view the area and its contents.',8,0),
	(19,'edit_area_contents','Edit Area Contents',0,0,'Can edit blocks within this area.',8,0),
	(20,'add_block_to_area','Add Block to Area',0,1,'Can add blocks to this area. This setting overrides the global Add Block permission for this area.',8,0),
	(21,'add_stack_to_area','Add Stack to Area',0,0,'Can add stacks to this area. This setting overrides the global Add Stack permission for this area.',8,0),
	(22,'add_layout_to_area','Add Layouts to Area',0,0,'Controls whether users get the ability to add layouts to a particular area.',8,0),
	(23,'edit_area_design','Edit Area Design',0,0,'Controls whether users see design controls and can modify an area\'s custom CSS.',8,0),
	(24,'edit_area_permissions','Edit Area Permissions',0,0,'Controls whether users can access the permissions on an area. Custom area permissions could override those of the page.',8,0),
	(25,'delete_area_contents','Delete Area Contents',0,0,'Controls whether users can delete blocks from this area.',8,0),
	(26,'schedule_area_contents_guest_access','Schedule Guest Access',0,0,'Controls whether users can schedule guest access permissions on blocks in this area. Guest Access is a shortcut for granting permissions just to the Guest Group.',8,0),
	(27,'view_block','View Block',0,0,'Controls whether users can view this block in the page.',10,0),
	(28,'edit_block','Edit Block',0,0,'Controls whether users can edit this block. This overrides any area or page permissions.',10,0),
	(29,'edit_block_custom_template','Change Custom Template',0,0,'Controls whether users can change the custom template on this block. This overrides any area or page permissions.',10,0),
	(30,'delete_block','Delete Block',0,0,'Controls whether users can delete this block. This overrides any area or page permissions.',10,0),
	(31,'edit_block_design','Edit Design',0,0,'Controls whether users can set custom design properties or CSS on this block.',10,0),
	(32,'edit_block_permissions','Edit Permissions',0,0,'Controls whether users can change permissions on this block, potentially granting themselves or others greater access.',10,0),
	(33,'schedule_guest_access','Schedule Guest Access',0,0,'Controls whether users can schedule guest access permissions on this block. Guest Access is a shortcut for granting permissions just to the Guest Group.',10,0),
	(34,'view_file_set_file','View Files',0,0,'Can view and download files in the site.',6,0),
	(35,'search_file_set','Search Files in File Manager',0,0,'Can access the file manager',6,0),
	(36,'edit_file_set_file_properties','Edit File Properties',0,0,'Can edit a file\'s properties.',6,0),
	(37,'edit_file_set_file_contents','Edit File Contents',0,0,'Can edit or replace files in set.',6,0),
	(38,'copy_file_set_files','Copy File',0,0,'Can copy files in file set.',6,0),
	(39,'edit_file_set_permissions','Edit File Access',0,0,'Can edit access to file sets.',6,0),
	(40,'delete_file_set','Delete File Set',0,0,'',6,0),
	(41,'delete_file_set_files','Delete File',0,0,'Can delete files in set.',6,0),
	(42,'add_file','Add File',0,1,'Can add files to set.',6,0),
	(43,'view_file','View Files',0,0,'Can view and download files.',7,0),
	(44,'view_file_in_file_manager','View File in File Manager',0,0,'Can access the File Manager.',7,0),
	(45,'edit_file_properties','Edit File Properties',0,0,'Can edit a file\'s properties.',7,0),
	(46,'edit_file_contents','Edit File Contents',0,0,'Can edit or replace files.',7,0),
	(47,'copy_file','Copy File',0,0,'Can copy file.',7,0),
	(48,'edit_file_permissions','Edit File Access',0,0,'Can edit access to file.',7,0),
	(49,'delete_file','Delete File',0,0,'Can delete file.',7,0),
	(50,'approve_basic_workflow_action','Approve or Deny',0,0,'Grant ability to approve workflow.',14,0),
	(51,'notify_on_basic_workflow_entry','Notify on Entry',0,0,'Notify approvers that a change has entered the workflow.',14,0),
	(52,'notify_on_basic_workflow_approve','Notify on Approve',0,0,'Notify approvers that a change has been approved.',14,0),
	(53,'notify_on_basic_workflow_deny','Notify on Deny',0,0,'Notify approvers that a change has been denied.',14,0),
	(54,'access_user_search','Access User Search',0,1,'',5,0),
	(55,'edit_user_properties','Edit User Details',0,1,NULL,5,0),
	(56,'view_user_attributes','View User Attributes',0,1,NULL,5,0),
	(57,'activate_user','Activate/Deactivate User',0,0,NULL,5,0),
	(58,'sudo','Sign in as User',0,0,NULL,5,0),
	(59,'delete_user','Delete User',0,0,NULL,5,0),
	(60,'access_group_search','Access Group Search',0,0,'',5,0),
	(61,'edit_groups','Edit Groups',0,0,'',5,0),
	(62,'assign_user_groups','Assign Groups to User',0,1,'',5,0),
	(63,'backup','Perform Backups',0,0,NULL,11,0),
	(64,'access_task_permissions','Access Task Permissions',0,0,NULL,11,0),
	(65,'access_sitemap','Access Sitemap',0,0,NULL,12,0),
	(66,'access_page_defaults','Access Page Type Defaults',0,0,NULL,11,0),
	(67,'empty_trash','Empty Trash',0,0,NULL,11,0),
	(68,'uninstall_packages','Uninstall Packages',0,0,NULL,13,0),
	(69,'install_packages','Install Packages',0,0,NULL,13,0),
	(70,'view_newsflow','View Newsflow',0,0,NULL,13,0);

/*!40000 ALTER TABLE `PermissionKeys` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PileContents
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PileContents`;

CREATE TABLE `PileContents` (
  `pcID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pID` int(10) unsigned NOT NULL DEFAULT '0',
  `itemID` int(10) unsigned NOT NULL DEFAULT '0',
  `itemType` varchar(64) NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `displayOrder` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pcID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Piles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Piles`;

CREATE TABLE `Piles` (
  `pID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uID` int(10) unsigned DEFAULT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(255) DEFAULT NULL,
  `state` varchar(64) NOT NULL,
  PRIMARY KEY (`pID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table SignupRequests
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SignupRequests`;

CREATE TABLE `SignupRequests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipFrom` int(10) unsigned NOT NULL DEFAULT '0',
  `date_access` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `index_ipFrom` (`ipFrom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Stacks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Stacks`;

CREATE TABLE `Stacks` (
  `stID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stName` varchar(255) NOT NULL,
  `stType` int(1) unsigned NOT NULL DEFAULT '0',
  `cID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`stID`),
  KEY `stType` (`stType`),
  KEY `stName` (`stName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Stacks` WRITE;
/*!40000 ALTER TABLE `Stacks` DISABLE KEYS */;

INSERT INTO `Stacks` (`stID`, `stName`, `stType`, `cID`)
VALUES
	(1,'Header Nav',20,121),
	(2,'Side Nav',0,122),
	(3,'Site Name',20,123);

/*!40000 ALTER TABLE `Stacks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SystemAntispamLibraries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SystemAntispamLibraries`;

CREATE TABLE `SystemAntispamLibraries` (
  `saslHandle` varchar(64) NOT NULL,
  `saslName` varchar(255) DEFAULT NULL,
  `saslIsActive` int(1) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`saslHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table SystemCaptchaLibraries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SystemCaptchaLibraries`;

CREATE TABLE `SystemCaptchaLibraries` (
  `sclHandle` varchar(64) NOT NULL,
  `sclName` varchar(255) DEFAULT NULL,
  `sclIsActive` int(1) NOT NULL DEFAULT '0',
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sclHandle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `SystemCaptchaLibraries` WRITE;
/*!40000 ALTER TABLE `SystemCaptchaLibraries` DISABLE KEYS */;

INSERT INTO `SystemCaptchaLibraries` (`sclHandle`, `sclName`, `sclIsActive`, `pkgID`)
VALUES
	('securimage','SecurImage (Default)',1,0);

/*!40000 ALTER TABLE `SystemCaptchaLibraries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SystemNotifications
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SystemNotifications`;

CREATE TABLE `SystemNotifications` (
  `snID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `snTypeID` int(3) unsigned NOT NULL DEFAULT '0',
  `snURL` text,
  `snURL2` text,
  `snDateTime` datetime NOT NULL,
  `snIsArchived` int(1) NOT NULL DEFAULT '0',
  `snIsNew` int(1) NOT NULL DEFAULT '0',
  `snTitle` varchar(255) DEFAULT NULL,
  `snDescription` text,
  `snBody` text,
  PRIMARY KEY (`snID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserAttributeKeys
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserAttributeKeys`;

CREATE TABLE `UserAttributeKeys` (
  `akID` int(10) unsigned NOT NULL,
  `uakProfileDisplay` tinyint(1) NOT NULL DEFAULT '0',
  `uakMemberListDisplay` tinyint(1) NOT NULL DEFAULT '0',
  `uakProfileEdit` tinyint(1) NOT NULL DEFAULT '1',
  `uakProfileEditRequired` tinyint(1) NOT NULL DEFAULT '0',
  `uakRegisterEdit` tinyint(1) NOT NULL DEFAULT '0',
  `uakRegisterEditRequired` tinyint(1) NOT NULL DEFAULT '0',
  `displayOrder` int(10) unsigned DEFAULT '0',
  `uakIsActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `UserAttributeKeys` WRITE;
/*!40000 ALTER TABLE `UserAttributeKeys` DISABLE KEYS */;

INSERT INTO `UserAttributeKeys` (`akID`, `uakProfileDisplay`, `uakMemberListDisplay`, `uakProfileEdit`, `uakProfileEditRequired`, `uakRegisterEdit`, `uakRegisterEditRequired`, `displayOrder`, `uakIsActive`)
VALUES
	(10,0,0,1,0,1,0,1,1),
	(11,0,0,1,0,1,0,2,1);

/*!40000 ALTER TABLE `UserAttributeKeys` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table UserAttributeValues
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserAttributeValues`;

CREATE TABLE `UserAttributeValues` (
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  `avID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uID`,`akID`,`avID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserBannedIPs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserBannedIPs`;

CREATE TABLE `UserBannedIPs` (
  `ipFrom` int(10) unsigned NOT NULL DEFAULT '0',
  `ipTo` int(10) unsigned NOT NULL DEFAULT '0',
  `banCode` int(1) unsigned NOT NULL DEFAULT '1',
  `expires` int(10) unsigned NOT NULL DEFAULT '0',
  `isManual` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ipFrom`,`ipTo`),
  KEY `ipFrom` (`ipFrom`),
  KEY `ipTo` (`ipTo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserGroups`;

CREATE TABLE `UserGroups` (
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  `ugEntered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`uID`,`gID`),
  KEY `uID` (`uID`),
  KEY `gID` (`gID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserOpenIDs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserOpenIDs`;

CREATE TABLE `UserOpenIDs` (
  `uID` int(10) unsigned NOT NULL,
  `uOpenID` varchar(255) NOT NULL,
  PRIMARY KEY (`uOpenID`),
  KEY `uID` (`uID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionAssignGroupAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionAssignGroupAccessList`;

CREATE TABLE `UserPermissionAssignGroupAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionAssignGroupAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionAssignGroupAccessListCustom`;

CREATE TABLE `UserPermissionAssignGroupAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`gID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionEditPropertyAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionEditPropertyAccessList`;

CREATE TABLE `UserPermissionEditPropertyAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `uName` int(1) unsigned DEFAULT '0',
  `uEmail` int(1) unsigned DEFAULT '0',
  `uPassword` int(1) unsigned DEFAULT '0',
  `uAvatar` int(1) unsigned DEFAULT '0',
  `uTimezone` int(1) unsigned DEFAULT '0',
  `uDefaultLanguage` int(1) unsigned DEFAULT '0',
  `attributePermission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionEditPropertyAttributeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionEditPropertyAttributeAccessListCustom`;

CREATE TABLE `UserPermissionEditPropertyAttributeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionUserSearchAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionUserSearchAccessList`;

CREATE TABLE `UserPermissionUserSearchAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionUserSearchAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionUserSearchAccessListCustom`;

CREATE TABLE `UserPermissionUserSearchAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `gID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`gID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionViewAttributeAccessList
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionViewAttributeAccessList`;

CREATE TABLE `UserPermissionViewAttributeAccessList` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paID`,`peID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPermissionViewAttributeAccessListCustom
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPermissionViewAttributeAccessListCustom`;

CREATE TABLE `UserPermissionViewAttributeAccessListCustom` (
  `paID` int(10) unsigned NOT NULL DEFAULT '0',
  `peID` int(10) unsigned NOT NULL DEFAULT '0',
  `akID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`paID`,`peID`,`akID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPrivateMessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPrivateMessages`;

CREATE TABLE `UserPrivateMessages` (
  `msgID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uAuthorID` int(10) unsigned NOT NULL DEFAULT '0',
  `msgDateCreated` datetime NOT NULL,
  `msgSubject` varchar(255) NOT NULL,
  `msgBody` text,
  `uToID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserPrivateMessagesTo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserPrivateMessagesTo`;

CREATE TABLE `UserPrivateMessagesTo` (
  `msgID` int(10) unsigned NOT NULL DEFAULT '0',
  `uID` int(10) unsigned NOT NULL DEFAULT '0',
  `uAuthorID` int(10) unsigned NOT NULL DEFAULT '0',
  `msgMailboxID` int(11) NOT NULL,
  `msgIsNew` int(1) NOT NULL DEFAULT '0',
  `msgIsUnread` int(1) NOT NULL DEFAULT '0',
  `msgIsReplied` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgID`,`uID`,`uAuthorID`),
  KEY `uID` (`uID`),
  KEY `uAuthorID` (`uAuthorID`),
  KEY `msgFolderID` (`msgMailboxID`),
  KEY `msgIsNew` (`msgIsNew`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Users`;

CREATE TABLE `Users` (
  `uID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uName` varchar(64) NOT NULL,
  `uEmail` varchar(64) NOT NULL,
  `uPassword` varchar(255) NOT NULL,
  `uIsActive` varchar(1) NOT NULL DEFAULT '0',
  `uIsValidated` tinyint(4) NOT NULL DEFAULT '-1',
  `uIsFullRecord` tinyint(1) NOT NULL DEFAULT '1',
  `uDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uHasAvatar` tinyint(1) NOT NULL DEFAULT '0',
  `uLastOnline` int(10) unsigned NOT NULL DEFAULT '0',
  `uLastLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `uLastIP` bigint(10) NOT NULL DEFAULT '0',
  `uPreviousLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `uNumLogins` int(10) unsigned NOT NULL DEFAULT '0',
  `uTimezone` varchar(255) DEFAULT NULL,
  `uDefaultLanguage` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`uID`),
  UNIQUE KEY `uName` (`uName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;

INSERT INTO `Users` (`uID`, `uName`, `uEmail`, `uPassword`, `uIsActive`, `uIsValidated`, `uIsFullRecord`, `uDateAdded`, `uHasAvatar`, `uLastOnline`, `uLastLogin`, `uLastIP`, `uPreviousLogin`, `uNumLogins`, `uTimezone`, `uDefaultLanguage`)
VALUES
	(1,'admin','me@brianfanning.com','7ffcb6b78f6f8b4bf2198ce4c02e9571','1',-1,1,'2013-04-27 15:01:26',0,1367111319,1367085686,2130706433,0,1,NULL,NULL);

/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table UserSearchIndexAttributes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserSearchIndexAttributes`;

CREATE TABLE `UserSearchIndexAttributes` (
  `uID` int(11) unsigned NOT NULL DEFAULT '0',
  `ak_profile_private_messages_enabled` tinyint(4) DEFAULT '0',
  `ak_profile_private_messages_notification_enabled` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`uID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UsersFriends
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UsersFriends`;

CREATE TABLE `UsersFriends` (
  `ufID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uID` int(10) unsigned DEFAULT NULL,
  `status` varchar(64) NOT NULL,
  `friendUID` int(10) unsigned DEFAULT NULL,
  `uDateAdded` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ufID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table UserValidationHashes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserValidationHashes`;

CREATE TABLE `UserValidationHashes` (
  `uvhID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uID` int(10) unsigned DEFAULT NULL,
  `uHash` varchar(64) NOT NULL,
  `type` int(4) unsigned NOT NULL DEFAULT '0',
  `uDateGenerated` int(10) unsigned NOT NULL DEFAULT '0',
  `uDateRedeemed` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uvhID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table WorkflowProgress
# ------------------------------------------------------------

DROP TABLE IF EXISTS `WorkflowProgress`;

CREATE TABLE `WorkflowProgress` (
  `wpID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wpCategoryID` int(10) unsigned DEFAULT NULL,
  `wfID` int(10) unsigned NOT NULL DEFAULT '0',
  `wpApproved` tinyint(1) NOT NULL DEFAULT '0',
  `wpDateAdded` datetime DEFAULT NULL,
  `wpDateLastAction` datetime DEFAULT NULL,
  `wpCurrentStatus` int(10) NOT NULL DEFAULT '0',
  `wrID` int(1) NOT NULL DEFAULT '0',
  `wpIsCompleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wpID`),
  KEY `wrID` (`wrID`),
  KEY `wpIsCompleted` (`wpIsCompleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table WorkflowProgressCategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `WorkflowProgressCategories`;

CREATE TABLE `WorkflowProgressCategories` (
  `wpCategoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wpCategoryHandle` varchar(255) NOT NULL,
  `pkgID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`wpCategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `WorkflowProgressCategories` WRITE;
/*!40000 ALTER TABLE `WorkflowProgressCategories` DISABLE KEYS */;

INSERT INTO `WorkflowProgressCategories` (`wpCategoryID`, `wpCategoryHandle`, `pkgID`)
VALUES
	(1,'page',NULL),
	(2,'file',NULL),
	(3,'user',NULL);

/*!40000 ALTER TABLE `WorkflowProgressCategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table WorkflowProgressHistory
# ------------------------------------------------------------

DROP TABLE IF EXISTS `WorkflowProgressHistory`;

CREATE TABLE `WorkflowProgressHistory` (
  `wphID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wpID` int(10) unsigned NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `object` text,
  PRIMARY KEY (`wphID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `WorkflowProgressHistory` WRITE;
/*!40000 ALTER TABLE `WorkflowProgressHistory` DISABLE KEYS */;

INSERT INTO `WorkflowProgressHistory` (`wphID`, `wpID`, `timestamp`, `object`)
VALUES
	(1,1,'2013-04-27 20:05:50','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"2\";s:4:\"wrID\";s:1:\"1\";}'),
	(2,2,'2013-04-27 20:06:05','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"3\";s:4:\"wrID\";s:1:\"2\";}'),
	(3,3,'2013-04-27 20:07:35','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"4\";s:4:\"wrID\";s:1:\"3\";}'),
	(4,4,'2013-04-27 20:35:40','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"5\";s:4:\"wrID\";s:1:\"4\";}'),
	(5,5,'2013-04-27 21:12:11','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"6\";s:4:\"wrID\";s:1:\"5\";}'),
	(6,6,'2013-04-27 21:38:47','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"7\";s:4:\"wrID\";s:1:\"6\";}'),
	(7,7,'2013-04-27 21:42:00','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"8\";s:4:\"wrID\";s:1:\"7\";}'),
	(8,8,'2013-04-27 21:44:02','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:1:\"9\";s:4:\"wrID\";s:1:\"8\";}'),
	(9,9,'2013-04-27 21:46:22','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:2:\"10\";s:4:\"wrID\";s:1:\"9\";}'),
	(10,10,'2013-04-27 21:49:21','O:30:\"ApprovePagePageWorkflowRequest\":8:{s:14:\"\0*\0wrStatusNum\";i:30;s:12:\"\0*\0currentWP\";N;s:6:\"\0*\0uID\";s:1:\"1\";s:5:\"error\";s:0:\"\";s:4:\"pkID\";s:2:\"12\";s:3:\"cID\";s:1:\"1\";s:4:\"cvID\";s:2:\"11\";s:4:\"wrID\";s:2:\"10\";}');

/*!40000 ALTER TABLE `WorkflowProgressHistory` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table WorkflowRequestObjects
# ------------------------------------------------------------

DROP TABLE IF EXISTS `WorkflowRequestObjects`;

CREATE TABLE `WorkflowRequestObjects` (
  `wrID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wrObject` text,
  PRIMARY KEY (`wrID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table Workflows
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Workflows`;

CREATE TABLE `Workflows` (
  `wfID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wfName` varchar(255) DEFAULT NULL,
  `wftID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`wfID`),
  UNIQUE KEY `wfName` (`wfName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table WorkflowTypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `WorkflowTypes`;

CREATE TABLE `WorkflowTypes` (
  `wftID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wftHandle` varchar(64) NOT NULL,
  `wftName` varchar(128) NOT NULL,
  `pkgID` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`wftID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `WorkflowTypes` WRITE;
/*!40000 ALTER TABLE `WorkflowTypes` DISABLE KEYS */;

INSERT INTO `WorkflowTypes` (`wftID`, `wftHandle`, `wftName`, `pkgID`)
VALUES
	(1,'basic','Basic Workflow',0);

/*!40000 ALTER TABLE `WorkflowTypes` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
